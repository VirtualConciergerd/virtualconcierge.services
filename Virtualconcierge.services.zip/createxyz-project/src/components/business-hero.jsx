"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  title = "Join Our Virtual Concierge Network",
  subtitle = "Connect with millions of travelers and grow your business through AI-powered recommendations",
  buttonText = "Verify My Business",
  heroImage = "https://picsum.photos/1920/1080",
  onVerifyClick,
}) {
  return (
    <div className="relative w-full overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Business networking background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[rgba(0,0,0,0.5)]"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-20 md:py-28 lg:py-32">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-crimson-text font-bold text-white mb-6">
              {title}
            </h1>

            <p className="text-lg md:text-xl text-white/90 mb-8 font-roboto">
              {subtitle}
            </p>

            <button
              onClick={onVerifyClick}
              className="inline-block bg-[var(--primary)] hover:bg-[var(--secondary)] text-white font-roboto px-8 py-4 rounded-lg text-lg transition-colors duration-300 transform hover:scale-105"
            >
              {buttonText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-4">Default Hero</h2>
        <MainComponent onVerifyClick={() => console.log("Verify clicked")} />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Custom Content Hero</h2>
        <MainComponent
          title="Grow Your Tourism Business"
          subtitle="Join the leading AI-powered concierge platform in the Dominican Republic"
          buttonText="Partner With Us"
          heroImage="https://picsum.photos/1920/1081"
          onVerifyClick={() => console.log("Partner clicked")}
        />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Restaurant-Focused Hero</h2>
        <MainComponent
          title="Showcase Your Restaurant"
          subtitle="Let AI-powered recommendations bring food lovers to your door"
          buttonText="List Your Restaurant"
          heroImage="https://picsum.photos/1920/1082"
          onVerifyClick={() => console.log("Restaurant clicked")}
        />
      </div>
    </div>
  );
});
}