"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ serviceId }) {
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [reviews, setReviews] = useState([]);
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  const loadReviews = async () => {
    try {
      const response = await fetch("/api/get-service-reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ serviceId }),
      });

      if (!response.ok) throw new Error("Failed to load reviews");
      const data = await response.json();
      setReviews(data);
    } catch (error) {
      console.error("Load reviews error:", error);
      setError("Failed to load reviews. Please try again later.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/create-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serviceId,
          rating,
          reviewText,
        }),
      });

      if (!response.ok) throw new Error("Failed to submit review");
      await loadReviews();
      setReviewText("");
      setRating(5);
    } catch (error) {
      console.error("Submit review error:", error);
      setError("Failed to submit review. Please try again later.");
    }
  };

  useEffect(() => {
    if (serviceId) {
      loadReviews();
    }
  }, [serviceId]);

  return (
    <div className="bg-white rounded-lg shadow">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {user ? (
        <form onSubmit={handleSubmit} className="p-6 border-b">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Rating
            </label>
            <div className="flex gap-2">
              {[5, 4, 3, 2, 1].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setRating(num)}
                  className={`text-2xl ${
                    rating >= num ? "text-yellow-400" : "text-gray-300"
                  }`}
                >
                  ★
                </button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <label
              htmlFor="review"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Your Review
            </label>
            <textarea
              id="review"
              name="review"
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              rows="4"
              placeholder="Share your experience..."
            />
          </div>

          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Submit Review
          </button>
        </form>
      ) : (
        <div className="p-6 border-b text-center">
          <p className="text-gray-600">
            Please{" "}
            <a
              href="/account/signin?callbackUrl=/"
              className="text-blue-600 hover:text-blue-800"
            >
              sign in
            </a>{" "}
            to leave a review
          </p>
        </div>
      )}

      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Customer Reviews
        </h3>
        {reviews.length === 0 ? (
          <p className="text-gray-500 text-center py-4">
            No reviews yet. Be the first to review!
          </p>
        ) : (
          <div className="space-y-6">
            {reviews.map((review) => (
              <div
                key={review.id}
                className="border-b last:border-b-0 pb-6 last:pb-0"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">
                    {review.user_name}
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(review.created_at).toLocaleDateString()}
                  </span>
                </div>
                <div className="text-yellow-400 mb-2">
                  {"★".repeat(review.rating)}
                  <span className="text-gray-300">
                    {"★".repeat(5 - review.rating)}
                  </span>
                </div>
                <p className="text-gray-700">{review.review_text}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  const mockUser = {
    id: "123",
    name: "John Doe",
    email: "john@example.com",
  };

  const mockReviews = [
    {
      id: 1,
      user_name: "Alice Smith",
      rating: 5,
      review_text:
        "Excellent service! Would definitely recommend to others. The staff was very professional and helpful.",
      created_at: "2025-01-15T10:00:00Z",
    },
    {
      id: 2,
      user_name: "Bob Johnson",
      rating: 4,
      review_text:
        "Good experience overall. There's room for improvement but I'm satisfied with the service.",
      created_at: "2025-01-14T15:30:00Z",
    },
  ];

  return (
    <div className="p-8 space-y-8 bg-gray-100">
      <div>
        <h2 className="text-lg font-medium mb-4">Signed Out State</h2>
        <MainComponent serviceId="service123" />
      </div>

      <div>
        <h2 className="text-lg font-medium mb-4">Signed In State</h2>
        <MainComponent serviceId="service123" user={mockUser} />
      </div>

      <div>
        <h2 className="text-lg font-medium mb-4">With Existing Reviews</h2>
        <MainComponent
          serviceId="service123"
          user={mockUser}
          initialReviews={mockReviews}
        />
      </div>

      <div>
        <h2 className="text-lg font-medium mb-4">Error State</h2>
        <MainComponent serviceId="invalid-service" />
      </div>
    </div>
  );
});
}