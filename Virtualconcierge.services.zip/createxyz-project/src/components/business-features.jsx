"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  features = [
    {
      title: "AI-Powered Matching",
      description:
        "Connect with tourists based on their preferences and travel style",
      icon: "brain-circuit",
      metric: "95% match accuracy",
    },
    {
      title: "Local Integration",
      description:
        "Seamlessly connect with local tourism boards and service providers",
      icon: "network",
      metric: "500+ local partners",
    },
    {
      title: "Global Reach",
      description:
        "Access international travelers planning their Caribbean getaway",
      icon: "globe",
      metric: "1M+ monthly visitors",
    },
    {
      title: "Lead Generation",
      description: "Convert interest into bookings with smart recommendations",
      icon: "line-chart",
      metric: "40% conversion rate",
    },
    {
      title: "Real-time Analytics",
      description: "Track performance and optimize your business presence",
      icon: "bar-chart",
      metric: "Live insights",
    },
    {
      title: "Multilingual Support",
      description: "Reach tourists in their preferred language",
      icon: "languages",
      metric: "12 languages",
    },
  ],
}) {
  return (
    <div className="w-full bg-gradient-to-br from-[#f8fafc] to-[#e2e8f0] py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-crimson-text font-bold text-[#1e293b] mb-4">
            Powerful Features for Your Business
          </h2>
          <p className="text-[#475569] text-lg max-w-2xl mx-auto">
            Join our network of successful businesses and tap into the growing
            tourism market
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-[#3b82f6] bg-opacity-10 rounded-lg flex items-center justify-center">
                    <i
                      className={`fas fa-${feature.icon} text-[#3b82f6] text-xl`}
                    ></i>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-crimson-text font-bold text-[#1e293b] mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-[#475569] mb-4">{feature.description}</p>
                  <div className="flex items-center text-[#3b82f6] font-semibold">
                    <i className="fas fa-chart-line mr-2"></i>
                    {feature.metric}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  // Basic Features Story
  const basicFeatures = [
    {
      title: "Smart Matching",
      description: "AI-powered tourist matching system",
      icon: "robot",
      metric: "90% accuracy",
    },
    {
      title: "Local Network",
      description: "Connect with local businesses",
      icon: "handshake",
      metric: "200+ partners",
    },
    {
      title: "Analytics",
      description: "Detailed business insights",
      icon: "chart-line",
      metric: "Real-time data",
    },
  ];

  // Extended Features Story
  const extendedFeatures = [
    {
      title: "AI Concierge",
      description: "24/7 automated customer service",
      icon: "robot",
      metric: "98% satisfaction",
    },
    {
      title: "Booking System",
      description: "Integrated reservation management",
      icon: "calendar",
      metric: "50K+ bookings",
    },
    {
      title: "Marketing Tools",
      description: "Automated promotion campaigns",
      icon: "bullhorn",
      metric: "3x ROI",
    },
    {
      title: "Payment Processing",
      description: "Secure, multi-currency transactions",
      icon: "credit-card",
      metric: "100% secure",
    },
    {
      title: "Customer Insights",
      description: "Detailed visitor analytics",
      icon: "users",
      metric: "Rich data",
    },
    {
      title: "Support",
      description: "24/7 multilingual assistance",
      icon: "headset",
      metric: "5min response",
    },
  ];

  return (
    <div className="space-y-12">
      <div>
        <h2 className="text-2xl font-bold mb-4">Basic Features Display</h2>
        <MainComponent features={basicFeatures} />
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Extended Features Display</h2>
        <MainComponent features={extendedFeatures} />
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Default Features Display</h2>
        <MainComponent />
      </div>
    </div>
  );
});
}