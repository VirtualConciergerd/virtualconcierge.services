"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  testimonials = [
    {
      name: "Maria Rodriguez",
      business: "Punta Cana Adventures",
      image: "https://picsum.photos/200/200?random=1",
      rating: 5,
      review:
        "Joining Virtual Concierge transformed our business. Our bookings increased by 200% in just three months!",
      position: "Owner",
      revenue: "+200% Revenue",
    },
    {
      name: "Carlos Mendez",
      business: "Santo Domingo Food Tours",
      image: "https://picsum.photos/200/200?random=2",
      rating: 5,
      review:
        "The AI-powered recommendations have brought us exactly the kind of customers we were looking for. Outstanding results!",
      position: "CEO",
      revenue: "+150% Bookings",
    },
    {
      name: "Ana Rivera",
      business: "Samaná Bay Excursions",
      image: "https://picsum.photos/200/200?random=3",
      rating: 5,
      review:
        "The integration was seamless, and the support team is always there when we need them. Best business decision we've made.",
      position: "Director",
      revenue: "+180% Growth",
    },
    {
      name: "Luis Morales",
      business: "Puerto Plata Hospitality",
      image: "https://picsum.photos/200/200?random=4",
      rating: 5,
      review:
        "Virtual Concierge has helped us reach international travelers we never had access to before. Simply amazing!",
      position: "Founder",
      revenue: "+250% Reach",
    },
  ],
}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const nextSlide = useCallback(() => {
    if (!isAnimating) {
      setIsAnimating(true);
      setCurrentIndex((prevIndex) =>
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1,
      );
      setTimeout(() => setIsAnimating(false), 500);
    }
  }, [isAnimating, testimonials.length]);

  const prevSlide = useCallback(() => {
    if (!isAnimating) {
      setIsAnimating(true);
      setCurrentIndex((prevIndex) =>
        prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1,
      );
      setTimeout(() => setIsAnimating(false), 500);
    }
  }, [isAnimating, testimonials.length]);

  useEffect(() => {
    const timer = setInterval(() => {
      nextSlide();
    }, 5000);

    return () => clearInterval(timer);
  }, [nextSlide]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-crimson-text text-center text-[#1e293b] font-bold mb-12">
          Success Stories
        </h2>

        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <div className="flex flex-col items-center">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-24 h-24 rounded-full mb-6 object-cover"
                    />
                    <div className="flex mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <i key={i} className="fas fa-star text-yellow-400"></i>
                      ))}
                    </div>
                    <p className="text-[#475569] text-lg text-center mb-6 italic max-w-2xl">
                      "{testimonial.review}"
                    </p>
                    <div className="text-center">
                      <h3 className="text-xl font-bold text-[#1e293b] mb-1">
                        {testimonial.name}
                      </h3>
                      <p className="text-[#3b82f6] font-semibold mb-1">
                        {testimonial.business}
                      </p>
                      <p className="text-[#475569] text-sm mb-2">
                        {testimonial.position}
                      </p>
                      <span className="inline-block bg-[#3b82f6] text-white px-4 py-1 rounded-full text-sm">
                        {testimonial.revenue}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-6 bg-white rounded-full p-3 shadow-lg text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            disabled={isAnimating}
          >
            <i className="fas fa-chevron-left"></i>
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-6 bg-white rounded-full p-3 shadow-lg text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            disabled={isAnimating}
          >
            <i className="fas fa-chevron-right"></i>
          </button>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  if (!isAnimating) {
                    setIsAnimating(true);
                    setCurrentIndex(index);
                    setTimeout(() => setIsAnimating(false), 500);
                  }
                }}
                className={`w-3 h-3 rounded-full transition-colors ${
                  currentIndex === index ? "bg-[#3b82f6]" : "bg-[#e2e8f0]"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const defaultTestimonials = [
    {
      name: "Maria Rodriguez",
      business: "Punta Cana Adventures",
      image: "https://picsum.photos/200/200?random=1",
      rating: 5,
      review:
        "Joining Virtual Concierge transformed our business. Our bookings increased by 200% in just three months!",
      position: "Owner",
      revenue: "+200% Revenue",
    },
    {
      name: "Carlos Mendez",
      business: "Santo Domingo Food Tours",
      image: "https://picsum.photos/200/200?random=2",
      rating: 5,
      review:
        "The AI-powered recommendations have brought us exactly the kind of customers we were looking for. Outstanding results!",
      position: "CEO",
      revenue: "+150% Bookings",
    },
  ];

  const extendedTestimonials = [
    ...defaultTestimonials,
    {
      name: "Ana Rivera",
      business: "Samaná Bay Excursions",
      image: "https://picsum.photos/200/200?random=3",
      rating: 5,
      review:
        "The integration was seamless, and the support team is always there when we need them. Best business decision we've made.",
      position: "Director",
      revenue: "+180% Growth",
    },
    {
      name: "Luis Morales",
      business: "Puerto Plata Hospitality",
      image: "https://picsum.photos/200/200?random=4",
      rating: 4,
      review:
        "Virtual Concierge has helped us reach international travelers we never had access to before. Simply amazing!",
      position: "Founder",
      revenue: "+250% Reach",
    },
  ];

  return (
    <div className="space-y-8 p-8 bg-[#f8fafc]">
      <div>
        <h2 className="text-2xl font-bold mb-4">Default Testimonials</h2>
        <MainComponent testimonials={defaultTestimonials} />
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Extended Testimonials</h2>
        <MainComponent testimonials={extendedTestimonials} />
      </div>
    </div>
  );
});
}