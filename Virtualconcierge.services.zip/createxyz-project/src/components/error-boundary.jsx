"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ children, fallbackUI, onRetry, section = "general" }) {
  const [error, setError] = useState(null);
  const [errorInfo, setErrorInfo] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const { data: user } = useUser();

  const logError = useCallback(async (error, info) => {
    try {
      const response = await fetch("/api/error-log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          error: {
            message: error.message,
            name: error.name,
            stack: error.stack,
            type: error.type || "general",
          },
          info,
          section,
          userId: user?.id,
          timestamp: new Date().toISOString(),
          retryCount,
          userAgent: navigator.userAgent,
        }),
      });

      if (!response.ok) {
        console.error("Failed to log error:", await response.text());
      }
    } catch (logError) {
      console.error("Error logging failed:", logError);
    }
  }, [section, user, retryCount]);

  useEffect(() => {
    const handleGlobalError = (event) => {
      const error = event.error;
      console.error("Global error caught:", error);
      logError(error, { type: "global" });
      setError(error);
      event.preventDefault();
    };

    window.addEventListener("error", handleGlobalError);
    return () => window.removeEventListener("error", handleGlobalError);
  }, [logError]);

  useEffect(() => {
    const handleUnhandledRejection = (event) => {
      const error = event.reason;
      console.error("Unhandled promise rejection:", error);
      logError(error, { type: "promise" });
      setError(error);
      event.preventDefault();
    };

    window.addEventListener("unhandledrejection", handleUnhandledRejection);
    return () => window.removeEventListener("unhandledrejection", handleUnhandledRejection);
  }, [logError]);

  const handleRetry = useCallback(async () => {
    setRetryCount(count => count + 1);
    setError(null);
    setErrorInfo(null);
    
    if (onRetry) {
      try {
        await onRetry();
      } catch (retryError) {
        logError(retryError, { type: "retry" });
        setError(retryError);
      }
    }
  }, [onRetry, logError]);

  const getErrorDetails = useCallback((error) => {
    let message = "Something unexpected happened";
    let type = "general";
    let icon = "exclamation-circle";
    let color = "gray";
    let action = "Please try again or contact support";

    if (error.name === "NetworkError" || error.message?.includes("network") || error.message?.includes("fetch")) {
      message = "Unable to connect to our servers";
      type = "network";
      icon = "wifi";
      color = "blue";
      action = "Please check your internet connection";
    } else if (error.name === "ValidationError" || error.message?.includes("validation")) {
      message = "The provided information is invalid";
      type = "validation";
      icon = "exclamation-triangle";
      color = "yellow";
      action = "Please check your input and try again";
    } else if (error.status === 401 || error.message?.includes("unauthorized")) {
      message = "Your session has expired";
      type = "auth";
      icon = "lock";
      color = "red";
      action = "Please sign in again";
    } else if (error.status === 403 || error.message?.includes("forbidden")) {
      message = "You don't have permission to perform this action";
      type = "permission";
      icon = "shield-alt";
      color = "orange";
      action = "Please contact your administrator";
    } else if (error.status === 404 || error.message?.includes("not found")) {
      message = "The requested resource was not found";
      type = "notFound";
      icon = "search";
      color = "purple";
      action = "Please check the URL and try again";
    }

    return { message, type, icon, color, action };
  }, []);

  if (error) {
    if (fallbackUI) {
      return fallbackUI({ error, reset: handleRetry });
    }

    const { message, type, icon, color, action } = getErrorDetails(error);

    return (
      <div className="rounded-lg bg-white shadow-lg p-6 max-w-lg mx-auto">
        <div className={`text-center mb-6 text-${color}-500`}>
          <i className={`fas fa-${icon} text-4xl`}></i>
        </div>
        
        <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2 text-center">
          {message}
        </h2>
        
        <p className="text-[#475569] text-center mb-6">{action}</p>
        
        {errorInfo && (
          <div className="bg-gray-50 rounded p-4 mb-4 overflow-auto max-h-32">
            <pre className="text-sm text-gray-600 whitespace-pre-wrap">
              {errorInfo.componentStack}
            </pre>
          </div>
        )}
        
        <div className="flex justify-center gap-4">
          {retryCount < 3 && (
            <button
              onClick={handleRetry}
              className="inline-block bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
            >
              <i className="fas fa-redo mr-2"></i>
              Try Again ({3 - retryCount} attempts left)
            </button>
          )}
          
          <a
            href="/"
            className="inline-block bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <i className="fas fa-home mr-2"></i>
            Go Home
          </a>
          
          {type === "auth" && (
            <a
              href="/account/signin"
              className="inline-block bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
            >
              <i className="fas fa-sign-in-alt mr-2"></i>
              Sign In
            </a>
          )}
        </div>
      </div>
    );
  }

  return children;
}

function StoryComponent() {
  const [count, setCount] = useState(0);

  const BuggyCounter = () => {
    if (count === 5) {
      throw new Error("Simulated error: Counter reached 5!");
    }
    return (
      <button
        onClick={() => setCount(c => c + 1)}
        className="bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
      >
        Count: {count}
      </button>
    );
  };

  const NetworkErrorExample = () => {
    throw new Error("NetworkError: Failed to fetch data");
  };

  const ValidationErrorExample = () => {
    throw { name: "ValidationError", message: "Invalid input data" };
  };

  const AuthErrorExample = () => {
    throw { status: 401, message: "Unauthorized access" };
  };

  const NotFoundErrorExample = () => {
    throw { status: 404, message: "Resource not found" };
  };

  const PermissionErrorExample = () => {
    throw { status: 403, message: "Forbidden access" };
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-4">Basic Error Example:</h2>
        <MainComponent section="counter">
          <BuggyCounter />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Network Error Example:</h2>
        <MainComponent section="network">
          <NetworkErrorExample />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Validation Error Example:</h2>
        <MainComponent section="validation">
          <ValidationErrorExample />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Auth Error Example:</h2>
        <MainComponent section="auth">
          <AuthErrorExample />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Not Found Error Example:</h2>
        <MainComponent section="notFound">
          <NotFoundErrorExample />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Permission Error Example:</h2>
        <MainComponent section="permission">
          <PermissionErrorExample />
        </MainComponent>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Custom Fallback UI Example:</h2>
        <MainComponent
          section="custom"
          fallbackUI={({ error, reset }) => (
            <div className="bg-purple-100 p-4 rounded-lg">
              <p className="text-purple-800 mb-2">Custom error UI: {error.message}</p>
              <button
                onClick={reset}
                className="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600"
              >
                Reset
              </button>
            </div>
          )}
        >
          <BuggyCounter />
        </MainComponent>
      </div>
    </div>
  );
});
}