"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  guides = [],
  loading = false,
  error = null,
  onGuideSelect,
  onDownload,
  isAuthenticated = false,
  currency = "USD",
  className = "",
}) {
  if (loading) {
    return (
      <div className={`grid md:grid-cols-3 gap-6 ${className}`}>
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="guide-card bg-white rounded-lg shadow-lg overflow-hidden animate-pulse"
          >
            <div className="w-full h-48 bg-gray-200"></div>
            <div className="p-4">
              <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
        {error}
      </div>
    );
  }

  if (!guides.length) {
    return (
      <div className="text-center py-8 text-[#475569]">
        No guides available at the moment.
      </div>
    );
  }

  const formatPrice = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
    }).format(amount);
  };

  return (
    <div className={`grid md:grid-cols-3 gap-6 ${className}`}>
      {guides.map((guide) => (
        <div
          key={guide.id}
          className="guide-card bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
        >
          <div className="relative">
            <img
              src={guide.preview_image}
              alt={guide.title}
              className="w-full h-48 object-cover"
            />
            {guide.featured && (
              <div className="absolute top-0 right-0 bg-[#3b82f6] text-white px-3 py-1 text-sm">
                Featured
              </div>
            )}
          </div>
          <div className="p-4">
            <h3 className="text-xl font-crimson-text font-bold text-[#1e293b] mb-2">
              {guide.title}
            </h3>
            <p className="text-[#475569] mb-4 line-clamp-2">
              {guide.description}
            </p>
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-bold text-[#1e293b]">
                {formatPrice(guide.price)}
              </span>
              {guide.rating && (
                <div className="flex items-center">
                  <i className="fas fa-star text-yellow-400 mr-1"></i>
                  <span className="text-[#475569]">{guide.rating}</span>
                </div>
              )}
            </div>
            <div className="space-y-2">
              {isAuthenticated ? (
                <>
                  <button
                    onClick={() => onGuideSelect?.(guide)}
                    className="w-full bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
                  >
                    View Details
                  </button>
                  {guide.downloadable && (
                    <button
                      onClick={() => onDownload?.(guide)}
                      className="w-full border border-[#3b82f6] text-[#3b82f6] px-4 py-2 rounded-lg hover:bg-[#f8fafc] transition-colors"
                    >
                      <i className="fas fa-download mr-2"></i>
                      Download Guide
                    </button>
                  )}
                </>
              ) : (
                <a
                  href="/account/signin?callbackUrl=/"
                  className="block w-full text-center bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
                >
                  Sign in to Access
                </a>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function StoryComponent() {
  const sampleGuides = [
    {
      id: 1,
      title: "Ultimate Santo Domingo Guide",
      description:
        "Complete guide to exploring the historic capital city with local insights and hidden gems.",
      price: 29.99,
      preview_image:
        "https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/",
      rating: 4.8,
      featured: true,
      downloadable: true,
    },
    {
      id: 2,
      title: "Punta Cana Beach Explorer",
      description:
        "Discover the best beaches, activities, and resorts in Punta Cana.",
      price: 24.99,
      preview_image:
        "https://ucarecdn.com/3ec4320a-3d69-4366-9e7d-98da2b9ed3a3/",
      rating: 4.6,
      downloadable: true,
    },
    {
      id: 3,
      title: "Dominican Cuisine Masterclass",
      description:
        "Learn about local dishes, ingredients, and top restaurant recommendations.",
      price: 19.99,
      preview_image:
        "https://ucarecdn.com/ace54da1-c23e-4177-84cf-95c1cba4d606/-/format/auto/",
      rating: 4.9,
      downloadable: true,
    },
  ];

  return (
    <div className="p-8 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-12">
        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-6">
            Default State (Authenticated)
          </h2>
          <MainComponent
            guides={sampleGuides}
            isAuthenticated={true}
            onGuideSelect={(guide) => console.log("Selected guide:", guide)}
            onDownload={(guide) => console.log("Downloading guide:", guide)}
          />
        </div>

        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-6">
            Not Authenticated
          </h2>
          <MainComponent guides={sampleGuides} isAuthenticated={false} />
        </div>

        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-6">
            Loading State
          </h2>
          <MainComponent loading={true} />
        </div>

        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-6">
            Error State
          </h2>
          <MainComponent error="Failed to load guides. Please try again later." />
        </div>

        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-6">
            Empty State
          </h2>
          <MainComponent guides={[]} />
        </div>
      </div>
    </div>
  );
});
}