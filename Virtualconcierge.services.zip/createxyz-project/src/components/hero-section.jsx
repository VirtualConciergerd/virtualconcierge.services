"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  title,
  description,
  imageUrl,
  isLoading,
  error,
  fallbackImage = "https://images.unsplash.com/photo-1580253320029-be897f5f420a?ixlib=rb-1.2.1&auto=format&fit=crop&w=3000&q=80",
  ctaText,
  onCtaClick,
}) {
  const backgroundImage = imageUrl || fallbackImage;

  if (isLoading) {
    return (
      <div className="relative h-[500px] bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-[500px] overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center transition-opacity duration-300"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
      </div>

      <div className="relative h-full flex items-center justify-center text-center px-4">
        <div className="max-w-4xl">
          {title && (
            <h1 className="text-4xl md:text-6xl font-crimson-text text-white font-bold mb-6">
              {title}
            </h1>
          )}

          {description && (
            <p className="text-xl text-white mb-8 max-w-2xl mx-auto">
              {description}
            </p>
          )}

          {ctaText && (
            <button
              onClick={onCtaClick}
              className="bg-[#3b82f6] text-white px-8 py-3 rounded-full text-lg hover:bg-[#2563eb] transition-colors inline-block"
            >
              {ctaText}
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="absolute bottom-4 right-4 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-md text-sm">
          {error}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="space-y-8">
      <MainComponent
        title="Welcome to Virtual Concierge"
        description="Your AI-powered travel companion for unforgettable experiences"
        imageUrl="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
        ctaText="Get Started"
        onCtaClick={() => console.log("CTA clicked")}
      />

      <MainComponent
        title="Discover Local Experiences"
        description="Explore authentic destinations with personalized recommendations"
        imageUrl="https://ucarecdn.com/3ec4320a-3d69-4366-9e7d-98da2b9ed3a3/"
        isLoading={false}
        error="Using fallback image"
        ctaText="Explore Now"
        onCtaClick={() => console.log("Explore clicked")}
      />

      <MainComponent isLoading={true} />

      <MainComponent
        title="Error State Example"
        error="Failed to load hero image"
        ctaText="Try Again"
        onCtaClick={() => setIsLoading(false)}
      />
    </div>
  );
});
}