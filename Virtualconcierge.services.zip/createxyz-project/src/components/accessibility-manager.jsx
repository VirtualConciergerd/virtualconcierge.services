"use client";
import React from "react";



export default function Index() {
  return (const AccessibilityContext = createContext();

function MainComponent({ children }) {
  const [settings, setSettings] = useState({
    highContrast: false,
    reduceMotion: false,
    fontSize: 'medium',
    screenReaderOptimized: false,
    keyboardNavigation: true,
    colorBlindMode: 'none'
  });

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const response = await fetch('/api/user/accessibility-settings');
        if (response.ok) {
          const data = await response.json();
          setSettings(data.settings);
          applySettings(data.settings);
        }
      } catch (error) {
        console.error('Failed to load accessibility settings:', error);
      }
    };
    loadSettings();
  }, []);

  const applySettings = (newSettings) => {
    document.documentElement.classList.toggle('high-contrast', newSettings.highContrast);
    document.documentElement.classList.toggle('reduce-motion', newSettings.reduceMotion);
    
    document.documentElement.style.fontSize = {
      small: '14px',
      medium: '16px',
      large: '18px',
      'extra-large': '20px'
    }[newSettings.fontSize];
    
    document.documentElement.setAttribute('data-color-blind-mode', newSettings.colorBlindMode);
    document.documentElement.classList.toggle('keyboard-nav', newSettings.keyboardNavigation);
  };

  const updateSettings = async (newSettings) => {
    try {
      const response = await fetch('/api/user/accessibility-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: newSettings })
      });
      
      if (response.ok) {
        setSettings(newSettings);
        applySettings(newSettings);
      }
    } catch (error) {
      console.error('Failed to update accessibility settings:', error);
    }
  };

  return (
    <></>
  );
}

function StoryComponent() {
  return (
    <div className="p-4">
      <MainComponent>
        <div className="space-y-4">
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-xl font-bold mb-4">Default Settings</h2>
            <pre className="bg-gray-100 p-2 rounded">
              {JSON.stringify({
                highContrast: false,
                reduceMotion: false,
                fontSize: 'medium',
                screenReaderOptimized: false,
                keyboardNavigation: true,
                colorBlindMode: 'none'
              }, null, 2)}
            </pre>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-xl font-bold mb-4">High Contrast Settings</h2>
            <pre className="bg-gray-100 p-2 rounded">
              {JSON.stringify({
                highContrast: true,
                reduceMotion: true,
                fontSize: 'large',
                screenReaderOptimized: true,
                keyboardNavigation: true,
                colorBlindMode: 'deuteranopia'
              }, null, 2)}
            </pre>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-xl font-bold mb-4">Enhanced Readability</h2>
            <pre className="bg-gray-100 p-2 rounded">
              {JSON.stringify({
                highContrast: false,
                reduceMotion: true,
                fontSize: 'extra-large',
                screenReaderOptimized: true,
                keyboardNavigation: true,
                colorBlindMode: 'none'
              }, null, 2)}
            </pre>
          </div>
        </div>
      </MainComponent>
    </div>
  );
}

export function useAccessibility() {
  return useContext(AccessibilityContext);
});
}