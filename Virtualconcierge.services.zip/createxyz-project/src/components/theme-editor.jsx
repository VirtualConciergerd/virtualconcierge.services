"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ countryId, initialTheme = null, onSave }) {
  const [theme, setTheme] = useState({
    primary: "#FF4B3E",
    secondary: "#2EC4B6",
    accent: "#FED766",
    highlight1: "#eac0ff",
    highlight2: "#38b6ff",
    highlight3: "#ffde59",
  });
  const [previewMode, setPreviewMode] = useState("light");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (initialTheme) {
      setTheme(initialTheme);
    }
  }, [initialTheme]);

  const presetThemes = {
    dominican: {
      primary: "#002D62",
      secondary: "#CE1126",
      accent: "#FFFFFF",
      highlight1: "#041E42",
      highlight2: "#BF0D3E",
      highlight3: "#F1F1F1",
    },
    jamaica: {
      primary: "#009B3A",
      secondary: "#FED100",
      accent: "#000000",
      highlight1: "#007C2E",
      highlight2: "#FFB81C",
      highlight3: "#1A1A1A",
    },
    bahamas: {
      primary: "#00ABC9",
      secondary: "#FAE042",
      accent: "#000000",
      highlight1: "#0097B2",
      highlight2: "#FFD700",
      highlight3: "#1A1A1A",
    },
  };

  const checkContrast = (color1, color2) => {
    const luminance = (r, g, b) => {
      const [rs, gs, bs] = [r, g, b].map((c) => {
        c = c / 255;
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
    };

    const hex2rgb = (hex) => {
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result
        ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16),
          }
        : null;
    };

    const rgb1 = hex2rgb(color1);
    const rgb2 = hex2rgb(color2);
    const l1 = luminance(rgb1.r, rgb1.g, rgb1.b);
    const l2 = luminance(rgb2.r, rgb2.g, rgb2.b);
    const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    return ratio >= 4.5;
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await onSave(theme);
    } catch (err) {
      setError("Failed to save theme");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setTheme({
      primary: "#FF4B3E",
      secondary: "#2EC4B6",
      accent: "#FED766",
      highlight1: "#eac0ff",
      highlight2: "#38b6ff",
      highlight3: "#ffde59",
    });
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <h3 className="font-bold text-[#1e293b] mb-4">Theme Colors</h3>
            <div className="space-y-4">
              {Object.entries(theme).map(([key, value]) => (
                <div key={key} className="flex items-center space-x-4">
                  <label className="w-24 text-[#475569]">{key}</label>
                  <input
                    type="color"
                    value={value}
                    onChange={(e) =>
                      setTheme((prev) => ({ ...prev, [key]: e.target.value }))
                    }
                    className="w-12 h-12 rounded cursor-pointer border border-gray-200"
                  />
                  <input
                    type="text"
                    value={value}
                    onChange={(e) =>
                      setTheme((prev) => ({ ...prev, [key]: e.target.value }))
                    }
                    className="w-24 px-2 py-1 border rounded"
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-[#1e293b] mb-4">Preset Themes</h3>
            <div className="grid grid-cols-3 gap-4">
              {Object.entries(presetThemes).map(([name, colors]) => (
                <button
                  key={name}
                  onClick={() => setTheme(colors)}
                  className="p-4 border rounded-lg hover:shadow-lg transition-shadow"
                >
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-16 h-8 rounded overflow-hidden border">
                      {Object.values(colors).map((color, i) => (
                        <div
                          key={i}
                          className="h-2"
                          style={{ backgroundColor: color }}
                        ></div>
                      ))}
                    </div>
                    <span className="text-sm text-[#475569] capitalize">
                      {name}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={() =>
                setPreviewMode((prev) => (prev === "light" ? "dark" : "light"))
              }
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
            >
              Toggle {previewMode === "light" ? "Dark" : "Light"} Mode
            </button>
            <button
              onClick={handleReset}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
            >
              Reset
            </button>
            <button
              onClick={handleSave}
              disabled={loading}
              className="px-4 py-2 bg-[#3b82f6] text-white rounded-lg hover:bg-[#2563eb] disabled:opacity-50"
            >
              {loading ? "Saving..." : "Save Theme"}
            </button>
          </div>

          {error && <div className="text-red-500">{error}</div>}
        </div>

        <div className="space-y-6">
          <h3 className="font-bold text-[#1e293b] mb-4">Preview</h3>

          <div
            className={`p-6 rounded-lg ${previewMode === "dark" ? "bg-gray-800" : "bg-white"} shadow-lg`}
          >
            <div className="space-y-4">
              <div className="flex space-x-4">
                <button
                  style={{ backgroundColor: theme.primary }}
                  className="px-4 py-2 text-white rounded"
                >
                  Primary Button
                </button>
                <button
                  style={{ backgroundColor: theme.secondary }}
                  className="px-4 py-2 text-white rounded"
                >
                  Secondary Button
                </button>
                <button
                  style={{ backgroundColor: theme.accent }}
                  className="px-4 py-2 text-white rounded"
                >
                  Accent Button
                </button>
              </div>

              <div className="space-y-2">
                <div
                  style={{ backgroundColor: theme.highlight1 }}
                  className="p-4 rounded"
                >
                  Highlight 1 Background
                </div>
                <div
                  style={{ backgroundColor: theme.highlight2 }}
                  className="p-4 rounded"
                >
                  Highlight 2 Background
                </div>
                <div
                  style={{ backgroundColor: theme.highlight3 }}
                  className="p-4 rounded"
                >
                  Highlight 3 Background
                </div>
              </div>

              <div className="p-4 border rounded">
                <h4 className="font-bold mb-2">Contrast Check</h4>
                {Object.entries(theme).map(([key, value]) => (
                  <div key={key} className="flex items-center space-x-2">
                    <span
                      style={{ color: value }}
                      className={`${previewMode === "dark" ? "bg-gray-800" : "bg-white"}`}
                    >
                      Text on {previewMode === "light" ? "Light" : "Dark"}
                    </span>
                    <span
                      className={`text-xs ${checkContrast(value, previewMode === "dark" ? "#1f2937" : "#ffffff") ? "text-green-500" : "text-red-500"}`}
                    >
                      {checkContrast(
                        value,
                        previewMode === "dark" ? "#1f2937" : "#ffffff",
                      )
                        ? "✓ WCAG AA"
                        : "✗ Poor Contrast"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const [savedTheme, setSavedTheme] = useState(null);

  const handleSave = (theme) => {
    setSavedTheme(theme);
  };

  return (
    <div className="p-8 bg-gray-100">
      <h2 className="text-2xl font-bold mb-8">Theme Editor Demo</h2>
      <MainComponent
        countryId="123"
        initialTheme={{
          primary: "#FF4B3E",
          secondary: "#2EC4B6",
          accent: "#FED766",
          highlight1: "#eac0ff",
          highlight2: "#38b6ff",
          highlight3: "#ffde59",
        }}
        onSave={handleSave}
      />
      {savedTheme && (
        <div className="mt-8 p-4 bg-white rounded">
          <h3 className="font-bold mb-2">Saved Theme:</h3>
          <pre>{JSON.stringify(savedTheme, null, 2)}</pre>
        </div>
      )}
    </div>
  );
});
}