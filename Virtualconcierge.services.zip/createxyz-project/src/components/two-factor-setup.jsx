"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ onComplete, onError }) {
  const [step, setStep] = useState('initial');
  const [setupData, setSetupData] = useState(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState(null);
  const [showBackupCodes, setShowBackupCodes] = useState(false);

  const initiate2FASetup = async () => {
    try {
      const response = await fetch('/api/setup-2-fa', {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error('Failed to initiate 2FA setup');
      }

      const data = await response.json();
      setSetupData(data);
      setStep('setup');
    } catch (error) {
      const errorMessage = 'Failed to initiate 2FA setup';
      setError(errorMessage);
      onError?.(errorMessage);
    }
  };

  const verify2FA = async () => {
    try {
      const response = await fetch('/api/verify-2-fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: verificationCode })
      });

      if (!response.ok) {
        throw new Error('Invalid verification code');
      }

      setStep('complete');
      setShowBackupCodes(true);
      onComplete?.();
    } catch (error) {
      const errorMessage = 'Failed to verify 2FA';
      setError(errorMessage);
      onError?.(errorMessage);
    }
  };

  return (
    <div className="max-w-md bg-white rounded-lg shadow-lg p-6">
      {error && (
        <div className="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
          {error}
        </div>
      )}

      {step === 'initial' && (
        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-4">
            Setup Two-Factor Authentication
          </h2>
          <p className="mb-4 text-[#475569]">
            Enhance your account security by enabling two-factor authentication.
          </p>
          <button
            onClick={initiate2FASetup}
            className="w-full bg-[#3b82f6] text-white px-6 py-3 rounded-lg hover:bg-[#2563eb] transition-colors"
          >
            Begin Setup
          </button>
        </div>
      )}

      {step === 'setup' && setupData && (
        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-4">
            Scan QR Code
          </h2>
          <div className="mb-4">
            <img
              src={setupData.qrCode}
              alt="2FA QR Code"
              className="mx-auto"
            />
          </div>
          <p className="mb-4 text-sm text-[#475569]">
            Scan this QR code with your authenticator app or enter the code manually:
            <code className="block mt-2 p-2 bg-gray-50 rounded font-mono text-sm">
              {setupData.secret}
            </code>
          </p>
          <div className="mb-4">
            <input
              type="text"
              name="verification-code"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Enter verification code"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
            />
          </div>
          <button
            onClick={verify2FA}
            className="w-full bg-[#3b82f6] text-white px-6 py-3 rounded-lg hover:bg-[#2563eb] transition-colors"
          >
            Verify
          </button>
        </div>
      )}

      {step === 'complete' && (
        <div>
          <h2 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-4">
            2FA Setup Complete
          </h2>
          {showBackupCodes && setupData && (
            <div>
              <p className="mb-2 text-[#475569]">
                Save these backup codes in a secure place. You can use them to access your account if you lose your authenticator device.
              </p>
              <div className="bg-gray-50 p-4 rounded-lg mb-4 font-mono text-sm">
                {setupData.backupCodes.map((code, index) => (
                  <code key={index} className="block mb-1">
                    {code}
                  </code>
                ))}
              </div>
              <button
                onClick={() => setShowBackupCodes(false)}
                className="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
              >
                I've Saved My Backup Codes
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [setupComplete, setSetupComplete] = useState(false);
  const [setupError, setSetupError] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-crimson-text font-bold text-[#1e293b] mb-8">
          Two-Factor Authentication Setup
        </h1>
        
        <MainComponent
          onComplete={() => setSetupComplete(true)}
          onError={setSetupError}
        />

        {setupComplete && (
          <div className="mt-4 p-4 bg-green-100 text-green-700 rounded-lg">
            2FA setup completed successfully!
          </div>
        )}
        
        {setupError && (
          <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
            Error: {setupError}
          </div>
        )}
      </div>
    </div>
  );
});
}