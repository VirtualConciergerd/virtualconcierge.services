"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ title, items, type }) {
  const renderRating = (rating) => {
    return "★".repeat(Math.floor(rating)) + "☆".repeat(5 - Math.floor(rating));
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {items.map((item, index) => (
          <div
            key={item.id}
            className="flex border rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="w-1/3">
              <img
                src={item.image_url || "https://via.placeholder.com/150"}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-2/3 p-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="inline-block bg-primary text-white text-sm px-2 py-1 rounded-full mb-2">
                    #{index + 1}
                  </span>
                  <h3 className="text-xl font-semibold mb-1">{item.name}</h3>
                </div>
                <div className="text-yellow-500 text-sm">
                  {renderRating(item.average_rating)}
                  <div className="text-gray-600 text-xs">
                    ({item.total_reviews} reviews)
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-2">{item.description}</p>
              <div className="text-sm text-gray-500">
                {item.region_name}, {item.country_name}
              </div>
              {item.price_range && (
                <div className="text-sm text-gray-500">
                  Price Range: {item.price_range}
                </div>
              )}
              {type === "tour" && item.duration && (
                <div className="text-sm text-gray-500">
                  Duration: {item.duration}
                </div>
              )}
              {item.booking_link && (
                <a
                  href={item.booking_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block mt-2 text-primary hover:underline"
                >
                  Book Now
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StoryComponent() {
  const tourItems = [
    {
      id: 1,
      name: "Historic City Tour",
      description: "Explore the colonial zone with expert guides",
      image_url: "https://via.placeholder.com/150",
      average_rating: 4.5,
      total_reviews: 128,
      region_name: "Santo Domingo",
      country_name: "Dominican Republic",
      price_range: "$50-$100",
      duration: "3 hours",
      booking_link: "https://example.com/book/tour1",
    },
    {
      id: 2,
      name: "Saona Island Adventure",
      description: "Paradise island excursion with snorkeling",
      image_url: "https://via.placeholder.com/150",
      average_rating: 5,
      total_reviews: 256,
      region_name: "La Romana",
      country_name: "Dominican Republic",
      price_range: "$100-$150",
      duration: "Full day",
      booking_link: "https://example.com/book/tour2",
    },
  ];

  const accommodationItems = [
    {
      id: 1,
      name: "Luxury Beach Resort",
      description: "5-star beachfront resort with spa",
      image_url: "https://via.placeholder.com/150",
      average_rating: 4.8,
      total_reviews: 512,
      region_name: "Punta Cana",
      country_name: "Dominican Republic",
      price_range: "$200-$500",
      booking_link: "https://example.com/book/hotel1",
    },
    {
      id: 2,
      name: "Boutique City Hotel",
      description: "Charming hotel in colonial zone",
      image_url: "https://via.placeholder.com/150",
      average_rating: 4.2,
      total_reviews: 89,
      region_name: "Santo Domingo",
      country_name: "Dominican Republic",
      price_range: "$100-$200",
      booking_link: "https://example.com/book/hotel2",
    },
  ];

  return (
    <div className="p-4 space-y-8">
      <MainComponent title="Top 10 Tours" items={tourItems} type="tour" />
      <MainComponent
        title="Top 10 Accommodations"
        items={accommodationItems}
        type="accommodation"
      />
    </div>
  );
});
}