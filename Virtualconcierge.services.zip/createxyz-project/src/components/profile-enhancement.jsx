"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  user,
  loading,
  profileData,
  error,
  isEditing,
  customField,
  newTag,
  onProfileUpdate,
  onVerificationRequest,
  onAddCustomField,
  onAddProfileTag,
  onEditToggle,
  onCustomFieldChange,
  onNewTagChange
}) {
  if (loading || !profileData) {
    return (
      <div className="flex justify-center items-center p-8">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-100 text-red-700 p-3 rounded">
          {error}
        </div>
      )}

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-2">Profile Completion</h3>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div
            className="bg-blue-600 h-2.5 rounded-full"
            style={{ width: `${profileData.completionPercentage}%` }}
          ></div>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          {profileData.completionPercentage}% Complete
        </p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Profile Type</h3>
        <div className="flex space-x-4">
          {['personal', 'business', 'professional'].map(type => (
            <button
              key={type}
              onClick={() => onProfileUpdate({ profile_type: type })}
              className={`px-4 py-2 rounded ${
                profileData.profile_type === type
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200'
              }`}
            >
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-2">Verification Status</h3>
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded text-sm ${
            profileData.verification_status === 'verified'
              ? 'bg-green-100 text-green-800'
              : profileData.verification_status === 'pending'
              ? 'bg-yellow-100 text-yellow-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {profileData.verification_status.toUpperCase()}
          </span>
          {profileData.verification_status === 'unverified' && (
            <button
              onClick={() => onVerificationRequest(profileData.profile_type)}
              className="text-blue-600 text-sm hover:underline"
            >
              Request Verification
            </button>
          )}
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Custom Fields</h3>
        <div className="space-y-4">
          {Object.entries(profileData.custom_fields || {}).map(([key, value]) => (
            <div key={key} className="flex justify-between items-center">
              <span className="font-medium">{key}</span>
              <span>{value}</span>
            </div>
          ))}
          {isEditing && (
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Field name"
                value={customField.key}
                onChange={(e) => onCustomFieldChange({ ...customField, key: e.target.value })}
                className="border rounded px-2 py-1"
              />
              <input
                type="text"
                placeholder="Field value"
                value={customField.value}
                onChange={(e) => onCustomFieldChange({ ...customField, value: e.target.value })}
                className="border rounded px-2 py-1"
              />
              <button
                onClick={onAddCustomField}
                className="bg-blue-600 text-white px-3 py-1 rounded"
              >
                Add
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Profile Tags</h3>
        <div className="flex flex-wrap gap-2">
          {profileData.profile_tags?.map(tag => (
            <span key={tag} className="bg-gray-100 px-2 py-1 rounded">
              {tag}
            </span>
          ))}
          {isEditing && (
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="New tag"
                value={newTag}
                onChange={(e) => onNewTagChange(e.target.value)}
                className="border rounded px-2 py-1"
              />
              <button
                onClick={onAddProfileTag}
                className="bg-blue-600 text-white px-3 py-1 rounded"
              >
                Add
              </button>
            </div>
          )}
        </div>
      </div>

      <button
        onClick={onEditToggle}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        {isEditing ? 'Save Changes' : 'Edit Profile'}
      </button>
    </div>
  );
}

function StoryComponent() {
  const [isEditing, setIsEditing] = useState(false);
  const [customField, setCustomField] = useState({ key: '', value: '' });
  const [newTag, setNewTag] = useState('');
  const [error, setError] = useState(null);

  const mockProfileData = {
    completionPercentage: 75,
    profile_type: 'personal',
    verification_status: 'unverified',
    custom_fields: {
      'Favorite Color': 'Blue',
      'Preferred Language': 'English'
    },
    profile_tags: ['Travel', 'Photography', 'Food']
  };

  return (
    <div className="p-6 bg-gray-100">
      <h2 className="text-2xl font-bold mb-6">Profile Enhancement Component</h2>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Default State</h3>
        <MainComponent
          loading={false}
          profileData={mockProfileData}
          error={null}
          isEditing={false}
          customField={{ key: '', value: '' }}
          newTag=""
          onProfileUpdate={() => {}}
          onVerificationRequest={() => {}}
          onAddCustomField={() => {}}
          onAddProfileTag={() => {}}
          onEditToggle={() => {}}
          onCustomFieldChange={() => {}}
          onNewTagChange={() => {}}
        />
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Loading State</h3>
        <MainComponent
          loading={true}
          profileData={null}
          error={null}
          isEditing={false}
          customField={{ key: '', value: '' }}
          newTag=""
          onProfileUpdate={() => {}}
          onVerificationRequest={() => {}}
          onAddCustomField={() => {}}
          onAddProfileTag={() => {}}
          onEditToggle={() => {}}
          onCustomFieldChange={() => {}}
          onNewTagChange={() => {}}
        />
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Error State</h3>
        <MainComponent
          loading={false}
          profileData={mockProfileData}
          error="Failed to load profile data"
          isEditing={false}
          customField={{ key: '', value: '' }}
          newTag=""
          onProfileUpdate={() => {}}
          onVerificationRequest={() => {}}
          onAddCustomField={() => {}}
          onAddProfileTag={() => {}}
          onEditToggle={() => {}}
          onCustomFieldChange={() => {}}
          onNewTagChange={() => {}}
        />
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-4">Editing State</h3>
        <MainComponent
          loading={false}
          profileData={mockProfileData}
          error={null}
          isEditing={true}
          customField={{ key: '', value: '' }}
          newTag=""
          onProfileUpdate={() => {}}
          onVerificationRequest={() => {}}
          onAddCustomField={() => {}}
          onAddProfileTag={() => {}}
          onEditToggle={() => {}}
          onCustomFieldChange={() => {}}
          onNewTagChange={() => {}}
        />
      </div>
    </div>
  );
});
}