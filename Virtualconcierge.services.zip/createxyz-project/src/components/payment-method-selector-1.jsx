"use client";
import React from "react";



export default function Index() {
  return (function MainComponent() {
  const PaymentMethodSelector = ({ onSelect, selected }) => {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          <input
            type="radio"
            id="card"
            name="payment"
            value="card"
            checked={selected === "card"}
            onChange={(e) => onSelect(e.target.value)}
            className="h-4 w-4 text-blue-600"
          />
          <label htmlFor="card" className="flex items-center space-x-2">
            <span>Credit Card</span>
            <div className="flex space-x-1">
              <i className="fab fa-cc-visa text-blue-600"></i>
              <i className="fab fa-cc-mastercard text-red-600"></i>
              <i className="fab fa-cc-amex text-blue-400"></i>
            </div>
          </label>
        </div>
      </div>
    );
  };

  return PaymentMethodSelector;
}

function StoryComponent() {
  const PaymentMethodSelector = MainComponent();
  const [selectedMethod, setSelectedMethod] = useState("card");

  return (
    <div className="p-6 space-y-8">
      <div>
        <h2 className="text-lg font-bold mb-4">Default State</h2>
        <PaymentMethodSelector
          selected={selectedMethod}
          onSelect={setSelectedMethod}
        />
      </div>

      <div>
        <h2 className="text-lg font-bold mb-4">Empty Selection</h2>
        <PaymentMethodSelector selected="" onSelect={() => {}} />
      </div>
    </div>
  );
});
}