"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ companyName = "Virtual Concierge", email = "Contactus@virtualconcierge.services" }) {
  return (
    <footer className="bg-[#4F5D75] text-white py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-crimson-text text-xl font-bold mb-4">
              {companyName}
            </h3>
            <p className="text-gray-300">Your AI-powered travel companion</p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Features</h4>
            <ul className="space-y-2">
              <li>
                <a href="/ai-assistant" className="text-gray-300 hover:text-white transition-colors">
                  AI Assistant
                </a>
              </li>
              <li>
                <a href="/translation" className="text-gray-300 hover:text-white transition-colors">
                  Translation Services
                </a>
              </li>
              <li>
                <a href="/recommendations" className="text-gray-300 hover:text-white transition-colors">
                  Local Recommendations
                </a>
              </li>
              <li>
                <a href="/planning" className="text-gray-300 hover:text-white transition-colors">
                  Travel Planning
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <a href="/about" className="text-gray-300 hover:text-white transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href={`mailto:${email}`} className="text-gray-300 hover:text-white transition-colors">
                  <i className="fas fa-envelope mr-2"></i>
                  {email}
                </a>
              </li>
              <li>
                <a href="/privacy" className="text-gray-300 hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms" className="text-gray-300 hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Connect</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-linkedin text-xl"></i>
              </a>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-gray-700 text-center text-gray-300">
          <p>&copy; 2025 {companyName}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

function StoryComponent() {
  return (
    <div>
      <MainComponent />
      <MainComponent 
        companyName="Travel Corp"
        email="contact@travelcorp.com"
      />
    </div>
  );
});
}