"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  isOpen,
  onClose,
  items = [],
  onUpdateQuantity,
  onCheckout,
  loading = false,
  error = null,
  onRetry = () => {},
}) {
  const [updateError, setUpdateError] = useState(null);

  const totalAmount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [items]);

  const handleQuantityChange = useCallback(
    async (itemId, newQuantity) => {
      try {
        setUpdateError(null);
        await onUpdateQuantity(itemId, newQuantity);
      } catch (err) {
        console.error(err);
        setUpdateError("Failed to update quantity");
      }
    },
    [onUpdateQuantity],
  );

  if (error) {
    return (
      <div
        className={`fixed inset-y-0 right-0 w-full md:w-[400px] bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex justify-between items-center p-4 border-b">
            <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold">
              Your Cart
            </h2>
            <button
              onClick={onClose}
              className="text-[#475569] hover:text-[#1e293b] transition-colors"
            >
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center p-4">
              <div className="text-red-600 mb-4">
                <i className="fas fa-exclamation-circle text-4xl"></i>
              </div>
              <p className="text-[#1e293b] mb-4">Error loading cart: {error}</p>
              <button
                onClick={onRetry}
                className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`fixed inset-y-0 right-0 w-full md:w-[400px] bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
        isOpen ? "translate-x-0" : "translate-x-full"
      }`}
    >
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold">
            Your Cart
          </h2>
          <button
            onClick={onClose}
            className="text-[#475569] hover:text-[#1e293b] transition-colors"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>

        {updateError && (
          <div className="p-4 bg-red-100 text-red-700 text-sm">
            {updateError}
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#3b82f6]"></div>
            </div>
          ) : items.length === 0 ? (
            <div className="text-center text-[#475569] py-8">
              Your cart is empty
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 bg-[#f8fafc] p-4 rounded-lg"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-crimson-text text-[#1e293b] font-bold mb-1">
                    {item.name}
                  </h3>
                  <p className="text-[#3b82f6] font-bold">
                    ${item.price.toFixed(2)}
                  </p>
                  <div className="flex items-center mt-2">
                    <button
                      onClick={() =>
                        handleQuantityChange(item.id, item.quantity - 1)
                      }
                      className="text-[#475569] hover:text-[#1e293b] px-2"
                      disabled={item.quantity <= 1}
                    >
                      <i className="fas fa-minus"></i>
                    </button>
                    <span className="mx-2 font-bold text-[#1e293b]">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        handleQuantityChange(item.id, item.quantity + 1)
                      }
                      className="text-[#475569] hover:text-[#1e293b] px-2"
                    >
                      <i className="fas fa-plus"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="border-t p-4 bg-white">
          <div className="flex justify-between items-center mb-4">
            <span className="text-lg font-crimson-text text-[#1e293b]">
              Total
            </span>
            <span className="text-xl font-bold text-[#1e293b]">
              ${totalAmount.toFixed(2)}
            </span>
          </div>
          <button
            onClick={onCheckout}
            disabled={items.length === 0 || loading}
            className="w-full bg-[#3b82f6] text-white py-3 rounded-full hover:bg-[#2563eb] transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed font-bold"
          >
            {loading ? "Loading..." : "Proceed to Checkout"}
          </button>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const [isOpen, setIsOpen] = useState(true);
  const [items, setItems] = useState([
    {
      id: 1,
      name: "Beach Tour Package",
      price: 99.99,
      quantity: 2,
      image:
        "https://ucarecdn.com/e8024184-bb47-41b7-b088-36ab39c18a9d/-/format/auto/",
    },
    {
      id: 2,
      name: "City Walking Tour",
      price: 49.99,
      quantity: 1,
      image:
        "https://ucarecdn.com/66b57df7-88b7-47c3-89f2-9df5b8803e6e/-/format/auto/",
    },
  ]);

  const handleUpdateQuantity = useCallback((itemId, newQuantity) => {
    setItems((prev) =>
      prev
        .map((item) =>
          item.id === itemId
            ? { ...item, quantity: Math.max(0, newQuantity) }
            : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }, []);

  return (
    <div className="h-screen bg-gray-100 p-4">
      <div className="space-y-4">
        <div>
          <h3 className="font-bold mb-2">Normal State:</h3>
          <button
            onClick={() => setIsOpen(true)}
            className="bg-[#3b82f6] text-white px-6 py-2 rounded-full"
          >
            Open Cart
          </button>

          <MainComponent
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            items={items}
            onUpdateQuantity={handleUpdateQuantity}
            onCheckout={() => alert("Proceeding to checkout...")}
          />
        </div>

        <div>
          <h3 className="font-bold mb-2">Loading State:</h3>
          <MainComponent
            isOpen={true}
            onClose={() => {}}
            items={[]}
            loading={true}
            onUpdateQuantity={() => {}}
            onCheckout={() => {}}
          />
        </div>

        <div>
          <h3 className="font-bold mb-2">Error State:</h3>
          <MainComponent
            isOpen={true}
            onClose={() => {}}
            items={[]}
            error="Failed to load cart items"
            onRetry={() => alert("Retrying...")}
            onUpdateQuantity={() => {}}
            onCheckout={() => {}}
          />
        </div>

        <div>
          <h3 className="font-bold mb-2">Empty State:</h3>
          <MainComponent
            isOpen={true}
            onClose={() => {}}
            items={[]}
            onUpdateQuantity={() => {}}
            onCheckout={() => {}}
          />
        </div>
      </div>
    </div>
  );
});
}