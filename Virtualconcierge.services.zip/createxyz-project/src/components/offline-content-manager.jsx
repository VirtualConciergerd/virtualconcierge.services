"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ guideId, guideName, guideSize }) {
  const { data: user } = useUser();
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState("idle");
  const [error, setError] = useState(null);
  const [isDownloaded, setIsDownloaded] = useState(false);

  useEffect(() => {
    checkDownloadStatus();
  }, [guideId]);

  const checkDownloadStatus = async () => {
    try {
      const response = await fetch("/api/offline-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "checkStatus",
          guideId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setIsDownloaded(data.isDownloaded);
      }
    } catch (err) {
      console.error("Failed to check download status:", err);
    }
  };

  const handleDownload = async () => {
    try {
      setDownloadStatus("downloading");
      setError(null);

      const response = await fetch("/api/offline-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "initializeDownload",
          guideId,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to initialize download");
      }

      const { downloadUrl, encryptionKey } = await response.json();

      const contentResponse = await fetch(downloadUrl);
      const reader = contentResponse.body.getReader();
      const contentLength = +contentResponse.headers.get("Content-Length");

      let receivedLength = 0;
      const chunks = [];

      while (true) {
        const { done, value } = await reader.read();

        if (done) {
          break;
        }

        chunks.push(value);
        receivedLength += value.length;
        setDownloadProgress((receivedLength / contentLength) * 100);
      }

      const content = new Blob(chunks);
      const encryptedContent = await encryptContent(content, encryptionKey);

      await storeContent(guideId, encryptedContent, encryptionKey);

      await fetch("/api/offline-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "completeDownload",
          guideId,
        }),
      });

      setDownloadStatus("completed");
      setIsDownloaded(true);
    } catch (err) {
      console.error("Download failed:", err);
      setError("Failed to download content. Please try again.");
      setDownloadStatus("error");
    }
  };

  const handleDelete = async () => {
    try {
      await fetch("/api/offline-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "deleteContent",
          guideId,
        }),
      });

      await deleteContent(guideId);

      setIsDownloaded(false);
      setDownloadStatus("idle");
    } catch (err) {
      console.error("Failed to delete content:", err);
      setError("Failed to delete content. Please try again.");
    }
  };

  const encryptContent = async (content, key) => {
    const buffer = await content.arrayBuffer();
    const iv = crypto.getRandomValues(new Uint8Array.from({length: 12}));
    const encodedKey = new TextEncoder().encode(key);

    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      encodedKey,
      "AES-GCM",
      false,
      ["encrypt"],
    );

    const encryptedContent = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv,
      },
      cryptoKey,
      buffer,
    );

    return {
      content: encryptedContent,
      iv,
    };
  };

  const storeContent = async (guideId, encryptedData, key) => {
    const db = await openDB();
    await db.put("offlineContent", {
      guideId,
      content: encryptedData.content,
      iv: encryptedData.iv,
      key,
      timestamp: Date.now(),
    });
  };

  const deleteContent = async (guideId) => {
    const db = await openDB();
    await db.delete("offlineContent", guideId);
  };

  const openDB = () => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("offlineGuides", 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains("offlineContent")) {
          db.createObjectStore("offlineContent", { keyPath: "guideId" });
        }
      };
    });
  };

  return (
    <div className="border rounded-lg p-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{guideName}</h3>
          <p className="text-sm text-gray-600">
            Size: {(guideSize / 1024 / 1024).toFixed(2)}MB
          </p>
        </div>

        {!isDownloaded ? (
          <button
            onClick={handleDownload}
            disabled={downloadStatus === "downloading"}
            className={`px-4 py-2 rounded-lg ${
              downloadStatus === "downloading"
                ? "bg-gray-300 cursor-not-allowed"
                : "bg-primary text-white"
            }`}
          >
            {downloadStatus === "downloading"
              ? "Downloading..."
              : "Download for Offline"}
          </button>
        ) : (
          <button
            onClick={handleDelete}
            className="px-4 py-2 rounded-lg border border-red-500 text-red-500"
          >
            Delete Download
          </button>
        )}
      </div>

      {downloadStatus === "downloading" && (
        <div className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${downloadProgress}%` }}
            />
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {downloadProgress.toFixed(1)}% downloaded
          </p>
        </div>
      )}

      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-4 space-y-4">
      <MainComponent
        guideId="guide-1"
        guideName="Bangkok City Guide"
        guideSize={15728640}
      />

      <MainComponent
        guideId="guide-2"
        guideName="Tokyo Travel Guide"
        guideSize={20971520}
      />

      <MainComponent
        guideId="guide-3"
        guideName="Paris Walking Tours"
        guideSize={10485760}
      />
    </div>
  );
});
}