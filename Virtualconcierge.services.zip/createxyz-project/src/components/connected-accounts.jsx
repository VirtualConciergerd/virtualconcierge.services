"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  accounts = [],
  onConnect,
  onDisconnect,
  loading = false,
  error = null
}) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
        Connected Accounts
      </h2>

      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
        </div>
      ) : accounts.length === 0 ? (
        <div className="text-center py-8 text-[#475569]">
          <i className="fas fa-link-slash text-4xl mb-4"></i>
          <p>No accounts connected yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {accounts.map((account) => (
            <div
              key={account.provider}
              className="border rounded-lg p-4 flex items-center justify-between"
            >
              <div className="flex items-center space-x-4">
                <div className="text-2xl text-[#3b82f6]">
                  <i className={`fab fa-${account.provider.toLowerCase()}`}></i>
                </div>
                <div>
                  <div className="font-medium text-[#1e293b]">
                    {account.provider}
                  </div>
                  <div className="text-sm text-[#475569]">
                    {account.email || account.username}
                  </div>
                  <div className="text-xs text-[#64748b]">
                    Last login: {account.lastLogin}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    account.verified
                      ? "bg-green-100 text-green-800"
                      : "bg-yellow-100 text-yellow-800"
                  }`}
                >
                  {account.verified ? "Verified" : "Unverified"}
                </span>

                <button
                  onClick={() =>
                    account.connected
                      ? onDisconnect(account.provider)
                      : onConnect(account.provider)
                  }
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    account.connected
                      ? "bg-red-100 text-red-700 hover:bg-red-200"
                      : "bg-[#3b82f6] text-white hover:bg-[#2563eb]"
                  }`}
                >
                  {account.connected ? "Disconnect" : "Connect"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const mockAccounts = [
    {
      provider: "Google",
      connected: true,
      verified: true,
      email: "user@gmail.com",
      lastLogin: "2025-01-15 14:30",
    },
    {
      provider: "Facebook",
      connected: true,
      verified: false,
      username: "johndoe",
      lastLogin: "2025-01-10 09:15",
    },
    {
      provider: "Twitter",
      connected: false,
      verified: false,
      username: null,
      lastLogin: null,
    },
  ];

  return (
    <div className="p-8 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] min-h-screen">
      <div className="max-w-3xl mx-auto space-y-8">
        <MainComponent
          accounts={mockAccounts}
          onConnect={(provider) => console.log(`Connect ${provider}`)}
          onDisconnect={(provider) => console.log(`Disconnect ${provider}`)}
          loading={false}
          error={null}
        />

        <MainComponent
          accounts={[]}
          onConnect={(provider) => console.log(`Connect ${provider}`)}
          onDisconnect={(provider) => console.log(`Disconnect ${provider}`)}
          loading={false}
          error={null}
        />

        <MainComponent
          accounts={mockAccounts}
          onConnect={(provider) => console.log(`Connect ${provider}`)}
          onDisconnect={(provider) => console.log(`Disconnect ${provider}`)}
          loading={true}
          error={null}
        />

        <MainComponent
          accounts={mockAccounts}
          onConnect={(provider) => console.log(`Connect ${provider}`)}
          onDisconnect={(provider) => console.log(`Disconnect ${provider}`)}
          loading={false}
          error="Failed to load connected accounts"
        />
      </div>
    </div>
  );
});
}