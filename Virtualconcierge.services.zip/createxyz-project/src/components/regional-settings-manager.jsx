"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  initialSettings = {
    date_format: 'MM/DD/YYYY',
    time_format: '12h',
    first_day_of_week: 'sunday',
    calendar_type: 'gregorian',
    show_holidays: true,
    preferred_holidays: []
  },
  onSave,
  loading = false,
  error = null
}) {
  const [settings, setSettings] = useState(initialSettings);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSave(settings);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
        Regional Settings
      </h2>

      {error && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-[#1e293b] mb-2">
            Date Format
          </label>
          <select
            value={settings.date_format}
            onChange={(e) => setSettings({ ...settings, date_format: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
            disabled={loading || isSaving}
          >
            <option value="MM/DD/YYYY">MM/DD/YYYY</option>
            <option value="DD/MM/YYYY">DD/MM/YYYY</option>
            <option value="YYYY-MM-DD">YYYY-MM-DD</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-[#1e293b] mb-2">
            Time Format
          </label>
          <select
            value={settings.time_format}
            onChange={(e) => setSettings({ ...settings, time_format: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
            disabled={loading || isSaving}
          >
            <option value="12h">12-hour</option>
            <option value="24h">24-hour</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-[#1e293b] mb-2">
            First Day of Week
          </label>
          <select
            value={settings.first_day_of_week}
            onChange={(e) => setSettings({ ...settings, first_day_of_week: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
            disabled={loading || isSaving}
          >
            <option value="sunday">Sunday</option>
            <option value="monday">Monday</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-[#1e293b] mb-2">
            Calendar Type
          </label>
          <select
            value={settings.calendar_type}
            onChange={(e) => setSettings({ ...settings, calendar_type: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
            disabled={loading || isSaving}
          >
            <option value="gregorian">Gregorian</option>
            <option value="lunar">Lunar</option>
            <option value="islamic">Islamic</option>
          </select>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="show_holidays"
            checked={settings.show_holidays}
            onChange={(e) => setSettings({ ...settings, show_holidays: e.target.checked })}
            className="h-4 w-4 text-[#3b82f6] focus:ring-[#3b82f6] border-gray-300 rounded"
            disabled={loading || isSaving}
          />
          <label htmlFor="show_holidays" className="ml-2 block text-sm text-[#1e293b]">
            Show Holidays
          </label>
        </div>

        <button
          type="submit"
          disabled={loading || isSaving}
          className="inline-block bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Saving...
            </>
          ) : (
            'Save Settings'
          )}
        </button>
      </form>
    </div>
  );
}

function StoryComponent() {
  const [demoSettings, setDemoSettings] = useState({
    date_format: 'MM/DD/YYYY',
    time_format: '12h',
    first_day_of_week: 'sunday',
    calendar_type: 'gregorian',
    show_holidays: true,
    preferred_holidays: []
  });

  const handleSave = async (newSettings) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        setDemoSettings(newSettings);
        resolve();
      }, 1000);
    });
  };

  return (
    <div className="p-4 space-y-8">
      <div>
        <h3 className="text-lg font-bold mb-4">Default State</h3>
        <MainComponent onSave={handleSave} initialSettings={demoSettings} />
      </div>

      <div>
        <h3 className="text-lg font-bold mb-4">Loading State</h3>
        <MainComponent onSave={handleSave} loading={true} />
      </div>

      <div>
        <h3 className="text-lg font-bold mb-4">Error State</h3>
        <MainComponent
          onSave={handleSave}
          error="Failed to load regional settings. Please try again."
        />
      </div>
    </div>
  );
});
}