"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  onRefresh,
  environmentConfig = {
    NODE_ENV: "",
    DATABASE_URL: "",
    AUTH_SECRET: "",
    PIXABAY_API_KEY: "",
    REPLICATE_API_TOKEN: "",
    EMAIL_SERVICE_API_KEY: "",
    RATE_LIMIT_MAX: "",
    QUEUE_MAX_SIZE: "",
  },
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [configStatus, setConfigStatus] = useState(null);

  const validateConfig = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/environment-config", {
        method: "POST",
        body: JSON.stringify(environmentConfig),
      });

      if (!response.ok) {
        throw new Error("Failed to validate configuration");
      }

      const status = await response.json();
      setConfigStatus(status);

      if (onRefresh) {
        onRefresh(status);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to validate configuration");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    validateConfig();
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold">
          Configuration Manager
        </h2>
        <button
          onClick={validateConfig}
          disabled={loading}
          className="bg-[#3b82f6] text-white px-4 py-2 rounded hover:bg-[#2563eb] transition-colors disabled:opacity-50"
        >
          {loading ? (
            <i className="fas fa-spinner fa-spin"></i>
          ) : (
            <i className="fas fa-sync-alt"></i>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {configStatus && (
        <div>
          <div className="flex items-center mb-6">
            <div
              className={`w-3 h-3 rounded-full mr-2 ${
                configStatus.valid ? "bg-green-500" : "bg-red-500"
              }`}
            ></div>
            <span className="text-lg font-medium text-[#1e293b]">
              {configStatus.valid
                ? "Configuration Valid"
                : "Configuration Invalid"}
            </span>
          </div>

          {configStatus.missing?.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-medium text-[#1e293b] mb-2">
                Missing Variables
              </h3>
              <ul className="bg-yellow-50 rounded p-4 space-y-2">
                {configStatus.missing.map((variable) => (
                  <li key={variable} className="text-yellow-800">
                    <i className="fas fa-exclamation-triangle mr-2"></i>
                    {variable}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {configStatus.invalid?.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-medium text-[#1e293b] mb-2">
                Invalid Variables
              </h3>
              <ul className="bg-red-50 rounded p-4 space-y-2">
                {configStatus.invalid.map((variable) => (
                  <li key={variable} className="text-red-800">
                    <i className="fas fa-times-circle mr-2"></i>
                    {variable}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="border rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Variable
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Environment
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {Object.entries(environmentConfig).map(([key, value]) => (
                  <tr key={key}>
                    <td className="px-6 py-4 text-sm text-[#1e293b]">{key}</td>
                    <td className="px-6 py-4">
                      {value ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <i className="fas fa-check-circle mr-1"></i>
                          Set
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          <i className="fas fa-times-circle mr-1"></i>
                          Not Set
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-[#475569]">
                      {key === "NODE_ENV" ? value || "development" : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  // Development preset
  const devConfig = {
    NODE_ENV: "development",
    DATABASE_URL: "postgres://user:password@localhost:5432/mydb",
    AUTH_SECRET: "dev_secret_key_must_be_at_least_32_chars",
    PIXABAY_API_KEY: "",
    REPLICATE_API_TOKEN: "",
    EMAIL_SERVICE_API_KEY: "dev_email_key",
    RATE_LIMIT_MAX: "100",
    QUEUE_MAX_SIZE: "50",
  };

  // Production preset
  const prodConfig = {
    NODE_ENV: "production",
    DATABASE_URL: "postgres://prod_user:password@prod-db:5432/prod_db",
    AUTH_SECRET: "prod_secret_key_must_be_at_least_32_chars",
    PIXABAY_API_KEY: "valid_api_key_40_chars_long_for_pixabay_here",
    REPLICATE_API_TOKEN: "r8_valid_token",
    EMAIL_SERVICE_API_KEY: "prod_email_key",
    RATE_LIMIT_MAX: "1000",
    QUEUE_MAX_SIZE: "500",
  };

  return (
    <div className="p-8 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] min-h-screen space-y-8">
      <div>
        <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
          Development Environment
        </h2>
        <MainComponent
          environmentConfig={devConfig}
          onRefresh={(status) => console.log("Dev config status:", status)}
        />
      </div>

      <div>
        <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
          Production Environment
        </h2>
        <MainComponent
          environmentConfig={prodConfig}
          onRefresh={(status) => console.log("Prod config status:", status)}
        />
      </div>
    </div>
  );
});
}