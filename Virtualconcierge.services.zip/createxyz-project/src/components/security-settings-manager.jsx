"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  onAddSecurityQuestion, 
  onRemoveSecurityQuestion, 
  onRemoveDevice,
  securityQuestions = [],
  trustedDevices = [],
  loading = false,
  error = null 
}) {
  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center p-8">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
        </div>
      ) : (
        <>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium mb-4">Security Questions</h3>
            <div className="space-y-4">
              {securityQuestions.map((q, i) => (
                <div key={i} className="flex justify-between items-center">
                  <span>{q.question}</span>
                  <button
                    onClick={() => onRemoveSecurityQuestion(q.id)}
                    className="text-red-600 hover:text-red-800 transition-colors"
                  >
                    <i className="fas fa-trash-alt mr-2"></i>
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={onAddSecurityQuestion}
                className="w-full bg-[#3b82f6] text-white py-2 px-4 rounded hover:bg-[#2563eb] transition-colors flex items-center justify-center"
              >
                <i className="fas fa-plus-circle mr-2"></i>
                Add Security Question
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium mb-4">Trusted Devices</h3>
            <div className="space-y-4">
              {trustedDevices.map(device => (
                <div key={device.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium flex items-center">
                      <i className={`fas fa-${device.device_type === 'mobile' ? 'mobile-alt' : 'laptop'} mr-2 text-gray-600`}></i>
                      {device.device_name}
                    </p>
                    <p className="text-sm text-gray-500">
                      Last used: {new Date(device.last_used).toLocaleDateString()}
                    </p>
                  </div>
                  <button
                    onClick={() => onRemoveDevice(device.id)}
                    className="text-red-600 hover:text-red-800 transition-colors"
                  >
                    <i className="fas fa-times-circle mr-2"></i>
                    Remove
                  </button>
                </div>
              ))}
              {trustedDevices.length === 0 && (
                <p className="text-center text-gray-500 py-4">
                  No trusted devices found
                </p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StoryComponent() {
  const [securityQuestions, setSecurityQuestions] = useState([
    { id: 1, question: "What was your first pet's name?" },
    { id: 2, question: "In what city were you born?" }
  ]);

  const [trustedDevices, setTrustedDevices] = useState([
    {
      id: 1,
      device_name: "iPhone 12",
      device_type: "mobile",
      last_used: "2025-01-15T10:30:00Z"
    },
    {
      id: 2,
      device_name: "MacBook Pro",
      device_type: "desktop",
      last_used: "2025-01-14T15:45:00Z"
    }
  ]);

  // Example handlers
  const handleAddSecurityQuestion = () => {
    console.log("Add security question clicked");
  };

  const handleRemoveSecurityQuestion = (id) => {
    setSecurityQuestions(questions => questions.filter(q => q.id !== id));
  };

  const handleRemoveDevice = (id) => {
    setTrustedDevices(devices => devices.filter(d => d.id !== id));
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h2 className="text-2xl font-bold mb-6">Security Settings</h2>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Normal State</h3>
        <MainComponent
          securityQuestions={securityQuestions}
          trustedDevices={trustedDevices}
          onAddSecurityQuestion={handleAddSecurityQuestion}
          onRemoveSecurityQuestion={handleRemoveSecurityQuestion}
          onRemoveDevice={handleRemoveDevice}
        />
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Loading State</h3>
        <MainComponent
          loading={true}
          securityQuestions={[]}
          trustedDevices={[]}
          onAddSecurityQuestion={() => {}}
          onRemoveSecurityQuestion={() => {}}
          onRemoveDevice={() => {}}
        />
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Error State</h3>
        <MainComponent
          error="Failed to load security settings"
          securityQuestions={[]}
          trustedDevices={[]}
          onAddSecurityQuestion={() => {}}
          onRemoveSecurityQuestion={() => {}}
          onRemoveDevice={() => {}}
        />
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-4">Empty State</h3>
        <MainComponent
          securityQuestions={[]}
          trustedDevices={[]}
          onAddSecurityQuestion={() => {}}
          onRemoveSecurityQuestion={() => {}}
          onRemoveDevice={() => {}}
        />
      </div>
    </div>
  );
});
}