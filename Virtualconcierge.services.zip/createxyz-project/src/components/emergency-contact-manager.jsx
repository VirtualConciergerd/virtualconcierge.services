"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  initialContacts = [],
  onSave = async () => {},
  onDelete = async () => {},
  onEdit = async () => {},
}) {
  const [contacts, setContacts] = useState(initialContacts);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    relationship: '',
    phone: '',
    email: '',
    notificationPreferences: {
      loginAttempts: true,
      passwordChanges: true,
      securityEvents: true
    }
  });

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const response = await fetch('/api/manage-emergency-contacts', { method: 'POST' });
        if (!response.ok) throw new Error('Failed to fetch contacts');
        const data = await response.json();
        setContacts(data);
      } catch (error) {
        setError('Failed to load emergency contacts');
      } finally {
        setLoading(false);
      }
    };

    fetchContacts();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/manage-emergency-contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          method: editingContact ? 'PUT' : 'POST',
          body: {
            ...formData,
            id: editingContact?.id
          }
        })
      });

      if (!response.ok) throw new Error('Failed to save contact');

      await onSave(formData);
      setShowForm(false);
      setEditingContact(null);
      setFormData({
        name: '',
        relationship: '',
        phone: '',
        email: '',
        notificationPreferences: {
          loginAttempts: true,
          passwordChanges: true,
          securityEvents: true
        }
      });
    } catch (error) {
      setError('Failed to save emergency contact');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this contact?')) return;

    try {
      const response = await fetch('/api/manage-emergency-contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          method: 'DELETE',
          query: { id }
        })
      });

      if (!response.ok) throw new Error('Failed to delete contact');
      await onDelete(id);
      const updatedContacts = contacts.filter(contact => contact.id !== id);
      setContacts(updatedContacts);
    } catch (error) {
      setError('Failed to delete emergency contact');
    }
  };

  const handleEdit = (contact) => {
    setEditingContact(contact);
    setFormData({
      name: contact.name,
      relationship: contact.relationship,
      phone: contact.phone,
      email: contact.email,
      notificationPreferences: {
        loginAttempts: contact.notify_on_login_attempts,
        passwordChanges: contact.notify_on_password_changes,
        securityEvents: contact.notify_on_security_events
      }
    });
    setShowForm(true);
    onEdit(contact);
  };

  if (loading) return <div className="flex justify-center items-center p-4"><i className="fas fa-spinner fa-spin text-blue-600 text-2xl"></i></div>;

  return (
    <div className="space-y-6 bg-gray-50 p-6 rounded-lg">
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg flex items-center">
          <i className="fas fa-exclamation-circle mr-2"></i>
          {error}
        </div>
      )}

      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Emergency Contacts</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <i className={`fas fa-${showForm ? 'times' : 'plus'} mr-2`}></i>
          {showForm ? 'Cancel' : 'Add Contact'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Relationship</label>
              <input
                type="text"
                name="relationship"
                value={formData.relationship}
                onChange={(e) => setFormData({...formData, relationship: e.target.value})}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Phone</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Notification Preferences</label>
              <div className="space-y-2">
                {[
                  { key: 'loginAttempts', label: 'Notify on login attempts' },
                  { key: 'passwordChanges', label: 'Notify on password changes' },
                  { key: 'securityEvents', label: 'Notify on security events' }
                ].map(({ key, label }) => (
                  <label key={key} className="flex items-center">
                    <input
                      type="checkbox"
                      name={key}
                      checked={formData.notificationPreferences[key]}
                      onChange={(e) => setFormData({
                        ...formData,
                        notificationPreferences: {
                          ...formData.notificationPreferences,
                          [key]: e.target.checked
                        }
                      })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">{label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6">
            <button
              type="submit"
              className="w-full inline-flex justify-center items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <i className={`fas fa-${editingContact ? 'save' : 'plus'} mr-2`}></i>
              {editingContact ? 'Update Contact' : 'Add Contact'}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {contacts.map(contact => (
          <div key={contact.id} className="bg-white p-4 rounded-lg shadow-sm flex justify-between items-center">
            <div>
              <h3 className="font-medium text-gray-900">{contact.name}</h3>
              <p className="text-sm text-gray-600">{contact.relationship}</p>
              <p className="text-sm text-gray-600">
                <i className="fas fa-phone mr-2"></i>{contact.phone}
              </p>
              {contact.email && (
                <p className="text-sm text-gray-600">
                  <i className="fas fa-envelope mr-2"></i>{contact.email}
                </p>
              )}
              {contact.is_primary && (
                <span className="inline-flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mt-2">
                  <i className="fas fa-star mr-1"></i>
                  Primary Contact
                </span>
              )}
            </div>
            <div className="space-x-2">
              <button
                onClick={() => handleEdit(contact)}
                className="inline-flex items-center text-blue-600 hover:text-blue-800"
              >
                <i className="fas fa-edit mr-1"></i>
                Edit
              </button>
              <button
                onClick={() => handleDelete(contact.id)}
                className="inline-flex items-center text-red-600 hover:text-red-800"
              >
                <i className="fas fa-trash-alt mr-1"></i>
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StoryComponent() {
  const mockContacts = [
    {
      id: 1,
      name: "John Doe",
      relationship: "Brother",
      phone: "123-456-7890",
      email: "john@example.com",
      is_primary: true,
      notify_on_login_attempts: true,
      notify_on_password_changes: true,
      notify_on_security_events: true
    },
    {
      id: 2,
      name: "Jane Smith",
      relationship: "Sister",
      phone: "098-765-4321",
      email: "jane@example.com",
      is_primary: false,
      notify_on_login_attempts: false,
      notify_on_password_changes: true,
      notify_on_security_events: false
    }
  ];

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Emergency Contact Manager</h1>
      <MainComponent
        initialContacts={mockContacts}
        onSave={async (data) => console.log('Saving:', data)}
        onDelete={async (id) => console.log('Deleting:', id)}
        onEdit={async (contact) => console.log('Editing:', contact)}
      />
    </div>
  );
});
}