"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ image, name, price, onBuyNow }) {
  const formattedPrice = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative pb-[100%]">
        <img
          src={image}
          alt={`Product: ${name}`}
          className="absolute top-0 left-0 w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-crimson-text text-xl font-bold text-[#1e293b] mb-2">
          {name}
        </h3>
        <div className="flex justify-between items-center mb-4">
          <span className="text-lg font-roboto text-[#475569]">
            {formattedPrice}
          </span>
        </div>
        <button
          onClick={onBuyNow}
          className="w-full bg-[#3b82f6] text-white px-4 py-2 rounded hover:bg-[#2563eb] transition-colors font-roboto flex items-center justify-center"
        >
          <i className="fas fa-shopping-cart mr-2"></i>
          Buy Now
        </button>
      </div>
    </div>
  );
}

function StoryComponent() {
  const handleBuyNow = () => {
    console.log("Buy now clicked");
  };

  return (
    <div className="p-8 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] min-h-screen">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
        <MainComponent
          image="https://ucarecdn.com/4a2dfb50-3450-4d77-bc2b-2cf9f95d340a/-/format/auto/"
          name="Premium Resort Package"
          price={299.99}
          onBuyNow={handleBuyNow}
        />
        <MainComponent
          image="https://ucarecdn.com/3ec4320a-3d69-4366-9e7d-98da2b9ed3a3/"
          name="Beach Adventure Package"
          price={199.99}
          onBuyNow={handleBuyNow}
        />
        <MainComponent
          image="https://ucarecdn.com/e8024184-bb47-41b7-b088-36ab39c18a9d/-/format/auto/"
          name="Luxury Spa Experience"
          price={399.99}
          onBuyNow={handleBuyNow}
        />
      </div>
    </div>
  );
});
}