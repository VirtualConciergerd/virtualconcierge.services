"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ modelId, onClose }) {
  const containerRef = useRef(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionActive, setSessionActive] = useState(false);

  useEffect(() => {
    let camera, scene, renderer, model;
    let xrSessionId = null;

    const init = async () => {
      try {
        if (!navigator.xr) {
          throw new Error("WebXR not supported");
        }

        const response = await fetch("/api/ar-experience", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "getModel",
            modelId,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to load AR model");
        }

        const modelData = await response.json();
        xrSessionId = modelData.session_id;

        scene = new THREE.Scene();
        camera = new THREE.PerspectiveCamera(
          75,
          window.innerWidth / window.innerHeight,
          0.1,
          1000,
        );
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.xr.enabled = true;

        containerRef.current.appendChild(renderer.domElement);

        const light = new THREE.HemisphereLight(0xffffff, 0xbbbbff, 1);
        scene.add(light);

        const loader = new GLTFLoader();
        loader.load(modelData.model_url, (gltf) => {
          model = gltf.scene;
          model.position.set(0, 0, -1);
          scene.add(model);
          setIsLoading(false);
        });

        const arButton = ARButton.createButton(renderer, {
          requiredFeatures: ["hit-test"],
          optionalFeatures: ["dom-overlay"],
          domOverlay: { root: containerRef.current },
        });
        containerRef.current.appendChild(arButton);

        renderer.xr.addEventListener("sessionstart", () => {
          setSessionActive(true);
        });

        renderer.xr.addEventListener("sessionend", async () => {
          setSessionActive(false);

          if (xrSessionId) {
            await fetch("/api/ar-experience", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "endSession",
                sessionId: xrSessionId,
                metrics: {
                  duration: Date.now() - sessionStartTime,
                  devicePixelRatio: window.devicePixelRatio,
                  userAgent: navigator.userAgent,
                },
              }),
            });
          }
        });

        renderer.setAnimationLoop(() => {
          if (model) {
            model.rotation.y += 0.005;
          }
          renderer.render(scene, camera);
        });
      } catch (err) {
        setError(err.message);
        setIsLoading(false);
      }
    };

    init();

    return () => {
      if (renderer) {
        renderer.dispose();
        renderer.forceContextLoss();
      }
    };
  }, [modelId]);

  if (error) {
    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
        <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
          <h3 className="text-xl font-bold mb-2">Error</h3>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={onClose}
            className="w-full bg-primary text-white rounded-lg px-4 py-2"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="fixed inset-0 z-50">
      {isLoading && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
          <div className="text-white text-center">
            <div className="loading-spinner mb-4" />
            <p>Loading AR Experience...</p>
          </div>
        </div>
      )}

      {sessionActive && (
        <button
          onClick={onClose}
          className="absolute top-4 right-4 bg-white/80 p-2 rounded-full"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      )}
    </div>
  );
}

function StoryComponent() {
  const [showAR, setShowAR] = useState(false);

  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold mb-6">AR Viewer Component</h2>

      <div className="space-y-8">
        <div>
          <h3 className="text-xl font-bold mb-4">Basic Usage</h3>
          <button
            onClick={() => setShowAR(true)}
            className="bg-primary text-white px-6 py-2 rounded-lg"
          >
            Launch AR Viewer
          </button>
          {showAR && (
            <MainComponent
              modelId="sample-model-1"
              onClose={() => setShowAR(false)}
            />
          )}
        </div>

        <div>
          <h3 className="text-xl font-bold mb-4">Error State</h3>
          <MainComponent modelId="invalid-model-id" onClose={() => {}} />
        </div>
      </div>
    </div>
  );
});
}