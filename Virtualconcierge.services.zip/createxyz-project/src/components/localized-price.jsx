"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ amount, currency = "USD", showVAT = true }) {
  const currencyFormats = {
    USD: { locale: "en-US", currency: "USD" },
    CAD: { locale: "en-CA", currency: "CAD" },
    MXN: { locale: "es-MX", currency: "MXN" },
    BRL: { locale: "pt-BR", currency: "BRL" },
  };

  const format = currencyFormats[currency] || currencyFormats.USD;

  const formatter = new Intl.NumberFormat(format.locale, {
    style: "currency",
    currency: format.currency,
  });

  return (
    <span className="inline-flex items-center">
      <span className="font-semibold">{formatter.format(amount)}</span>
      {showVAT && (
        <span className="text-sm text-gray-500 ml-1">(Including VAT)</span>
      )}
    </span>
  );
}

function StoryComponent() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-lg font-bold mb-4">Default (USD)</h2>
        <MainComponent amount={99.99} />
      </div>

      <div>
        <h2 className="text-lg font-bold mb-4">CAD without VAT</h2>
        <MainComponent amount={129.99} currency="CAD" showVAT={false} />
      </div>

      <div>
        <h2 className="text-lg font-bold mb-4">MXN with VAT</h2>
        <MainComponent amount={1999.99} currency="MXN" />
      </div>

      <div>
        <h2 className="text-lg font-bold mb-4">BRL with VAT</h2>
        <MainComponent amount={499.99} currency="BRL" />
      </div>
    </div>
  );
});
}