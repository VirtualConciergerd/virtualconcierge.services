"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  plans = [],
  onSelectPlan,
  selectedPlanId = null,
  loading = false,
  error = null,
  currency = "USD",
  primaryColor = "#3b82f6",
  className = "",
}) {
  const formatPrice = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
        {error}
      </div>
    );
  }

  return (
    <div className={`grid gap-8 md:grid-cols-3 ${className}`}>
      {plans.map((plan) => (
        <div
          key={plan.id}
          className={`bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl ${
            plan.popular ? "border-2 border-[#3b82f6] relative" : ""
          }`}
        >
          {plan.popular && (
            <div className="absolute top-0 right-0 bg-[#3b82f6] text-white px-4 py-1 text-sm rounded-bl-lg">
              Most Popular
            </div>
          )}
          <div className="p-6">
            <h3 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-2">
              {plan.name}
            </h3>
            <div className="mb-4">
              <span className="text-3xl font-bold text-[#1e293b]">
                {formatPrice(plan.price)}
              </span>
              {plan.interval && (
                <span className="text-[#475569]">/{plan.interval}</span>
              )}
            </div>
            <p className="text-[#475569] mb-6">{plan.description}</p>
            <ul className="space-y-3 mb-6">
              {plan.features?.map((feature, index) => (
                <li key={index} className="flex items-start text-[#475569]">
                  <i
                    className={`fas fa-check mr-2 mt-1 ${
                      feature.enabled ? "text-green-500" : "text-gray-300"
                    }`}
                  ></i>
                  <span
                    className={
                      feature.enabled ? "text-[#1e293b]" : "text-gray-400"
                    }
                  >
                    {feature.name}
                  </span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => onSelectPlan(plan.id)}
              className={`w-full py-3 px-6 rounded-lg text-white font-roboto transition-colors ${
                selectedPlanId === plan.id
                  ? "bg-green-500 hover:bg-green-600"
                  : "bg-[#3b82f6] hover:bg-[#2563eb]"
              }`}
            >
              {selectedPlanId === plan.id ? "Selected" : "Select Plan"}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

function StoryComponent() {
  const [selectedPlan, setSelectedPlan] = useState(null);

  const samplePlans = [
    {
      id: "basic",
      name: "Basic",
      price: 29.99,
      interval: "month",
      description: "Perfect for getting started",
      popular: false,
      features: [
        { name: "24/7 Virtual Concierge", enabled: true },
        { name: "Basic Travel Guides", enabled: true },
        { name: "Standard Support", enabled: true },
        { name: "Priority Access", enabled: false },
        { name: "Offline Access", enabled: false },
      ],
    },
    {
      id: "pro",
      name: "Professional",
      price: 59.99,
      interval: "month",
      description: "Most popular for travelers",
      popular: true,
      features: [
        { name: "24/7 Virtual Concierge", enabled: true },
        { name: "Premium Travel Guides", enabled: true },
        { name: "Priority Support", enabled: true },
        { name: "Priority Access", enabled: true },
        { name: "Offline Access", enabled: false },
      ],
    },
    {
      id: "enterprise",
      name: "Enterprise",
      price: 99.99,
      interval: "month",
      description: "For serious travel businesses",
      popular: false,
      features: [
        { name: "24/7 Virtual Concierge", enabled: true },
        { name: "Premium Travel Guides", enabled: true },
        { name: "Dedicated Support", enabled: true },
        { name: "Priority Access", enabled: true },
        { name: "Offline Access", enabled: true },
      ],
    },
  ];

  return (
    <div className="p-8 bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-crimson-text font-bold text-center text-[#1e293b] mb-12">
          Choose Your Premium Plan
        </h2>

        <MainComponent
          plans={samplePlans}
          onSelectPlan={setSelectedPlan}
          selectedPlanId={selectedPlan}
        />

        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">Component States:</h3>

          <div className="space-y-8">
            <div>
              <h4 className="text-lg font-semibold mb-2">Loading State:</h4>
              <MainComponent loading={true} plans={[]} />
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-2">Error State:</h4>
              <MainComponent
                error="Failed to load premium plans. Please try again later."
                plans={[]}
              />
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-2">Empty State:</h4>
              <MainComponent plans={[]} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
}