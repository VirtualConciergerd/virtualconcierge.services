"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  bookings = [],
  view = "month",
  onViewChange,
  onBookingSelect,
  onBookingDrop,
  selectedDate = new Date(),
  onDateSelect,
}) {
  const [draggedBooking, setDraggedBooking] = useState(null);
  const [currentDate, setCurrentDate] = useState(selectedDate);

  const bookingTypes = {
    tour: { color: "bg-blue-200 border-blue-500", icon: "fa-mountain" },
    hotel: { color: "bg-green-200 border-green-500", icon: "fa-hotel" },
    activity: { color: "bg-purple-200 border-purple-500", icon: "fa-hiking" },
    transport: { color: "bg-yellow-200 border-yellow-500", icon: "fa-car" },
  };

  const statusIcons = {
    confirmed: "fa-check text-green-500",
    pending: "fa-clock text-yellow-500",
    cancelled: "fa-times text-red-500",
  };

  const getDaysInMonth = (date) => {
    const start = new Date(date.getFullYear(), date.getMonth(), 1);
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    const days = [];
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      days.push(new Date(d));
    }
    return days;
  };

  const handleDragStart = (booking) => {
    setDraggedBooking(booking);
  };

  const handleDrop = (date) => {
    if (draggedBooking && onBookingDrop) {
      onBookingDrop(draggedBooking, date);
    }
    setDraggedBooking(null);
  };

  const timeSlots = Array.from(
    { length: 24 },
    (_, i) => `${String(i).padStart(2, "0")}:00`,
  );

  const renderMonthView = () => {
    const days = getDaysInMonth(currentDate);

    return (
      <div className="grid grid-cols-7 gap-1">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
          <div key={day} className="p-2 text-center font-bold text-gray-600">
            {day}
          </div>
        ))}
        {days.map((day, index) => {
          const dayBookings = bookings.filter(
            (booking) =>
              new Date(booking.date).toDateString() === day.toDateString(),
          );

          return (
            <div
              key={day}
              className="min-h-[100px] border rounded-lg p-2 bg-white hover:bg-gray-50 cursor-pointer"
              onClick={() => onDateSelect?.(day)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(day)}
            >
              <div className="text-right text-gray-500">{day.getDate()}</div>
              <div className="space-y-1">
                {dayBookings.map((booking) => (
                  <div
                    key={booking.id}
                    className={`p-1 rounded-md border text-sm truncate
                      ${bookingTypes[booking.type]?.color}`}
                    draggable
                    onClick={(e) => {
                      e.stopPropagation();
                      onBookingSelect?.(booking);
                    }}
                    onDragStart={() => handleDragStart(booking)}
                  >
                    <i
                      className={`fas ${bookingTypes[booking.type]?.icon} mr-1`}
                    ></i>
                    <span>{booking.title}</span>
                    <i
                      className={`fas ${statusIcons[booking.status]} ml-1`}
                    ></i>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderWeekView = () => {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());

    const weekDays = Array.from({ length: 7 }, (_, i) => {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      return day;
    });

    return (
      <div className="overflow-x-auto">
        <div className="grid grid-cols-8 gap-1">
          <div className="w-20"></div>
          {weekDays.map((day) => (
            <div key={day} className="text-center font-bold text-gray-600 p-2">
              {day.toLocaleDateString("en-US", { weekday: "short" })}
              <div className="text-sm">{day.getDate()}</div>
            </div>
          ))}

          {timeSlots.map((slot) => (
            <React.Fragment key={slot}>
              <div className="text-right pr-2 text-gray-500 py-2">{slot}</div>
              {weekDays.map((day) => {
                const timeBookings = bookings.filter(
                  (booking) =>
                    new Date(booking.date).toDateString() ===
                      day.toDateString() && booking.time === slot,
                );

                return (
                  <div
                    key={`${day}-${slot}`}
                    className="border rounded-lg p-1 min-h-[40px] bg-white hover:bg-gray-50"
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() =>
                      handleDrop(new Date(day.setHours(parseInt(slot))))
                    }
                  >
                    {timeBookings.map((booking) => (
                      <div
                        key={booking.id}
                        className={`p-1 rounded-md border text-sm truncate
                          ${bookingTypes[booking.type]?.color}`}
                        draggable
                        onClick={() => onBookingSelect?.(booking)}
                        onDragStart={() => handleDragStart(booking)}
                      >
                        <i
                          className={`fas ${bookingTypes[booking.type]?.icon} mr-1`}
                        ></i>
                        <span>{booking.title}</span>
                        <i
                          className={`fas ${statusIcons[booking.status]} ml-1`}
                        ></i>
                      </div>
                    ))}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 bg-gray-100 rounded-lg">
      <div className="flex justify-between items-center mb-4">
        <div className="space-x-2">
          <button
            onClick={() =>
              setCurrentDate(
                new Date(currentDate.setMonth(currentDate.getMonth() - 1)),
              )
            }
            className="px-3 py-1 rounded-md bg-white hover:bg-gray-50 border"
          >
            <i className="fas fa-chevron-left"></i>
          </button>
          <span className="font-bold">
            {currentDate.toLocaleString("default", {
              month: "long",
              year: "numeric",
            })}
          </span>
          <button
            onClick={() =>
              setCurrentDate(
                new Date(currentDate.setMonth(currentDate.getMonth() + 1)),
              )
            }
            className="px-3 py-1 rounded-md bg-white hover:bg-gray-50 border"
          >
            <i className="fas fa-chevron-right"></i>
          </button>
        </div>
        <div className="space-x-2">
          <button
            onClick={() => onViewChange?.("month")}
            className={`px-3 py-1 rounded-md ${view === "month" ? "bg-blue-500 text-white" : "bg-white"}`}
          >
            Month
          </button>
          <button
            onClick={() => onViewChange?.("week")}
            className={`px-3 py-1 rounded-md ${view === "week" ? "bg-blue-500 text-white" : "bg-white"}`}
          >
            Week
          </button>
        </div>
      </div>
      {view === "month" ? renderMonthView() : renderWeekView()}
    </div>
  );
}

function StoryComponent() {
  const [view, setView] = useState("month");
  const [selectedBooking, setSelectedBooking] = useState(null);

  const sampleBookings = [
    {
      id: 1,
      title: "City Tour",
      type: "tour",
      date: new Date(),
      time: "09:00",
      status: "confirmed",
    },
    {
      id: 2,
      title: "Hotel Check-in",
      type: "hotel",
      date: new Date(),
      time: "14:00",
      status: "pending",
    },
    {
      id: 3,
      title: "Beach Activity",
      type: "activity",
      date: new Date(new Date().setDate(new Date().getDate() + 1)),
      time: "10:00",
      status: "cancelled",
    },
    {
      id: 4,
      title: "Airport Transfer",
      type: "transport",
      date: new Date(new Date().setDate(new Date().getDate() + 2)),
      time: "07:00",
      status: "confirmed",
    },
  ];

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Booking Calendar</h2>
        <MainComponent
          bookings={sampleBookings}
          view={view}
          onViewChange={setView}
          onBookingSelect={setSelectedBooking}
          onBookingDrop={(booking, date) => {
            console.log("Booking dropped:", booking, "New date:", date);
          }}
        />
        {selectedBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white p-6 rounded-lg max-w-md w-full">
              <h3 className="text-xl font-bold mb-4">Booking Details</h3>
              <p>
                <strong>Title:</strong> {selectedBooking.title}
              </p>
              <p>
                <strong>Type:</strong> {selectedBooking.type}
              </p>
              <p>
                <strong>Date:</strong>{" "}
                {new Date(selectedBooking.date).toLocaleDateString()}
              </p>
              <p>
                <strong>Time:</strong> {selectedBooking.time}
              </p>
              <p>
                <strong>Status:</strong> {selectedBooking.status}
              </p>
              <button
                onClick={() => setSelectedBooking(null)}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});
}