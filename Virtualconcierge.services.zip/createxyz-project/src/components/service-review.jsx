"use client";
import React from "react";

import { useUpload } from '../utilities/runtime-helpers'

export default function Index() {
  return (function MainComponent({
  review = null,
  user = null,
  onSubmit,
  onMarkHelpful,
  maxImages = 3,
  maxCharacters = 2000,
  isSubmitting = false,
  error = null,
}) {
  const [rating, setRating] = useState(review?.rating || 0);
  const [reviewText, setReviewText] = useState(review?.reviewText || "");
  const [images, setImages] = useState(review?.images || []);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [upload, { loading: uploading }] = useUpload();
  const [uploadError, setUploadError] = useState(null);

  const handleImageUpload = async (event) => {
    if (images.length >= maxImages) {
      setUploadError("Maximum number of images reached");
      return;
    }

    const file = event.target.files[0];
    if (!file) return;

    try {
      const { url, error } = await upload({ file });
      if (error) throw new Error(error);
      setImages([...images, url]);
      setUploadError(null);
    } catch (err) {
      setUploadError("Failed to upload image");
    }
  };

  const handleRemoveImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (onSubmit) {
      await onSubmit({
        rating,
        reviewText,
        images,
      });
    }
  };

  const remainingChars = maxCharacters - reviewText.length;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-50 text-red-600 rounded-lg">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {!review && (
          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2">Rating</label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onMouseEnter={() => setHoveredStar(star)}
                  onMouseLeave={() => setHoveredStar(0)}
                  onClick={() => setRating(star)}
                  className="text-2xl transition-transform hover:scale-110"
                >
                  <i
                    className={`fas fa-star ${
                      star <= (hoveredStar || rating)
                        ? "text-yellow-400"
                        : "text-gray-300"
                    }`}
                  ></i>
                </button>
              ))}
            </div>
          </div>
        )}

        {!review && (
          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2">
              Review
              <span className="text-gray-500 text-xs ml-2">
                ({remainingChars} characters remaining)
              </span>
            </label>
            <textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              maxLength={maxCharacters}
              placeholder="Share your experience..."
              className="w-full min-h-[120px] p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        )}

        {!review && (
          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2">
              Images
              <span className="text-gray-500 text-xs ml-2">
                (Maximum {maxImages})
              </span>
            </label>
            <div className="flex gap-4 flex-wrap">
              {images.map((image, index) => (
                <div key={index} className="relative">
                  <img
                    src={image}
                    alt={`Review image ${index + 1}`}
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(index)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
              ))}
              {images.length < maxImages && (
                <label className="w-24 h-24 border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer hover:border-blue-500">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <i className="fas fa-plus text-gray-400"></i>
                </label>
              )}
            </div>
            {uploadError && (
              <p className="text-red-500 text-sm mt-2">{uploadError}</p>
            )}
          </div>
        )}

        {review ? (
          <div>
            <div className="flex items-center gap-4 mb-4">
              <img
                src={user?.avatar || "https://via.placeholder.com/40"}
                alt={user?.name || "User"}
                className="w-10 h-10 rounded-full"
              />
              <div>
                <div className="font-semibold">{user?.name || "Anonymous"}</div>
                <div className="text-sm text-gray-500">
                  {new Date(review.date).toLocaleDateString()}
                </div>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <i
                    key={star}
                    className={`fas fa-star ${
                      star <= review.rating
                        ? "text-yellow-400"
                        : "text-gray-300"
                    }`}
                  ></i>
                ))}
              </div>
              <p className="text-gray-700">{review.reviewText}</p>
            </div>

            {review.images?.length > 0 && (
              <div className="flex gap-4 mb-4 overflow-x-auto">
                {review.images.map((image, index) => (
                  <img
                    key={index}
                    src={image}
                    alt={`Review image ${index + 1}`}
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                ))}
              </div>
            )}

            {review.staffResponse && (
              <div className="bg-gray-50 p-4 rounded-lg mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <i className="fas fa-user-tie text-gray-600"></i>
                  <span className="font-semibold">Staff Response</span>
                </div>
                <p className="text-gray-700">{review.staffResponse}</p>
              </div>
            )}

            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => onMarkHelpful?.(review.id, true)}
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
              >
                <i className="fas fa-thumbs-up"></i>
                Helpful ({review.helpfulCount || 0})
              </button>
              <button
                type="button"
                onClick={() => onMarkHelpful?.(review.id, false)}
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
              >
                <i className="fas fa-thumbs-down"></i>
                Not Helpful ({review.notHelpfulCount || 0})
              </button>
            </div>
          </div>
        ) : (
          <button
            type="submit"
            disabled={isSubmitting || !rating || !reviewText.trim()}
            className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <i className="fas fa-spinner fa-spin"></i>
            ) : (
              "Submit Review"
            )}
          </button>
        )}
      </form>
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-4">New Review Form</h2>
        <MainComponent
          onSubmit={async (data) => console.log("Submit:", data)}
          onMarkHelpful={(id, helpful) => console.log("Helpful:", id, helpful)}
        />
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Existing Review</h2>
        <MainComponent
          review={{
            id: 1,
            rating: 4,
            reviewText:
              "Great experience! The service was excellent and the staff was very friendly.",
            date: new Date().toISOString(),
            images: [
              "https://via.placeholder.com/200",
              "https://via.placeholder.com/200",
            ],
            helpfulCount: 12,
            notHelpfulCount: 2,
            staffResponse:
              "Thank you for your kind review! We're glad you enjoyed your experience with us.",
          }}
          user={{
            name: "John Doe",
            avatar: "https://via.placeholder.com/40",
          }}
          onMarkHelpful={(id, helpful) => console.log("Helpful:", id, helpful)}
        />
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Error State</h2>
        <MainComponent
          error="Something went wrong. Please try again later."
          onSubmit={async (data) => console.log("Submit:", data)}
          onMarkHelpful={(id, helpful) => console.log("Helpful:", id, helpful)}
        />
      </div>
    </div>
  );
});
}