"use client";
import React from "react";



export default function Index() {
  return (const CartContext = React.createContext();

function MainComponent({ children }) {
  const { data: user, loading: userLoading } = useUser();
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!user && !userLoading) {
      setError("Please sign in to access your cart");
      return;
    }

    const loadSavedCart = async () => {
      try {
        const savedCart = localStorage.getItem(`cart_${user?.id}`);
        if (savedCart) {
          const parsedCart = JSON.parse(savedCart);
          if (Array.isArray(parsedCart) && parsedCart.every(item => 
            item && 
            typeof item === 'object' && 
            typeof item.id === 'number' && 
            typeof item.quantity === 'number' && 
            typeof item.price === 'number' && 
            typeof item.name === 'string'
          )) {
            setCart(parsedCart);
          } else {
            throw new Error("Invalid cart data format");
          }
        }
      } catch (err) {
        console.error("Error loading cart:", err);
        setError("Could not load your saved cart");
        localStorage.removeItem(`cart_${user?.id}`);
      } finally {
        setInitialized(true);
      }
    };

    if (user) {
      loadSavedCart();
    }
  }, [user, userLoading]);

  useEffect(() => {
    if (user && cart.length > 0) {
      try {
        localStorage.setItem(`cart_${user.id}`, JSON.stringify(cart));
      } catch (err) {
        console.error("Error saving cart:", err);
        setError("Could not save cart changes");
      }
    }
  }, [cart, user]);

  const validateItem = useCallback((item) => {
    if (!item || typeof item !== 'object') throw new Error("Invalid item format");
    if (typeof item.id !== 'number') throw new Error("Item ID must be a number");
    if (typeof item.price !== 'number') throw new Error("Item price must be a number");
    if (typeof item.name !== 'string') throw new Error("Item name must be a string");
    return true;
  }, []);

  const addToCart = useCallback(async (item, quantity = 1) => {
    if (!user) {
      setError("Please sign in to add items to cart");
      return;
    }

    try {
      validateItem(item);
      if (quantity <= 0) throw new Error("Quantity must be greater than 0");

      setLoading(true);
      setError(null);

      const response = await fetch("/api/cart-management", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${user.token}`
        },
        body: JSON.stringify({
          action: "addItem",
          data: {
            itemId: item.id,
            userId: user.id,
            quantity,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to add item to cart");
      }

      setCart((prevCart) => {
        const existingItem = prevCart.find((i) => i.id === item.id);
        if (existingItem) {
          return prevCart.map((i) =>
            i.id === item.id ? { ...i, quantity: i.quantity + quantity } : i
          );
        }
        return [...prevCart, { ...item, quantity }];
      });
    } catch (err) {
      console.error("Add to cart error:", err);
      setError(err.message || "Could not add item to cart");
    } finally {
      setLoading(false);
    }
  }, [user, validateItem]);

  const removeFromCart = useCallback(async (itemId) => {
    if (!user) {
      setError("Please sign in to remove items from cart");
      return;
    }

    try {
      if (typeof itemId !== 'number') throw new Error("Invalid item ID");
      
      setLoading(true);
      setError(null);

      const response = await fetch("/api/cart-management", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${user.token}`
        },
        body: JSON.stringify({
          action: "removeItem",
          data: {
            itemId,
            userId: user.id,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to remove item from cart");
      }

      setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
    } catch (err) {
      console.error("Remove from cart error:", err);
      setError(err.message || "Could not remove item from cart");
    } finally {
      setLoading(false);
    }
  }, [user]);

  const updateQuantity = useCallback(async (itemId, quantity) => {
    if (!user) {
      setError("Please sign in to update cart");
      return;
    }

    try {
      if (typeof itemId !== 'number') throw new Error("Invalid item ID");
      if (typeof quantity !== 'number' || quantity < 0) throw new Error("Invalid quantity");

      setLoading(true);
      setError(null);

      const response = await fetch("/api/cart-management", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${user.token}`
        },
        body: JSON.stringify({
          action: "updateQuantity",
          data: {
            itemId,
            userId: user.id,
            quantity,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update cart");
      }

      if (quantity === 0) {
        setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
      } else {
        setCart((prevCart) =>
          prevCart.map((item) =>
            item.id === itemId ? { ...item, quantity } : item
          )
        );
      }
    } catch (err) {
      console.error("Update quantity error:", err);
      setError(err.message || "Could not update cart");
    } finally {
      setLoading(false);
    }
  }, [user]);

  const clearCart = useCallback(async () => {
    if (!user) {
      setError("Please sign in to clear cart");
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const response = await fetch("/api/cart-management", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${user.token}`
        },
        body: JSON.stringify({
          action: "clearCart",
          data: {
            userId: user.id,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to clear cart");
      }

      setCart([]);
      localStorage.removeItem(`cart_${user.id}`);
    } catch (err) {
      console.error("Clear cart error:", err);
      setError(err.message || "Could not clear cart");
    } finally {
      setLoading(false);
    }
  }, [user]);

  const totalItems = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  const totalAmount = useMemo(
    () => cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [cart]
  );

  const value = {
    cart,
    loading: loading || userLoading,
    error,
    initialized,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    totalItems,
    totalAmount,
  };

  return <></>;
}

function StoryComponent() {
  const mockItem = {
    id: 1,
    name: "Sample Product",
    price: 29.99,
    image: "https://via.placeholder.com/150",
  };

  return (
    <div className="p-4">
      <MainComponent>
        <div className="space-y-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-crimson-text text-xl mb-2">Cart Provider Demo</h3>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-bold mb-2">Loading State</h4>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-spinner fa-spin text-blue-500"></i>
                  <span>Loading cart...</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-bold mb-2">Error State</h4>
                <div className="text-red-500">
                  <i className="fas fa-exclamation-circle mr-2"></i>
                  Please sign in to access your cart
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-bold mb-2">Empty Cart</h4>
                <div className="text-gray-500">
                  Your cart is empty
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-bold mb-2">Cart with Items</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>{mockItem.name}</span>
                    <span>${mockItem.price}</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    Total Items: 1
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainComponent>
    </div>
  );
});
}