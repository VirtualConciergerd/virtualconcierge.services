"use client";
import React from "react";

function MainComponent() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    setError(null);

    try {
      const response = await fetch("/api/contact-form", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "submit",
          data: formData,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit form");
      }

      setStatus("success");
      setFormData({ name: "", email: "", message: "" });
    } catch (err) {
      setError("Failed to submit form. Please try again.");
      setStatus("error");
    }
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://ucarecdn.com/34fe97ef-19a4-41fc-8c46-0f6a70075aae/-/format/auto/)`,
        backgroundAttachment: "fixed",
      }}
    >
      <div className="max-w-4xl w-full space-y-8 backdrop-blur-md bg-white/80 p-8 rounded-xl shadow-2xl">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Contact Us</h1>
          <p className="text-lg text-gray-600">
            Let us help you plan your perfect Dominican Republic experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                Get in Touch
              </h2>
              <p className="text-gray-600 mb-6">
                Have questions about our services? Want to plan a special trip?
                We're here to help make your Dominican Republic experience
                unforgettable.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <i className="fas fa-envelope text-[#0056b3] text-xl"></i>
                <a
                  href="mailto:Contactus@virtualconciergerd.com"
                  className="text-gray-600 hover:text-[#0056b3] transition-colors"
                >
                  Contactus@virtualconciergerd.com
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <i className="fas fa-map-marker-alt text-[#0056b3] text-xl"></i>
                <span className="text-gray-600">
                  Santo Domingo, Dominican Republic
                </span>
              </div>
            </div>

            <div className="pt-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Follow Us
              </h3>
              <div className="flex space-x-6">
                <a
                  href="#"
                  className="text-[#0056b3] hover:text-[#003d80] transition-colors"
                >
                  <i className="fab fa-facebook text-2xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#0056b3] hover:text-[#003d80] transition-colors"
                >
                  <i className="fab fa-twitter text-2xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#0056b3] hover:text-[#003d80] transition-colors"
                >
                  <i className="fab fa-instagram text-2xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#0056b3] hover:text-[#003d80] transition-colors"
                >
                  <i className="fab fa-linkedin text-2xl"></i>
                </a>
              </div>
            </div>
          </div>

          <form
            onSubmit={handleSubmit}
            className="space-y-6 bg-white/50 p-6 rounded-lg backdrop-blur-sm"
          >
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-medium text-gray-700"
              >
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#0056b3] focus:ring-[#0056b3] bg-white/80"
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
              />
            </div>

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700"
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#0056b3] focus:ring-[#0056b3] bg-white/80"
                value={formData.email}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, email: e.target.value }))
                }
              />
            </div>

            <div>
              <label
                htmlFor="message"
                className="block text-sm font-medium text-gray-700"
              >
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#0056b3] focus:ring-[#0056b3] bg-white/80"
                value={formData.message}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, message: e.target.value }))
                }
              />
            </div>

            {error && (
              <div className="text-red-600 text-sm bg-red-50 p-3 rounded-md">
                {error}
              </div>
            )}

            {status === "success" && (
              <div className="text-green-600 text-sm bg-green-50 p-3 rounded-md">
                Thank you for your message! We'll get back to you soon.
              </div>
            )}

            <button
              type="submit"
              disabled={status === "loading"}
              className="w-full bg-[#0056b3] text-white rounded-md py-3 px-4 hover:bg-[#003d80] transition-colors disabled:opacity-50 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200"
            >
              {status === "loading" ? "Sending..." : "Send Message"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;