"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <nav className="fixed w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <img
              src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
              alt="Virtual Concierge Logo"
              className="h-10 w-auto"
            />
            <div className="text-2xl font-crimson-text text-[#1e293b] font-bold">
              Virtual Concierge
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <a
              href="/about"
              className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            >
              About
            </a>
            <a
              href="/contact"
              className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            >
              Contact
            </a>
            <a
              href="/account/signup"
              className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
            >
              Get Started
            </a>
          </div>
        </div>
      </nav>

      <main className="pt-24">
        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Your AI-Powered Travel Companion
            </h1>
            <p className="text-xl text-[#475569] mb-12 max-w-3xl mx-auto">
              Discover the Dominican Republic with personalized recommendations,
              real-time translations, and local insights
            </p>
            <a
              href="/account/signup"
              className="bg-[#3b82f6] text-white px-8 py-4 rounded-full text-lg hover:bg-[#2563eb] transition-colors inline-block"
            >
              Start Your Journey
            </a>
          </div>
        </section>

        <section className="py-16 px-4 bg-white">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
              Key Features
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center p-6">
                <i className="fas fa-language text-4xl text-[#3b82f6] mb-4"></i>
                <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
                  Real-time Translation
                </h3>
                <p className="text-[#475569]">
                  Break language barriers with instant translations in multiple
                  languages
                </p>
              </div>
              <div className="text-center p-6">
                <i className="fas fa-map-marked-alt text-4xl text-[#3b82f6] mb-4"></i>
                <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
                  Local Insights
                </h3>
                <p className="text-[#475569]">
                  Get personalized recommendations for attractions, restaurants,
                  and activities
                </p>
              </div>
              <div className="text-center p-6">
                <i className="fas fa-clock text-4xl text-[#3b82f6] mb-4"></i>
                <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
                  24/7 Assistance
                </h3>
                <p className="text-[#475569]">
                  Access help and information anytime, anywhere during your
                  travels
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
              What Travelers Say
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "The perfect travel companion! Made navigating the Dominican
                  Republic so much easier."
                </p>
                <div className="font-bold text-[#1e293b]">Sarah M.</div>
                <div className="text-sm text-[#475569]">Solo Traveler</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "Found amazing local spots we would have never discovered on
                  our own!"
                </p>
                <div className="font-bold text-[#1e293b]">James R.</div>
                <div className="text-sm text-[#475569]">Family Vacation</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "The real-time translation feature was a game-changer for our
                  trip."
                </p>
                <div className="font-bold text-[#1e293b]">Maria L.</div>
                <div className="text-sm text-[#475569]">Business Traveler</div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-[#1e293b] text-white">
          <div className="max-w-7xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-crimson-text font-bold mb-6">
              Ready to Explore?
            </h2>
            <p className="text-xl mb-8">
              Join thousands of travelers discovering the best of the Dominican
              Republic
            </p>
            <a
              href="/account/signup"
              className="bg-white text-[#1e293b] px-8 py-4 rounded-full text-lg hover:bg-gray-100 transition-colors inline-block"
            >
              Get Started Free
            </a>
          </div>
        </section>
      </main>

      <footer className="bg-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-crimson-text text-xl font-bold text-[#1e293b] mb-4">
                Virtual Concierge
              </h3>
              <p className="text-[#475569]">Your AI-powered travel companion</p>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Features</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>AI Assistant</li>
                <li>Translation Services</li>
                <li>Local Recommendations</li>
                <li>Travel Planning</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Company</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>
                  <a
                    href="/about"
                    className="hover:text-[#3b82f6] transition-colors"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="/contact"
                    className="hover:text-[#3b82f6] transition-colors"
                  >
                    Contact
                  </a>
                </li>
                <li>
                  <a
                    href="/cookie-policy"
                    className="hover:text-[#3b82f6] transition-colors"
                  >
                    Cookie Policy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Connect</h4>
              <div className="flex space-x-4">
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                >
                  <i className="fab fa-twitter text-xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                >
                  <i className="fab fa-facebook text-xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                >
                  <i className="fab fa-instagram text-xl"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                >
                  <i className="fab fa-linkedin text-xl"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-200 text-center text-[#475569]">
            <p>&copy; 2025 Virtual Concierge. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;