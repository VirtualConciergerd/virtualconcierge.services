"use client";
import React from "react";
import TopTenList from "../components/top-ten-list";

function MainComponent() {
  const { data: user } = useUser();
  const [healthStatus, setHealthStatus] = useState(null);
  const [queueMetrics, setQueueMetrics] = useState(null);
  const [rateLimitStatus, setRateLimitStatus] = useState(null);
  const [configStatus, setConfigStatus] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchSystemStatus = useCallback(async () => {
    if (!user?.isAdmin) return;

    setLoading(true);
    setError(null);

    try {
      const [healthRes, queueRes, rateLimitRes, configRes] = await Promise.all([
        fetch("/api/system-health-check", { method: "POST" }),
        fetch("/api/queue-monitor", { method: "POST" }),
        fetch("/api/api-rate-limiter", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ip: "0.0.0.0",
            endpoint: "/health-check",
          }),
        }),
        fetch("/api/environment-config", { method: "POST" }),
      ]);

      if (!healthRes.ok || !queueRes.ok || !rateLimitRes.ok || !configRes.ok) {
        throw new Error("Failed to fetch system status");
      }

      const [health, queue, rateLimit, config] = await Promise.all([
        healthRes.json(),
        queueRes.json(),
        rateLimitRes.json(),
        configRes.json(),
      ]);

      setHealthStatus(health);
      setQueueMetrics(queue);
      setRateLimitStatus(rateLimit);
      setConfigStatus(config);
    } catch (err) {
      console.error("System status error:", err);
      setError("Failed to fetch system status");
    } finally {
      setLoading(false);
    }
  }, [user?.isAdmin]);

  useEffect(() => {
    if (!user?.isAdmin) return;

    fetchSystemStatus();
    const interval = setInterval(fetchSystemStatus, 30000);
    return () => clearInterval(interval);
  }, [fetchSystemStatus, user?.isAdmin]);

  if (!user?.isAdmin) {
    return <TopTenList title="Top 10 Services" items={[]} type="service" />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">System Monitor</h1>
          {error && (
            <div className="mt-4 bg-red-50 border-l-4 border-red-400 p-4">
              <p className="text-red-700">{error}</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">System Health</h2>
            {loading && !healthStatus ? (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ) : healthStatus ? (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Status</span>
                  <span
                    className={`font-medium ${
                      healthStatus.success ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {healthStatus.success ? "Healthy" : "Error"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Database</span>
                  <span
                    className={`font-medium ${
                      healthStatus.status?.database === "healthy"
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {healthStatus.status?.database || "Unknown"}
                  </span>
                </div>
                <div>
                  <div className="text-sm text-gray-600">
                    Last 24h Registrations
                  </div>
                  <div className="text-2xl font-bold">
                    {healthStatus.status?.last24hRegistrations || 0}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Queue Status</h2>
            {queueMetrics && (
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-600">Queue Length</div>
                  <div className="text-2xl font-bold">
                    {queueMetrics.queue.total}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-600">Processing</div>
                    <div className="text-xl font-semibold">
                      {queueMetrics.queue.processing}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Pending</div>
                    <div className="text-xl font-semibold">
                      {queueMetrics.queue.pending}
                    </div>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Error Rate</div>
                  <div className="text-xl font-semibold text-red-600">
                    {queueMetrics.errors.rate}%
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Rate Limits</h2>
            {rateLimitStatus && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-600">IP Remaining</div>
                    <div className="text-2xl font-bold">
                      {rateLimitStatus.limits.ipRemaining}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">User Remaining</div>
                    <div className="text-2xl font-bold">
                      {rateLimitStatus.limits.userRemaining}
                    </div>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Reset At</div>
                  <div className="text-gray-900">
                    {new Date(
                      rateLimitStatus.limits.ipResetAt
                    ).toLocaleString()}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Configuration</h2>
            {configStatus && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Status</span>
                  <span
                    className={`px-2 py-1 rounded-full text-sm ${
                      configStatus.valid
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {configStatus.valid ? "Valid" : "Invalid"}
                  </span>
                </div>
                {configStatus.missing && configStatus.missing.length > 0 && (
                  <div>
                    <div className="text-sm text-gray-600 mb-2">
                      Missing Variables
                    </div>
                    <div className="text-red-600">
                      {configStatus.missing.join(", ")}
                    </div>
                  </div>
                )}
                <div>
                  <div className="text-sm text-gray-600">Environment</div>
                  <div className="font-medium">{configStatus.environment}</div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8">
          <button
            onClick={fetchSystemStatus}
            disabled={loading}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading ? (
              <>
                <i className="fas fa-spinner fa-spin"></i>
                <span>Refreshing...</span>
              </>
            ) : (
              <>
                <i className="fas fa-sync-alt"></i>
                <span>Refresh Status</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;