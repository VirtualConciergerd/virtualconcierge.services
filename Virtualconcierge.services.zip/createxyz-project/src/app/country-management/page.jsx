"use client";
import React from "react";

function MainComponent() {
  const [countries, setCountries] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  useEffect(() => {
    if (user && user.role !== "admin") {
      window.location.href = "/";
    }
  }, [user]);

  const fetchCountries = async () => {
    try {
      const response = await fetch("/api/admin/countries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "list" }),
      });
      if (!response.ok) throw new Error("Failed to fetch countries");
      const data = await response.json();
      setCountries(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  const handleDeleteCountry = async (id) => {
    if (!confirm("Are you sure you want to delete this country?")) return;

    try {
      const response = await fetch(`/api/admin/countries/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete country");

      fetchCountries();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/admin" className="hover:text-[#FF4B3E] transition-colors">
            Dashboard
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Country Management</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-[#1e293b]">
              Country Management
            </h1>
            <button
              onClick={() => {
                setSelectedCountry(null);
                setIsEditing(true);
              }}
              className="bg-[#FF4B3E] text-white px-4 py-2 rounded-lg hover:bg-[#ff635c] transition-all duration-300"
            >
              Add New Country
            </button>
          </div>

          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF4B3E]"></div>
            </div>
          ) : error ? (
            <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-4">
              {error}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-[#f8fafc] border-b">
                    <th className="px-4 py-3 text-left">Country</th>
                    <th className="px-4 py-3 text-left">Code</th>
                    <th className="px-4 py-3 text-left">Currency</th>
                    <th className="px-4 py-3 text-left">Emergency #</th>
                    <th className="px-4 py-3 text-left">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {countries.map((country) => (
                    <tr
                      key={country.id}
                      className="border-b hover:bg-[#f8fafc] transition-colors"
                    >
                      <td className="px-4 py-3">{country.name}</td>
                      <td className="px-4 py-3">{country.code}</td>
                      <td className="px-4 py-3">{country.currency}</td>
                      <td className="px-4 py-3">{country.emergency_number}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-1 rounded-full text-sm ${
                            country.active
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {country.active ? "Active" : "Inactive"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => {
                            setSelectedCountry(country);
                            setIsEditing(true);
                          }}
                          className="text-[#2EC4B6] hover:text-[#FF4B3E] mr-3"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button
                          onClick={() => handleDeleteCountry(country.id)}
                          className="text-[#FF4B3E] hover:text-[#ff635c]"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;