"use client";
import React from "react";

function MainComponent() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expandedTask, setExpandedTask] = useState(null);
  const [comments, setComments] = useState({});
  const [newComment, setNewComment] = useState("");
  const [commentLoading, setCommentLoading] = useState(false);
  const { data: user } = useUser();

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/list-tasks", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch tasks");
      const data = await response.json();
      setTasks(data);
    } catch (err) {
      console.error(err);
      setError("Could not load tasks");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/create-task", {
        method: "POST",
        body: JSON.stringify({ title, description }),
      });
      if (!response.ok) throw new Error("Failed to create task");
      await fetchTasks();
      setTitle("");
      setDescription("");
    } catch (err) {
      console.error(err);
      setError("Could not create task");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (taskId) => {
    if (!confirm("Are you sure you want to delete this task?")) return;

    try {
      const response = await fetch("/api/delete-task", {
        method: "POST",
        body: JSON.stringify({ taskId }),
      });
      if (!response.ok) throw new Error("Failed to delete task");
      await fetchTasks();
    } catch (err) {
      console.error(err);
      setError("Could not delete task");
    }
  };

  const fetchComments = async (taskId) => {
    setCommentLoading(true);
    try {
      const response = await fetch("/api/get-task-comments", {
        method: "POST",
        body: JSON.stringify({ taskId }),
      });
      if (!response.ok) throw new Error("Failed to fetch comments");
      const data = await response.json();
      setComments((prev) => ({ ...prev, [taskId]: data }));
    } catch (err) {
      console.error(err);
      setError("Could not load comments");
    } finally {
      setCommentLoading(false);
    }
  };

  const handleAddComment = async (taskId) => {
    if (!newComment.trim()) return;

    setCommentLoading(true);
    try {
      const response = await fetch("/api/add-comment", {
        method: "POST",
        body: JSON.stringify({ taskId, content: newComment }),
      });
      if (!response.ok) throw new Error("Failed to add comment");
      await fetchComments(taskId);
      setNewComment("");
    } catch (err) {
      console.error(err);
      setError("Could not add comment");
    } finally {
      setCommentLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  useEffect(() => {
    if (expandedTask) {
      fetchComments(expandedTask);
    }
  }, [expandedTask]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Task Management
          </h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#475569] mb-2">
                Task Title
              </label>
              <input
                type="text"
                name="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-3 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#475569] mb-2">
                Description
              </label>
              <textarea
                name="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                rows="3"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="bg-[#3b82f6] text-white px-6 py-2 rounded hover:bg-[#2563eb] transition-colors disabled:bg-gray-300"
            >
              {loading ? "Creating..." : "Create Task"}
            </button>
          </form>
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="space-y-6">
          {tasks.map((task) => (
            <div key={task.id} className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-xl font-bold text-[#1e293b] mb-2">
                    {task.title}
                  </h2>
                  <p className="text-[#475569] mb-2">{task.description}</p>
                  <div className="flex items-center text-sm text-[#475569]">
                    <span className="mr-4">
                      Created by: {task.creator_name}
                    </span>
                    <button
                      onClick={() =>
                        setExpandedTask(
                          expandedTask === task.id ? null : task.id
                        )
                      }
                      className="flex items-center text-[#3b82f6] hover:text-[#2563eb]"
                    >
                      <i className="fas fa-comments mr-1"></i>
                      {task.comment_count} Comments
                    </button>
                  </div>
                </div>
                {user && task.user_id === user.id && (
                  <button
                    onClick={() => handleDelete(task.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                )}
              </div>

              {expandedTask === task.id && (
                <div className="mt-4 pt-4 border-t">
                  <div className="space-y-4 mb-4">
                    {comments[task.id]?.map((comment) => (
                      <div key={comment.id} className="bg-gray-50 rounded p-3">
                        <div className="font-medium text-[#1e293b] mb-1">
                          {comment.user_name}
                        </div>
                        <p className="text-[#475569]">{comment.content}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Add a comment..."
                      className="flex-1 p-2 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                    />
                    <button
                      onClick={() => handleAddComment(task.id)}
                      disabled={commentLoading}
                      className="bg-[#3b82f6] text-white px-4 py-2 rounded hover:bg-[#2563eb] transition-colors disabled:bg-gray-300"
                    >
                      {commentLoading ? "Adding..." : "Add Comment"}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {loading && tasks.length === 0 && (
          <div className="text-center py-12">
            <i className="fas fa-spinner fa-spin text-3xl text-[#3b82f6]"></i>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;