"use client";
import React from "react";

function MainComponent() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({ type: "", message: "" });

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: "", message: "" });

    try {
      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          data: {
            message: `New contact form submission from ${formData.name} (${formData.email}): ${formData.message}`,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to send message");

      setStatus({
        type: "success",
        message: "Message sent successfully! We'll get back to you soon.",
      });
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      setStatus({
        type: "error",
        message: "Failed to send message. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <nav className="fixed w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-crimson-text text-[#1e293b] font-bold">
            Virtual Concierge
          </div>
          <div className="flex gap-4 items-center">
            <a
              href="/"
              className="text-[#1e293b] hover:text-[#3b82f6] transition-colors"
            >
              Home
            </a>
            <a
              href="/about"
              className="text-[#1e293b] hover:text-[#3b82f6] transition-colors"
            >
              About
            </a>
            <a
              href="/virtual-concierge"
              className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
            >
              Get Started
            </a>
          </div>
        </div>
      </nav>

      <main className="pt-24 px-4 max-w-7xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
          Contact Us
        </h1>

        <div className="grid md:grid-cols-2 gap-12 mb-12">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Send us a Message
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your Name"
                  className="w-full p-3 border rounded font-roboto focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  required
                />
              </div>
              <div>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Your Email"
                  className="w-full p-3 border rounded font-roboto focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  required
                />
              </div>
              <div>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Your Message"
                  className="w-full p-3 border rounded font-roboto h-32 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  required
                />
              </div>
              {status.message && (
                <div
                  className={`p-3 rounded ${
                    status.type === "success"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {status.message}
                </div>
              )}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#3b82f6] text-white px-6 py-3 rounded-full hover:bg-[#2563eb] transition-colors disabled:bg-[#93c5fd]"
              >
                {loading ? "Sending..." : "Send Message"}
              </button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Contact Information
              </h2>
              <div className="space-y-4">
                <div className="flex items-center">
                  <i className="fas fa-envelope text-[#3b82f6] text-xl w-8"></i>
                  <span>contact@virtualconcierge.com</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-phone text-[#3b82f6] text-xl w-8"></i>
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-map-marker-alt text-[#3b82f6] text-xl w-8"></i>
                  <span>
                    123 Tourism Street, Santo Domingo, Dominican Republic
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Connect With Us
              </h2>
              <div className="flex space-x-6">
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] text-2xl"
                >
                  <i className="fab fa-facebook"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] text-2xl"
                >
                  <i className="fab fa-twitter"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] text-2xl"
                >
                  <i className="fab fa-instagram"></i>
                </a>
                <a
                  href="#"
                  className="text-[#3b82f6] hover:text-[#2563eb] text-2xl"
                >
                  <i className="fab fa-linkedin"></i>
                </a>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Office Hours
              </h2>
              <div className="space-y-2">
                <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                <p>Saturday: 10:00 AM - 4:00 PM</p>
                <p>Sunday: Closed</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-12">
          <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Our Location
          </h2>
          <div className="h-[400px] bg-gray-100 rounded">
            <div className="w-full h-full flex items-center justify-center text-gray-500">
              Map will be displayed here
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-crimson-text text-xl font-bold text-[#1e293b] mb-4">
                Virtual Concierge
              </h3>
              <p className="text-[#475569]">Your AI-powered travel companion</p>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Features</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>AI Assistant</li>
                <li>Translation Services</li>
                <li>Local Recommendations</li>
                <li>Travel Planning</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Company</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>About Us</li>
                <li>Contact</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Connect</h4>
              <div className="flex space-x-4">
                <i className="fab fa-twitter text-[#3b82f6] text-xl"></i>
                <i className="fab fa-facebook text-[#3b82f6] text-xl"></i>
                <i className="fab fa-instagram text-[#3b82f6] text-xl"></i>
                <i className="fab fa-linkedin text-[#3b82f6] text-xl"></i>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-200 text-center text-[#475569]">
            <p>&copy; 2025 Virtual Concierge. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;