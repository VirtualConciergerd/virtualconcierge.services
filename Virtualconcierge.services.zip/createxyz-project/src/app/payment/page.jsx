"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();

  useEffect(() => {
    navigate("/");
  }, [navigate]);

  return null;
}

export default MainComponent;