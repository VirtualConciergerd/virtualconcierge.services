"use client";
import React from "react";

function MainComponent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    status: "all",
    type: "all",
  });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: searchQuery,
          filters: {
            ...filters,
            dateFrom: filters.dateFrom || undefined,
            dateTo: filters.dateTo || undefined,
          },
        }),
      });

      if (!response.ok) throw new Error("Search failed");

      const data = await response.json();
      setResults(data);
    } catch (err) {
      console.error(err);
      setError("Failed to perform search");
    } finally {
      setLoading(false);
    }
  }, [searchQuery, filters]);

  useEffect(() => {
    if (searchQuery.trim()) {
      const debounce = setTimeout(() => {
        handleSearch();
      }, 300);

      return () => clearTimeout(debounce);
    }
  }, [searchQuery, filters, handleSearch]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#FF4B3E] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Search</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tasks and comments..."
                className="w-full p-3 pr-10 border rounded font-roboto focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
              />
              <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-[#FF4B3E]"></i>
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="bg-[#FF4B3E] text-white px-6 py-3 rounded-lg hover:bg-[#ff635c] transition-colors flex items-center justify-center"
            >
              <i className="fas fa-filter mr-2"></i>
              Filters
            </button>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
              <div>
                <label className="block text-sm font-medium text-[#1e293b] mb-2">
                  Date From
                </label>
                <input
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) =>
                    setFilters({ ...filters, dateFrom: e.target.value })
                  }
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#1e293b] mb-2">
                  Date To
                </label>
                <input
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) =>
                    setFilters({ ...filters, dateTo: e.target.value })
                  }
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#1e293b] mb-2">
                  Status
                </label>
                <select
                  value={filters.status}
                  onChange={(e) =>
                    setFilters({ ...filters, status: e.target.value })
                  }
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                >
                  <option value="all">All</option>
                  <option value="open">Open</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#1e293b] mb-2">
                  Type
                </label>
                <select
                  value={filters.type}
                  onChange={(e) =>
                    setFilters({ ...filters, type: e.target.value })
                  }
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                >
                  <option value="all">All</option>
                  <option value="task">Tasks</option>
                  <option value="comment">Comments</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <i className="fas fa-spinner fa-spin text-4xl text-[#FF4B3E]"></i>
          </div>
        ) : (
          <div className="space-y-4">
            {results.map((result) => (
              <div
                key={result.id}
                className="bg-white rounded-lg shadow-lg p-6 hover:border-l-4 hover:border-[#FF4B3E] transition-all duration-300"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
                      {result.title}
                    </h3>
                    <p className="text-[#475569] mb-4">{result.content}</p>
                    <div className="flex items-center space-x-4 text-sm text-[#475569]">
                      <span className="flex items-center">
                        <i className="fas fa-calendar-alt mr-2"></i>
                        {new Date(result.date).toLocaleDateString()}
                      </span>
                      <span className="flex items-center">
                        <i className="fas fa-tag mr-2"></i>
                        {result.type}
                      </span>
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          result.status === "completed"
                            ? "bg-green-100 text-green-800"
                            : result.status === "in_progress"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-blue-100 text-blue-800"
                        }`}
                      >
                        {result.status}
                      </span>
                    </div>
                  </div>
                  <button className="text-[#FF4B3E] hover:text-[#ff635c] transition-colors">
                    <i className="fas fa-chevron-right"></i>
                  </button>
                </div>
              </div>
            ))}

            {!loading && results.length === 0 && searchQuery && (
              <div className="text-center text-[#475569] py-12">
                <i className="fas fa-search text-4xl mb-4 text-[#FF4B3E]"></i>
                <p className="text-xl">No results found</p>
                <p className="text-sm mt-2">
                  Try adjusting your search or filters
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;