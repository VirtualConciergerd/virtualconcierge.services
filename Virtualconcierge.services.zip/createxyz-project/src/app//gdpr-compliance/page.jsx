"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6] transition-colors"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">GDPR Compliance</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            GDPR Compliance Statement
          </h1>
          <p className="text-[#475569] mb-4">
            Last Updated: {new Date().toLocaleDateString()}
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                1. Introduction
              </h2>
              <p className="text-[#475569] mb-4">
                Virtual Concierge is committed to protecting the personal data
                of EU residents in accordance with the General Data Protection
                Regulation (GDPR).
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                2. Your GDPR Rights
              </h2>
              <div className="space-y-4">
                <p className="text-[#475569]">
                  Under GDPR, you have these rights:
                </p>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Right to be informed about how we use your data</li>
                  <li>Right to access your personal data</li>
                  <li>Right to rectification of inaccurate data</li>
                  <li>Right to erasure ("right to be forgotten")</li>
                  <li>Right to restrict processing</li>
                  <li>Right to data portability</li>
                  <li>Right to object to processing</li>
                  <li>Rights related to automated decision making</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                3. Data Protection Measures
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Encryption of personal data</li>
                <li>Regular security assessments</li>
                <li>Staff training on data protection</li>
                <li>Data protection impact assessments</li>
                <li>Appointment of a Data Protection Officer</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                4. International Data Transfers
              </h2>
              <p className="text-[#475569] mb-4">
                When we transfer data outside the EU, we ensure adequate
                safeguards through:
              </p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Standard Contractual Clauses</li>
                <li>Adequacy decisions</li>
                <li>Binding corporate rules</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                5. Data Breach Procedures
              </h2>
              <p className="text-[#475569] mb-4">
                In case of a data breach, we will:
              </p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Notify affected individuals within 72 hours</li>
                <li>Inform relevant supervisory authorities</li>
                <li>Document all breaches and our response</li>
                <li>Take measures to mitigate any adverse effects</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                6. Contact Our DPO
              </h2>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-[#475569]">Data Protection Officer:</p>
                <p className="text-[#475569]">
                  Email: dpo@virtualconcierge.com
                </p>
                <p className="text-[#475569]">
                  Address: [Your Business Address]
                </p>
                <p className="text-[#475569]">Phone: [Your Business Phone]</p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;