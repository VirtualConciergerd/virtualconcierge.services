"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [savedPlaces, setSavedPlaces] = useState([]);
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [weather, setWeather] = useState(null);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [serviceStatus, setServiceStatus] = useState({
    available: true,
    message: "",
  });
  const [bookings, setBookings] = useState([]);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const [notificationType, setNotificationType] = useState("success");
  const chatContainerRef = useRef(null);
  const handleFinish = useCallback((message) => {
    setMessages((prev) => [...prev, { role: "assistant", content: message }]);
    setStreamingMessage("");
    setLoading(false);
  }, []);
  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingMessage,
    onFinish: handleFinish,
  });

  useEffect(() => {
    const validateService = async () => {
      try {
        const response = await fetch("/api/concierge-service", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "status" }),
        });
        if (!response.ok) throw new Error("Service unavailable");
        const status = await response.json();
        setServiceStatus(status);
      } catch (err) {
        console.error(err);
        setServiceStatus({
          available: false,
          message: "Service is currently unavailable",
        });
      }
    };

    const fetchSavedPlaces = async () => {
      try {
        const response = await fetch("/api/places-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "get", data: { userId: user?.id } }),
        });
        if (!response.ok) throw new Error("Failed to fetch saved places");
        const data = await response.json();
        setSavedPlaces(data);
      } catch (err) {
        console.error(err);
        setError("Failed to load saved places");
      }
    };

    const fetchWeather = async () => {
      try {
        const response = await fetch(
          "/integrations/weather-by-city/weather/London"
        );
        if (!response.ok) throw new Error("Failed to fetch weather");
        const data = await response.json();
        setWeather(data);
      } catch (err) {
        console.error(err);
        setError("Failed to load weather");
      } finally {
        setLoading(false);
      }
    };

    const fetchBookings = async () => {
      try {
        const response = await fetch("/api/booking-service", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "list" }),
        });
        if (!response.ok) throw new Error("Failed to fetch bookings");
        const data = await response.json();
        setBookings(data.bookings);
      } catch (err) {
        console.error(err);
        showNotification("Failed to load bookings", "error");
      }
    };

    const handleConfirmBooking = async () => {
      setBookingLoading(true);
      try {
        const response = await fetch("/api/booking-service", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "create",
            serviceId: selectedService.id,
            date: selectedDate,
            numberOfPeople,
          }),
        });

        if (!response.ok) throw new Error("Failed to create booking");
        const data = await response.json();

        const paymentResponse = await fetch("/api/payment", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            bookingId: data.booking.id,
            amount: selectedService.price * numberOfPeople,
          }),
        });

        if (!paymentResponse.ok) throw new Error("Payment failed");

        showNotification("Booking confirmed successfully!", "success");
        setShowBookingModal(false);
        fetchBookings();
      } catch (err) {
        console.error(err);
        showNotification(err.message, "error");
      } finally {
        setBookingLoading(false);
      }
    };

    const showNotification = (message, type = "success") => {
      setNotificationMessage(message);
      setNotificationType(type);
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 5000);
    };

    validateService();
    if (!user) {
      window.location.href = "/account/signin?callbackUrl=/concierge";
      return;
    }
    fetchSavedPlaces();
    fetchWeather();
    fetchBookings();
  }, [user]);

  const validateMessage = (message) => {
    if (!message.trim())
      return { valid: false, error: "Message cannot be empty" };
    if (message.length > 500)
      return { valid: false, error: "Message too long (max 500 characters)" };
    return { valid: true, error: null };
  };
  const handleSendMessage = async (preset = null) => {
    if (!serviceStatus.available) {
      setError(serviceStatus.message);
      return;
    }

    const messageToSend = preset || inputMessage;
    const validation = validateMessage(messageToSend);

    if (!validation.valid) {
      setError(validation.error);
      return;
    }

    setLoading(true);
    setError(null);
    setMessages((prev) => [...prev, { role: "user", content: messageToSend }]);
    setInputMessage("");

    try {
      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          data: {
            userId: user?.id,
            message: messageToSend,
            language: selectedLanguage,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to send message");
      handleStreamResponse(response);
    } catch (err) {
      console.error(err);
      setError("Failed to send message");
      setLoading(false);
    }
  };

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop =
        chatContainerRef.current.scrollHeight;
    }
  }, [messages, streamingMessage]);

  return (
    <ErrorBoundary>
      <div className="flex flex-col md:flex-row h-screen bg-[#F5F1ED]">
        <div className="md:w-64 bg-[#70798C] p-4 flex flex-col md:min-h-screen">
          <div className="mb-6">
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="w-full p-2 bg-white/20 border border-white/30 rounded font-roboto text-white"
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
            </select>
          </div>

          {weather && (
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-lg mb-6 shadow-[0_0_15px_rgba(138,43,226,0.3)]">
              <div className="font-roboto text-lg text-white">
                {weather.location.name}
              </div>
              <div className="flex items-center text-white">
                <i className="fas fa-temperature-high mr-2 text-purple-300"></i>
                <span>{weather.current.temp_c}°C</span>
              </div>
              <div className="text-purple-200">
                {weather.current.condition.text}
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto">
            <h2 className="font-roboto text-lg mb-2 text-purple-200">
              Your Bookings
            </h2>
            <div className="space-y-2 mb-6">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="p-2 bg-white/10 backdrop-blur-md border border-white/20 rounded shadow-[0_0_15px_rgba(138,43,226,0.2)]"
                >
                  <div className="font-roboto text-white">
                    {booking.service_name}
                  </div>
                  <div className="text-sm text-purple-200">
                    {formatDate(booking.booking_date)}
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span
                      className={`text-xs px-2 py-1 rounded ${
                        booking.status === "confirmed"
                          ? "bg-green-500"
                          : booking.status === "pending"
                          ? "bg-yellow-500"
                          : "bg-red-500"
                      } text-white`}
                    >
                      {booking.status}
                    </span>
                    {booking.status !== "cancelled" && (
                      <button
                        onClick={() => handleCancelBooking(booking.id)}
                        className="text-xs text-red-300 hover:text-red-400"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <h2 className="font-roboto text-lg mb-2 text-purple-200">
              Saved Places
            </h2>
            <div className="space-y-2">
              {savedPlaces.map((place, index) => (
                <div
                  key={index}
                  className="p-2 bg-white/10 backdrop-blur-md border border-white/20 rounded shadow-[0_0_15px_rgba(138,43,226,0.2)]"
                >
                  <div className="font-roboto text-white">{place.name}</div>
                  <div className="text-sm text-purple-200">{place.address}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] md:h-screen">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 shadow-lg p-4 overflow-x-auto">
            <div className="flex space-x-2 min-w-max">
              <button
                onClick={() => handleSendMessage("Find restaurants nearby")}
                className="bg-[#8A2BE2] text-white px-4 py-2 rounded hover:bg-[#9D4EE3] transition-all duration-300 shadow-[0_0_15px_rgba(138,43,226,0.5)] hover:shadow-[0_0_20px_rgba(138,43,226,0.8)] whitespace-nowrap"
              >
                <i className="fas fa-utensils mr-2"></i>Restaurants
              </button>
              <button
                onClick={() => handleSendMessage("Find tourist attractions")}
                className="bg-[#4169E1] text-white px-4 py-2 rounded hover:bg-[#5179E2] transition-all duration-300 shadow-[0_0_15px_rgba(65,105,225,0.5)] hover:shadow-[0_0_20px_rgba(65,105,225,0.8)] whitespace-nowrap"
              >
                <i className="fas fa-landmark mr-2"></i>Attractions
              </button>
              <button
                onClick={() => handleSendMessage("Find transportation options")}
                className="bg-[#9932CC] text-white px-4 py-2 rounded hover:bg-[#A442DD] transition-all duration-300 shadow-[0_0_15px_rgba(153,50,204,0.5)] hover:shadow-[0_0_20px_rgba(153,50,204,0.8)] whitespace-nowrap"
              >
                <i className="fas fa-bus mr-2"></i>Transport
              </button>
            </div>
          </div>
          <div
            ref={chatContainerRef}
            className="flex-1 overflow-y-auto p-4 space-y-4"
          >
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[85%] md:max-w-[70%] p-3 rounded-lg ${
                    message.role === "user"
                      ? "bg-[#8A2BE2] text-white shadow-[0_0_15px_rgba(138,43,226,0.3)]"
                      : "bg-white/10 backdrop-blur-md border border-white/20 text-white shadow-[0_0_15px_rgba(65,105,225,0.3)]"
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}
            {streamingMessage && (
              <div className="flex justify-start">
                <div className="max-w-[85%] md:max-w-[70%] p-3 rounded-lg bg-white/10 backdrop-blur-md border border-white/20 text-white shadow-[0_0_15px_rgba(65,105,225,0.3)]">
                  {streamingMessage}
                </div>
              </div>
            )}
          </div>
          <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 shadow-lg">
            {error && <div className="text-red-300 mb-2">{error}</div>}
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder="Ask me anything..."
                className="flex-1 p-2 bg-[#70798C] border border-white/30 rounded text-white placeholder-purple-200"
                disabled={loading}
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={loading}
                className="bg-[#8A2BE2] text-white px-6 py-2 rounded hover:bg-[#9D4EE3] transition-all duration-300 shadow-[0_0_15px_rgba(138,43,226,0.5)] hover:shadow-[0_0_20px_rgba(138,43,226,0.8)] disabled:bg-purple-400 disabled:shadow-none"
              >
                {loading ? (
                  <i className="fas fa-spinner fa-spin"></i>
                ) : (
                  <i className="fas fa-paper-plane"></i>
                )}
              </button>
            </div>
          </div>
          {showBookingModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg p-6 max-w-md w-full">
                <h3 className="text-xl font-roboto mb-4">Confirm Booking</h3>
                <div className="mb-4">
                  <p className="text-gray-700">{selectedService?.name}</p>
                  <p className="text-gray-600">{formatDate(selectedDate)}</p>
                  <p className="text-gray-600">People: {numberOfPeople}</p>
                  <p className="font-bold mt-2">
                    Total: ${selectedService?.price * numberOfPeople}
                  </p>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setShowBookingModal(false)}
                    className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmBooking}
                    disabled={bookingLoading}
                    className="bg-[#8A2BE2] text-white px-6 py-2 rounded hover:bg-[#9D4EE3]"
                  >
                    {bookingLoading ? (
                      <i className="fas fa-spinner fa-spin"></i>
                    ) : (
                      "Confirm & Pay"
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
          {showNotification && (
            <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 max-w-sm">
              <div className="flex items-center">
                <i
                  className={`fas fa-${
                    notificationType === "success"
                      ? "check-circle text-green-500"
                      : "exclamation-circle text-red-500"
                  } text-2xl mr-3`}
                ></i>
                <p className="flex-1">{notificationMessage}</p>
                <button
                  onClick={() => setShowNotification(false)}
                  className="ml-2 text-gray-400 hover:text-gray-600"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default MainComponent;