"use client";
import React from "react";

function MainComponent() {
  const [verifying, setVerifying] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [resending, setResending] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { data: user } = useUser();

  useEffect(() => {
    const verifyEmail = async () => {
      const params = new URLSearchParams(location.search);
      const token = params.get("token");
      const email = params.get("email");

      if (!token || !email) {
        setError("Invalid verification link. Please request a new one.");
        setVerifying(false);
        return;
      }

      try {
        const response = await fetch("/api/verify-email", {
          method: "POST",
          body: JSON.stringify({ token, email }),
        });

        if (!response.ok) {
          throw new Error("Verification failed");
        }

        const data = await response.json();

        if (data.error) {
          throw new Error(data.error);
        }

        setSuccess(true);
        setTimeout(() => {
          navigate("/account/profile");
        }, 3000);
      } catch (err) {
        console.error("Email verification error:", err);
        setError("Failed to verify email. The link may have expired.");
      } finally {
        setVerifying(false);
      }
    };

    verifyEmail();
  }, [location, navigate]);

  const handleResendVerification = async () => {
    setResending(true);
    setError(null);

    try {
      const response = await fetch("/api/send-verification-email", {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Failed to send verification email");
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }
    } catch (err) {
      console.error("Resend verification error:", err);
      setError("Failed to send verification email. Please try again.");
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-8">
          <img
            src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
            alt="Virtual Concierge Logo"
            className="h-12 w-auto mx-auto mb-4"
          />
          <h1 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-2">
            Email Verification
          </h1>
        </div>

        {verifying ? (
          <div className="text-center py-8">
            <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6] mb-4"></i>
            <p className="text-[#475569]">Verifying your email address...</p>
          </div>
        ) : success ? (
          <div className="text-center">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-check text-green-500 text-2xl"></i>
            </div>
            <h2 className="text-xl font-bold text-[#1e293b] mb-2">
              Email Verified Successfully!
            </h2>
            <p className="text-[#475569] mb-4">
              Redirecting you to your profile...
            </p>
          </div>
        ) : (
          <div>
            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                <p className="text-red-700">{error}</p>
              </div>
            )}

            <div className="text-center">
              <p className="text-[#475569] mb-6">
                {user
                  ? "Need a new verification link?"
                  : "Please sign in to verify your email address."}
              </p>

              {user && (
                <button
                  onClick={handleResendVerification}
                  disabled={resending}
                  className="w-full bg-[#3b82f6] text-white py-2 px-4 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {resending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Sending...
                    </>
                  ) : (
                    "Resend Verification Email"
                  )}
                </button>
              )}

              {!user && (
                <a
                  href="/account/signin"
                  className="block w-full bg-[#3b82f6] text-white py-2 px-4 rounded-lg hover:bg-[#2563eb] transition-colors text-center"
                >
                  Sign In
                </a>
              )}

              <a
                href="/"
                className="text-[#3b82f6] hover:text-[#2563eb] transition-colors mt-4 inline-block"
              >
                Return to Home
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;