"use client";
import React from "react";
import ProfileEnhancement from "../../components/profile-enhancement";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [isUpdating, setIsUpdating] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    display_name: "",
    phone: "",
    timezone: "",
    notification_preferences: {
      email: true,
      sms: false,
      push: true,
      marketing: false,
    },
    account_settings: {
      language: "en",
      currency: "USD",
      theme: "light",
    },
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/get-user-profile", {
          method: "POST",
        });

        if (!response.ok) {
          throw new Error("Failed to fetch profile");
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setFormData({
          display_name: data.user.display_name || "",
          phone: data.user.phone || "",
          timezone: data.user.timezone || "",
          notification_preferences: data.user.notification_preferences || {
            email: true,
            sms: false,
            push: true,
            marketing: false,
          },
          account_settings: data.user.account_settings || {
            language: "en",
            currency: "USD",
            theme: "light",
          },
        });
      } catch (err) {
        console.error(err);
        setError("Failed to load profile");
      }
    };

    if (user) {
      fetchProfile();
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsUpdating(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch("/api/update-user-profile", {
        method: "POST",
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to update profile");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      setError("Failed to update profile");
    } finally {
      setIsUpdating(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  if (!user) {
    window.location.href = "/account/signin?callbackUrl=/account/profile";
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] py-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-crimson-text font-bold text-[#1e293b] mb-8">
          User Profile
        </h1>

        <ProfileEnhancement
          user={user}
          loading={userLoading}
          profileData={formData}
          error={error}
          isEditing={isUpdating}
          onProfileUpdate={handleSubmit}
          onVerificationRequest={() => {}}
          onAddCustomField={() => {}}
          onAddProfileTag={() => {}}
          onEditToggle={() => setIsUpdating(!isUpdating)}
          onCustomFieldChange={() => {}}
          onNewTagChange={() => {}}
        />

        {success && (
          <div className="mt-4 p-4 bg-green-100 text-green-700 rounded">
            Profile updated successfully
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;