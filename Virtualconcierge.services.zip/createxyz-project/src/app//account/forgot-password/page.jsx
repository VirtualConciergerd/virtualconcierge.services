"use client";
import React from "react";

function MainComponent() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (attempts >= 5) {
      setError("Too many attempts. Please try again later.");
      return;
    }

    if (!email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i)) {
      setError("Please enter a valid email address");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/request-password-reset", {
        method: "POST",
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error("Failed to request password reset");
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setSuccess(true);
      setAttempts(0);
    } catch (err) {
      console.error("Password reset request error:", err);
      setError("Failed to send reset email. Please try again.");
      setAttempts((prev) => prev + 1);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-8">
          <img
            src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
            alt="Virtual Concierge Logo"
            className="h-12 w-auto mx-auto mb-4"
          />
          <h1 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-2">
            Reset Your Password
          </h1>
          <p className="text-[#475569]">
            Enter your email address and we'll send you instructions to reset
            your password.
          </p>
        </div>

        {success ? (
          <div className="text-center">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-check text-green-500 text-2xl"></i>
            </div>
            <p className="text-[#1e293b] mb-6">
              If an account exists with this email, you'll receive password
              reset instructions shortly.
            </p>
            <a
              href="/account/signin"
              className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            >
              Return to Sign In
            </a>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-[#1e293b] mb-2"
              >
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                placeholder="Enter your email"
                disabled={loading}
                required
              />
            </div>

            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4">
                <p className="text-red-700">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || attempts >= 5}
              className="w-full bg-[#3b82f6] text-white px-6 py-3 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Sending Instructions...
                </>
              ) : (
                "Send Reset Instructions"
              )}
            </button>

            <div className="text-center mt-4">
              <a
                href="/account/signin"
                className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
              >
                Back to Sign In
              </a>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default MainComponent;