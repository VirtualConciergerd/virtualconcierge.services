"use client";
import React from "react";
import EmergencyContactManager from "../../components/emergency-contact-manager";
import SecuritySettingsManager from "../../components/security-settings-manager";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [qrCode, setQrCode] = useState(null);
  const [backupCodes, setBackupCodes] = useState([]);
  const [verificationCode, setVerificationCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [connectedAccounts, setConnectedAccounts] = useState([]);
  const [accountsLoading, setAccountsLoading] = useState(false);
  const [accountsError, setAccountsError] = useState(null);
  const [activeSessions, setActiveSessions] = useState([]);
  const [loginHistory, setLoginHistory] = useState([]);
  const [status, setStatus] = useState({ message: "", type: "info" });

  useEffect(() => {
    const fetchAccounts = async () => {
      setAccountsLoading(true);
      setAccountsError(null);
      try {
        const response = await fetch("/api/manage-connected-accounts", {
          method: "POST",
          body: JSON.stringify({ action: "list" }),
        });
        if (!response.ok) {
          throw new Error("Failed to fetch connected accounts");
        }
        const data = await response.json();
        setConnectedAccounts(data.accounts || []);
      } catch (err) {
        console.error(err);
        setAccountsError("Failed to load connected accounts");
      } finally {
        setAccountsLoading(false);
      }
    };
    const fetchActiveSessions = async () => {
      try {
        const response = await fetch("/api/get-active-sessions", {
          method: "POST",
        });
        if (!response.ok) {
          throw new Error("Failed to fetch active sessions");
        }
        const data = await response.json();
        setActiveSessions(data.sessions || []);
      } catch (err) {
        console.error(err);
        setError("Failed to load active sessions");
      }
    };
    const fetchLoginHistory = async () => {
      try {
        const response = await fetch("/api/get-login-history", {
          method: "POST",
        });
        if (!response.ok) {
          throw new Error("Failed to fetch login history");
        }
        const data = await response.json();
        setLoginHistory(data.history || []);
      } catch (err) {
        console.error(err);
        setError("Failed to load login history");
      }
    };

    if (user) {
      fetchAccounts();
      fetchActiveSessions();
      fetchLoginHistory();
    }
  }, [user]);

  const handleConnect = async (provider) => {
    try {
      const response = await fetch("/api/manage-connected-accounts", {
        method: "POST",
        body: JSON.stringify({
          action: "connect",
          provider,
        }),
      });
      if (!response.ok) {
        throw new Error("Failed to connect account");
      }
      // Refresh accounts list
      const { accounts } = await fetch("/api/manage-connected-accounts", {
        method: "POST",
        body: JSON.stringify({ action: "list" }),
      }).then((res) => res.json());
      setConnectedAccounts(accounts || []);
      setStatus({
        message: `Successfully connected ${provider} account`,
        type: "success",
      });
    } catch (err) {
      console.error(err);
      setAccountsError("Failed to connect account");
      setStatus({
        message: `Failed to connect ${provider} account`,
        type: "error",
      });
    }
  };

  const handleDisconnect = async (accountId) => {
    try {
      await fetch("/api/manage-connected-accounts", {
        method: "POST",
        body: JSON.stringify({
          action: "disconnect",
          accountId,
        }),
      });
      setConnectedAccounts((accounts) =>
        accounts.filter((a) => a.id !== accountId)
      );
      setStatus({
        message: "Account disconnected successfully",
        type: "success",
      });
    } catch (err) {
      console.error(err);
      setAccountsError("Failed to disconnect account");
      setStatus({ message: "Failed to disconnect account", type: "error" });
    }
  };

  const revokeSession = async (sessionId) => {
    try {
      const response = await fetch("/api/revoke-session", {
        method: "POST",
        body: JSON.stringify({ sessionId }),
      });
      if (!response.ok) {
        throw new Error("Failed to revoke session");
      }
      await fetchActiveSessions();
      setStatus({ message: "Session revoked successfully", type: "success" });
    } catch (err) {
      console.error(err);
      setError("Failed to revoke session");
      setStatus({ message: "Failed to revoke session", type: "error" });
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  if (!user) {
    window.location.href = "/account/signin?callbackUrl=/settings/security";
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] py-12 px-4">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-3xl font-crimson-text font-bold text-[#1e293b]">
          Security Settings
        </h1>

        {status.message && (
          <div
            className={`p-4 rounded-lg ${
              status.type === "error"
                ? "bg-red-50 text-red-700 border-l-4 border-red-500"
                : status.type === "success"
                ? "bg-green-50 text-green-700 border-l-4 border-green-500"
                : "bg-blue-50 text-blue-700 border-l-4 border-blue-500"
            }`}
          >
            <div className="flex items-center">
              <i
                className={`fas fa-${
                  status.type === "error"
                    ? "exclamation-circle"
                    : status.type === "success"
                    ? "check-circle"
                    : "info-circle"
                } mr-2`}
              ></i>
              {status.message}
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
          <p className="text-blue-700">
            Two-factor authentication adds an extra layer of security to your
            account. Once enabled, you'll need both your password and an
            authentication code from your phone to log in.
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-[#1e293b] mb-4">
            Two-Factor Authentication
          </h2>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <i
                className={`fas ${
                  twoFactorEnabled
                    ? "fa-lock text-green-500"
                    : "fa-lock-open text-gray-400"
                }`}
              ></i>
              <span className="text-[#475569]">
                2FA Status: {twoFactorEnabled ? "Enabled" : "Disabled"}
              </span>
            </div>
            <button
              onClick={twoFactorEnabled ? disable2FA : setup2FA}
              className={`px-4 py-2 rounded ${
                twoFactorEnabled
                  ? "bg-red-500 text-white"
                  : "bg-[#3b82f6] text-white"
              }`}
              disabled={loading}
            >
              {loading ? (
                <i className="fas fa-spinner fa-spin"></i>
              ) : twoFactorEnabled ? (
                "Disable 2FA"
              ) : (
                "Setup 2FA"
              )}
            </button>
          </div>

          {qrCode && !twoFactorEnabled && (
            <div className="mb-6 p-6 border rounded-lg bg-gray-50">
              <h3 className="font-bold mb-4">Scan QR Code</h3>
              <img
                src={qrCode}
                alt="2FA QR Code"
                className="mx-auto mb-4 w-48 h-48"
              />
              <div className="space-y-4">
                <input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  placeholder="Enter 6-digit verification code"
                  className="w-full px-4 py-2 border rounded"
                  maxLength="6"
                />
                <button
                  onClick={verify2FA}
                  className="w-full bg-[#3b82f6] text-white px-4 py-2 rounded"
                  disabled={loading || verificationCode.length !== 6}
                >
                  {loading ? "Verifying..." : "Verify and Enable 2FA"}
                </button>
              </div>
            </div>
          )}

          {backupCodes.length > 0 && (
            <div className="mt-6 p-6 border rounded-lg bg-gray-50">
              <h3 className="font-bold mb-4">Backup Codes</h3>
              <p className="text-sm text-gray-600 mb-4">
                Save these backup codes in a secure place. You can use them to
                access your account if you lose your authentication device.
              </p>
              <div className="grid grid-cols-2 gap-2">
                {backupCodes.map((code, index) => (
                  <div
                    key={index}
                    className="bg-white p-2 rounded border font-mono text-center"
                  >
                    {code}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
          <p className="text-blue-700">
            Link your accounts to enable single sign-on and enhance account
            security. Verified accounts provide additional features and improved
            account recovery options.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-[#1e293b] mb-4">
            Connected Accounts
          </h2>

          <ConnectedAccounts
            accounts={connectedAccounts}
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
            loading={accountsLoading}
            error={accountsError}
          />
        </div>
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-[#1e293b] mb-4">
            Active Sessions
          </h2>
          <div className="space-y-4">
            {activeSessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center justify-between border-b pb-4"
              >
                <div>
                  <p className="font-medium text-[#1e293b]">
                    {session.device_info}
                  </p>
                  <p className="text-sm text-[#475569]">
                    IP: {session.ip_address}
                  </p>
                  <p className="text-sm text-[#475569]">
                    Last active:{" "}
                    {new Date(session.last_active).toLocaleString()}
                  </p>
                </div>
                <button
                  onClick={() => revokeSession(session.id)}
                  className="text-red-600 hover:text-red-800"
                >
                  <i className="fas fa-times-circle mr-2"></i>
                  Revoke
                </button>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-[#1e293b] mb-4">
            Login History
          </h2>
          <div className="space-y-4">
            {loginHistory.map((login) => (
              <div key={login.id} className="border-b pb-4">
                <div className="flex items-center">
                  <span
                    className={`w-2 h-2 rounded-full mr-2 ${
                      login.success ? "bg-green-500" : "bg-red-500"
                    }`}
                  ></span>
                  <p className="font-medium text-[#1e293b]">
                    {login.success ? "Successful login" : "Failed attempt"}
                  </p>
                </div>
                <p className="text-sm text-[#475569]">
                  {new Date(login.login_timestamp).toLocaleString()}
                </p>
                <p className="text-sm text-[#475569]">IP: {login.ip_address}</p>
                <p className="text-sm text-[#475569]">
                  Location: {login.location}
                </p>
                {!login.success && (
                  <p className="text-sm text-red-600">
                    Reason: {login.failure_reason}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6 mt-6">
          <EmergencyContactManager />
        </div>
        <div className="mt-6">
          <SecuritySettingsManager />
        </div>
      </div>
    </div>
  );
}

export default MainComponent;