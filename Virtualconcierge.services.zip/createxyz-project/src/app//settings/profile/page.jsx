"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [upload, { loading: uploadLoading }] = useUpload();
  const [isUpdating, setIsUpdating] = useState(false);
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState(null);
  const [activeSection, setActiveSection] = useState("profile");
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    bio: "",
    avatar_url: "",
    timezone: "UTC",
    privacy_settings: {
      profile_visibility: "public",
      email_visibility: true,
      phone_visibility: false,
    },
    security_settings: {
      two_factor_enabled: false,
      login_notifications: true,
    },
    connected_accounts: [],
    notification_preferences: {
      email: true,
      sms: false,
      push: true,
      marketing: false,
      frequency: "daily",
    },
    account_settings: {
      language: "en",
      currency: "USD",
      theme: "light",
      text_size: "medium",
      high_contrast: false,
      date_format: "MM/DD/YYYY",
      time_format: "12h",
    },
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/get-user-profile", {
          method: "POST",
        });

        if (!response.ok) {
          throw new Error("Failed to fetch profile");
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setFormData((prev) => ({
          ...prev,
          ...data,
          notification_preferences:
            data.notification_preferences || prev.notification_preferences,
          account_settings: data.account_settings || prev.account_settings,
        }));
      } catch (err) {
        console.error(err);
        setError("Failed to load profile");
      }
    };

    if (user) {
      fetchProfile();
    }
  }, [user]);

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const { url, error: uploadError } = await upload({ file });
      if (uploadError) throw new Error(uploadError);

      const response = await fetch("/api/upload-profile-image", {
        method: "POST",
        body: JSON.stringify({ image: url }),
      });

      if (!response.ok) throw new Error("Failed to update avatar");

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setFormData((prev) => ({ ...prev, avatar_url: data.avatar_url }));
      setSuccess("Profile picture updated successfully");
    } catch (err) {
      console.error(err);
      setError("Failed to update profile picture");
    }
  };
  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    setIsUpdating(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch("/api/update-user-profile", {
        method: "POST",
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error("Failed to update profile");

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setSuccess("Profile updated successfully");
      setHasUnsavedChanges(false);
    } catch (err) {
      console.error(err);
      setError("Failed to update profile");
    } finally {
      setIsUpdating(false);
    }
  };

  const handleToggleTwoFactor = async () => {
    try {
      const response = await fetch("/api/toggle-two-factor-auth", {
        method: "POST",
        body: JSON.stringify({
          enable: !formData.security_settings.two_factor_enabled,
        }),
      });

      if (!response.ok) throw new Error("Failed to update 2FA settings");

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setFormData((prev) => ({
        ...prev,
        security_settings: {
          ...prev.security_settings,
          two_factor_enabled: data.two_factor_enabled,
        },
      }));
      setSuccess("Two-factor authentication settings updated");
    } catch (err) {
      console.error(err);
      setError("Failed to update two-factor authentication settings");
    }
  };
  const handleConnectedAccount = async (accountType, action) => {
    try {
      const response = await fetch("/api/manage-connected-account", {
        method: "POST",
        body: JSON.stringify({ accountType, action }),
      });

      if (!response.ok) throw new Error("Failed to update connected account");

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setFormData((prev) => ({
        ...prev,
        connected_accounts: data.connected_accounts,
      }));
      setSuccess(`Successfully ${action}ed ${accountType} account`);
    } catch (err) {
      console.error(err);
      setError(`Failed to ${action} ${accountType} account`);
    }
  };

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = "";
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [hasUnsavedChanges]);

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  if (!user) {
    window.location.href = "/account/signin?callbackUrl=/settings/profile";
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-crimson-text font-bold text-[#1e293b]">
              Profile Settings
            </h1>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isUpdating}
              className="bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {isUpdating ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Saving...
                </>
              ) : (
                <>
                  <i className="fas fa-save mr-2"></i>
                  Save Changes
                </>
              )}
            </button>
          </div>

          {success && (
            <div className="mb-6 bg-green-50 border-l-4 border-green-500 p-4">
              <p className="text-green-700">{success}</p>
            </div>
          )}

          {error && (
            <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-1">
              <nav className="space-y-2">
                {[
                  "Profile",
                  "Privacy",
                  "Security",
                  "Connected Accounts",
                  "Notifications",
                  "Display",
                  "Regional",
                ].map((section) => (
                  <button
                    key={section}
                    onClick={() => setActiveSection(section.toLowerCase())}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                      activeSection === section.toLowerCase()
                        ? "bg-[#3b82f6] text-white"
                        : "text-[#1e293b] hover:bg-gray-100"
                    }`}
                  >
                    {section}
                  </button>
                ))}
              </nav>
            </div>

            <div className="md:col-span-3">
              <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
                {activeSection === "profile" && (
                  <div className="space-y-6">
                    <div className="flex flex-col items-center mb-6">
                      <div className="relative mb-4">
                        <img
                          src={
                            formData.avatar_url ||
                            "https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
                          }
                          alt="Profile avatar"
                          className="w-32 h-32 rounded-full object-cover border-4 border-[#3b82f6]"
                        />
                        <label className="absolute bottom-0 right-0 bg-[#3b82f6] text-white rounded-full p-2 cursor-pointer hover:bg-[#2563eb] transition-colors">
                          <i className="fas fa-camera"></i>
                          <input
                            type="file"
                            className="hidden"
                            accept="image/*"
                            onChange={handleAvatarUpload}
                          />
                        </label>
                      </div>
                      {uploadLoading && (
                        <p className="text-[#475569]">Uploading...</p>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-[#1e293b] mb-2">
                          Name
                        </label>
                        <input
                          type="text"
                          value={formData.name}
                          onChange={(e) => {
                            setFormData({ ...formData, name: e.target.value });
                            setHasUnsavedChanges(true);
                          }}
                          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                          name="name"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#1e293b] mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => {
                            setFormData({ ...formData, email: e.target.value });
                            setHasUnsavedChanges(true);
                          }}
                          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                          name="email"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#1e293b] mb-2">
                          Phone
                        </label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => {
                            setFormData({ ...formData, phone: e.target.value });
                            setHasUnsavedChanges(true);
                          }}
                          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                          name="phone"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#1e293b] mb-2">
                          Timezone
                        </label>
                        <select
                          value={formData.timezone}
                          onChange={(e) => {
                            setFormData({
                              ...formData,
                              timezone: e.target.value,
                            });
                            setHasUnsavedChanges(true);
                          }}
                          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                          name="timezone"
                        >
                          <option value="UTC">UTC</option>
                          <option value="America/New_York">Eastern Time</option>
                          <option value="America/Chicago">Central Time</option>
                          <option value="America/Denver">Mountain Time</option>
                          <option value="America/Los_Angeles">
                            Pacific Time
                          </option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#1e293b] mb-2">
                        Bio
                      </label>
                      <textarea
                        value={formData.bio}
                        onChange={(e) => {
                          setFormData({ ...formData, bio: e.target.value });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                        name="bio"
                        rows="4"
                      />
                    </div>
                  </div>
                )}

                {activeSection === "privacy" && (
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-[#1e293b] mb-4">
                        Profile Visibility
                      </label>
                      <div className="space-y-2">
                        {["public", "private", "contacts"].map((option) => (
                          <label
                            key={option}
                            className="flex items-center space-x-3"
                          >
                            <input
                              type="radio"
                              checked={
                                formData.privacy_settings.profile_visibility ===
                                option
                              }
                              onChange={() => {
                                setFormData({
                                  ...formData,
                                  privacy_settings: {
                                    ...formData.privacy_settings,
                                    profile_visibility: option,
                                  },
                                });
                                setHasUnsavedChanges(true);
                              }}
                              className="text-[#3b82f6] focus:ring-[#3b82f6]"
                            />
                            <span className="text-[#1e293b] capitalize">
                              {option}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[#1e293b]">
                          Show Email Address
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              privacy_settings: {
                                ...formData.privacy_settings,
                                email_visibility:
                                  !formData.privacy_settings.email_visibility,
                              },
                            });
                            setHasUnsavedChanges(true);
                          }}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            formData.privacy_settings.email_visibility
                              ? "bg-[#3b82f6]"
                              : "bg-gray-200"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              formData.privacy_settings.email_visibility
                                ? "translate-x-6"
                                : "translate-x-1"
                            }`}
                          />
                        </button>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[#1e293b]">
                          Show Phone Number
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              privacy_settings: {
                                ...formData.privacy_settings,
                                phone_visibility:
                                  !formData.privacy_settings.phone_visibility,
                              },
                            });
                            setHasUnsavedChanges(true);
                          }}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            formData.privacy_settings.phone_visibility
                              ? "bg-[#3b82f6]"
                              : "bg-gray-200"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              formData.privacy_settings.phone_visibility
                                ? "translate-x-6"
                                : "translate-x-1"
                            }`}
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "security" && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h3 className="text-lg font-medium text-[#1e293b]">
                          Two-Factor Authentication
                        </h3>
                        <p className="text-[#475569]">
                          Add an extra layer of security to your account
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleToggleTwoFactor}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          formData.security_settings.two_factor_enabled
                            ? "bg-[#3b82f6]"
                            : "bg-gray-200"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            formData.security_settings.two_factor_enabled
                              ? "translate-x-6"
                              : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h3 className="text-lg font-medium text-[#1e293b]">
                          Login Notifications
                        </h3>
                        <p className="text-[#475569]">
                          Get notified of new sign-ins to your account
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData({
                            ...formData,
                            security_settings: {
                              ...formData.security_settings,
                              login_notifications:
                                !formData.security_settings.login_notifications,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          formData.security_settings.login_notifications
                            ? "bg-[#3b82f6]"
                            : "bg-gray-200"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            formData.security_settings.login_notifications
                              ? "translate-x-6"
                              : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Password
                      </h3>
                      <a
                        href="/account/reset-password"
                        className="inline-flex items-center px-4 py-2 border border-[#3b82f6] text-[#3b82f6] rounded-lg hover:bg-[#3b82f6] hover:text-white transition-colors"
                      >
                        <i className="fas fa-key mr-2"></i>
                        Change Password
                      </a>
                    </div>
                  </div>
                )}

                {activeSection === "connected accounts" && (
                  <div className="space-y-6">
                    {["google", "facebook", "twitter", "github"].map(
                      (platform) => (
                        <div
                          key={platform}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center">
                            <i
                              className={`fab fa-${platform} text-2xl mr-4 text-[#1e293b]`}
                            ></i>
                            <div>
                              <h3 className="text-lg font-medium text-[#1e293b] capitalize">
                                {platform}
                              </h3>
                              <p className="text-[#475569]">
                                {formData.connected_accounts.includes(platform)
                                  ? `Connected to ${platform}`
                                  : `Connect to ${platform}`}
                              </p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              handleConnectedAccount(
                                platform,
                                formData.connected_accounts.includes(platform)
                                  ? "remove"
                                  : "add"
                              )
                            }
                            className={`px-4 py-2 rounded-lg transition-colors ${
                              formData.connected_accounts.includes(platform)
                                ? "bg-red-500 text-white hover:bg-red-600"
                                : "bg-[#3b82f6] text-white hover:bg-[#2563eb]"
                            }`}
                          >
                            {formData.connected_accounts.includes(platform)
                              ? "Disconnect"
                              : "Connect"}
                          </button>
                        </div>
                      )
                    )}
                  </div>
                )}

                {activeSection === "notifications" && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Email Notifications
                      </h3>
                      <div className="space-y-4">
                        {Object.entries(formData.notification_preferences).map(
                          ([key, value]) =>
                            key !== "frequency" && (
                              <div
                                key={key}
                                className="flex items-center justify-between"
                              >
                                <span className="text-[#1e293b] capitalize">
                                  {key} Notifications
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setFormData({
                                      ...formData,
                                      notification_preferences: {
                                        ...formData.notification_preferences,
                                        [key]: !value,
                                      },
                                    });
                                    setHasUnsavedChanges(true);
                                  }}
                                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                                    value ? "bg-[#3b82f6]" : "bg-gray-200"
                                  }`}
                                >
                                  <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                      value ? "translate-x-6" : "translate-x-1"
                                    }`}
                                  />
                                </button>
                              </div>
                            )
                        )}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Notification Frequency
                      </h3>
                      <select
                        value={formData.notification_preferences.frequency}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            notification_preferences: {
                              ...formData.notification_preferences,
                              frequency: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                      </select>
                    </div>
                  </div>
                )}

                {activeSection === "display" && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Theme
                      </h3>
                      <select
                        value={formData.account_settings.theme}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              theme: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="light">Light</option>
                        <option value="dark">Dark</option>
                      </select>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Text Size
                      </h3>
                      <select
                        value={formData.account_settings.text_size}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              text_size: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-medium text-[#1e293b]">
                          High Contrast
                        </h3>
                        <p className="text-[#475569]">
                          Increase contrast for better visibility
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              high_contrast:
                                !formData.account_settings.high_contrast,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          formData.account_settings.high_contrast
                            ? "bg-[#3b82f6]"
                            : "bg-gray-200"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            formData.account_settings.high_contrast
                              ? "translate-x-6"
                              : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                )}

                {activeSection === "regional" && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Language
                      </h3>
                      <select
                        value={formData.account_settings.language}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              language: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="en">English</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                      </select>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Currency
                      </h3>
                      <select
                        value={formData.account_settings.currency}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              currency: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="USD">USD ($)</option>
                        <option value="EUR">EUR (€)</option>
                        <option value="GBP">GBP (£)</option>
                      </select>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Date Format
                      </h3>
                      <select
                        value={formData.account_settings.date_format}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              date_format: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                        <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                        <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                      </select>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium text-[#1e293b] mb-4">
                        Time Format
                      </h3>
                      <select
                        value={formData.account_settings.time_format}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            account_settings: {
                              ...formData.account_settings,
                              time_format: e.target.value,
                            },
                          });
                          setHasUnsavedChanges(true);
                        }}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      >
                        <option value="12h">12-hour</option>
                        <option value="24h">24-hour</option>
                      </select>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;