"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: authLoading } = useUser();
  const [orderDetails, setOrderDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();
  const searchParams = new URLSearchParams(window.location.search);
  const sessionId = searchParams.get("session_id");

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/account/signin?callbackUrl=/orders/confirmation");
      return;
    }

    if (sessionId && user) {
      handleOrderConfirmation();
    }
  }, [user, authLoading, sessionId, router]);

  async function handleOrderConfirmation() {
    try {
      const response = await fetch("/api/handle-order-confirmation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });

      if (!response.ok) {
        throw new Error("Failed to confirm order");
      }

      const { orderId } = await response.json();

      const statusResponse = await fetch("/api/get-order-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });

      if (!statusResponse.ok) {
        throw new Error("Failed to get order details");
      }

      const orderData = await statusResponse.json();
      setOrderDetails(orderData);
    } catch (err) {
      console.error("Confirmation error:", err);
      setError("Unable to confirm your order. Please contact support.");
    } finally {
      setLoading(false);
    }
  }

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
          <p className="mt-4 text-[#475569]">Confirming your order...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
            {error}
          </div>
          <button
            onClick={() => router.push("/cart")}
            className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
          >
            Return to Cart
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <i className="fas fa-check-circle text-green-500 text-5xl mb-4"></i>
            <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold">
              Order Confirmed!
            </h1>
            <p className="text-[#475569] mt-2">
              Thank you for your purchase. We've sent a confirmation email with
              your order details.
            </p>
          </div>

          {orderDetails && (
            <>
              <div className="border-t border-b border-gray-200 py-4 mb-6">
                <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                  Order Details
                </h2>
                <div className="space-y-2">
                  <p className="text-[#475569]">
                    <span className="font-semibold">Order ID:</span> #
                    {orderDetails.orderId}
                  </p>
                  <p className="text-[#475569]">
                    <span className="font-semibold">Status:</span>{" "}
                    <span className="capitalize">{orderDetails.status}</span>
                  </p>
                  <p className="text-[#475569]">
                    <span className="font-semibold">Date:</span>{" "}
                    {new Date(orderDetails.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-crimson-text text-[#1e293b] font-bold mb-4">
                  Items Ordered
                </h3>
                <div className="space-y-4">
                  {orderDetails.items.map((item, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center"
                    >
                      <div>
                        <p className="font-semibold text-[#1e293b]">
                          {item.name}
                        </p>
                        <p className="text-sm text-[#475569]">
                          Quantity: {item.quantity}
                        </p>
                      </div>
                      <p className="text-[#1e293b]">${item.price.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4 mb-6">
                <div className="flex justify-between items-center text-xl font-bold text-[#1e293b]">
                  <span>Total</span>
                  <span>${orderDetails.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-crimson-text text-[#1e293b] font-bold mb-2">
                  Shipping Address
                </h3>
                <p className="text-[#475569]">{orderDetails.shippingAddress}</p>
              </div>

              <div className="flex justify-center space-x-4">
                <button
                  onClick={() => router.push("/")}
                  className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
                >
                  Continue Shopping
                </button>
                <button
                  onClick={() => router.push("/orders")}
                  className="bg-white text-[#3b82f6] border border-[#3b82f6] px-6 py-2 rounded-full hover:bg-gray-50 transition-colors"
                >
                  View All Orders
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;