"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await fetch("/api/order-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "listUserOrders",
            data: { userId: "123" },
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch orders");
        }

        const data = await response.json();
        setOrders(data.orders || []);
      } catch (err) {
        console.error(err);
        setError("Could not load your orders");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  const getStatusColor = (status) => {
    const statusColors = {
      pending: "text-yellow-600 bg-yellow-100",
      processing: "text-blue-600 bg-blue-100",
      shipped: "text-green-600 bg-green-100",
      delivered: "text-green-800 bg-green-100",
      cancelled: "text-red-600 bg-red-100",
    };
    return statusColors[status] || "text-gray-600 bg-gray-100";
  };

  const getStatusIcon = (status) => {
    const statusIcons = {
      pending: "fa-clock",
      processing: "fa-cog",
      shipped: "fa-shipping-fast",
      delivered: "fa-check-circle",
      cancelled: "fa-times-circle",
    };
    return statusIcons[status] || "fa-question-circle";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
        <div className="max-w-7xl mx-auto text-center py-12">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <nav className="fixed w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-crimson-text text-[#1e293b] font-bold">
            Virtual Concierge
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => navigate("/cart")}
              className="text-[#1e293b] hover:text-[#3b82f6] transition-colors"
            >
              <i className="fas fa-shopping-cart"></i>
            </button>
            <button
              onClick={() => navigate("/")}
              className="text-[#1e293b] hover:text-[#3b82f6] transition-colors"
            >
              <i className="fas fa-home"></i>
            </button>
          </div>
        </div>
      </nav>

      <main className="pt-24 px-4 pb-12">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-8">
            My Orders
          </h1>

          {error && (
            <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
              {error}
            </div>
          )}

          {orders.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg shadow">
              <i className="fas fa-shopping-bag text-4xl text-[#3b82f6] mb-4"></i>
              <p className="text-[#475569] text-lg">
                You haven't placed any orders yet
              </p>
              <button
                onClick={() => navigate("/")}
                className="mt-4 bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-lg shadow-lg p-6"
                >
                  <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                    <div>
                      <h2 className="font-crimson-text text-xl font-bold text-[#1e293b] mb-2">
                        Order #{order.id}
                      </h2>
                      <p className="text-[#475569]">
                        Placed on{" "}
                        {new Date(order.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div
                      className={`px-4 py-2 rounded-full flex items-center ${getStatusColor(
                        order.status
                      )}`}
                    >
                      <i
                        className={`fas ${getStatusIcon(order.status)} mr-2`}
                      ></i>
                      <span className="capitalize">{order.status}</span>
                    </div>
                  </div>

                  <div className="border-t border-b border-gray-200 py-4 mb-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-bold text-[#1e293b] mb-2">
                          Shipping Address
                        </h3>
                        <p className="text-[#475569]">
                          {order.shipping_address}
                        </p>
                      </div>
                      <div>
                        <h3 className="font-bold text-[#1e293b] mb-2">
                          Order Summary
                        </h3>
                        <p className="text-[#475569]">
                          Total Amount:{" "}
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(order.total_amount)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {order.status === "shipped" && (
                    <div className="mb-4">
                      <h3 className="font-bold text-[#1e293b] mb-2">
                        Tracking Information
                      </h3>
                      <p className="text-[#475569]">
                        Tracking Number: {order.tracking_number}
                      </p>
                      <div className="mt-2 flex space-x-2">
                        <i className="fas fa-truck text-[#3b82f6]"></i>
                        <p className="text-[#475569]">
                          Estimated delivery:{" "}
                          {new Date(
                            order.estimated_delivery
                          ).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end">
                    <button
                      onClick={() =>
                        navigate(`/virtual-concierge?order=${order.id}`)
                      }
                      className="text-[#3b82f6] hover:text-[#2563eb] transition-colors flex items-center"
                    >
                      <span>Need help with this order?</span>
                      <i className="fas fa-arrow-right ml-2"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default MainComponent;