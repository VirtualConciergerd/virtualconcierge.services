"use client";
import React from "react";

function MainComponent() {
  const [cart, setCart] = useState([]);
  const [savedItems, setSavedItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updateLoading, setUpdateLoading] = useState({});
  const [relatedProducts, setRelatedProducts] = useState([]);
  const { data: user, loading: authLoading } = useUser();

  const fetchCart = useCallback(async () => {
    try {
      setError(null);
      const response = await fetch("/api/cart-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "getCart",
          data: { userId: user?.id },
        }),
      });

      if (!response.ok) {
        throw new Error(`Error fetching cart: ${response.status}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setCart(data.items || []);
      localStorage.setItem(`cart_${user.id}`, JSON.stringify(data.items || []));
    } catch (err) {
      console.error("Cart fetch error:", err);
      setError("Could not load your cart. Please try again later.");
    } finally {
      setLoading(false);
    }
  }, [user]);

  const recoverCart = useCallback(
    async (savedCart) => {
      try {
        const response = await fetch("/api/cart-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "recoverCart",
            data: { userId: user?.id, items: savedCart },
          }),
        });

        if (!response.ok) {
          throw new Error(`Error recovering cart: ${response.status}`);
        }

        await fetchCart();
      } catch (err) {
        console.error("Cart recovery error:", err);
        setError("Could not recover your saved cart.");
      }
    },
    [user, fetchCart]
  );

  const saveForLater = useCallback(
    async (itemId) => {
      try {
        const item = cart.find((i) => i.id === itemId);
        if (!item) return;

        setSavedItems((prev) => [...prev, item]);

        await fetch("/api/cart-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "removeItem",
            data: { userId: user?.id, itemId },
          }),
        });

        await fetchCart();
      } catch (err) {
        console.error("Save for later error:", err);
        setError("Could not save item for later.");
      }
    },
    [cart, user, fetchCart]
  );

  const moveToCart = useCallback(
    async (itemId) => {
      try {
        const item = savedItems.find((i) => i.id === itemId);
        if (!item) return;

        setSavedItems((prev) => prev.filter((i) => i.id !== itemId));

        await fetch("/api/cart-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "addItem",
            data: { userId: user?.id, itemId, quantity: 1 },
          }),
        });

        await fetchCart();
      } catch (err) {
        console.error("Move to cart error:", err);
        setError("Could not move item to cart.");
      }
    },
    [savedItems, user, fetchCart]
  );

  const removeFromCart = useCallback(
    async (itemId) => {
      try {
        await fetch("/api/cart-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "removeItem",
            data: { userId: user?.id, itemId },
          }),
        });

        await fetchCart();
      } catch (err) {
        console.error("Remove from cart error:", err);
        setError("Could not remove item from cart.");
      }
    },
    [user, fetchCart]
  );

  useEffect(() => {
    if (user) {
      fetchCart();
      const savedCart = localStorage.getItem(`cart_${user.id}`);
      if (savedCart && cart.length === 0) {
        recoverCart(JSON.parse(savedCart));
      }
    } else {
      setLoading(false);
    }
  }, [user, fetchCart]);

  const updateQuantity = useCallback(
    async (itemId, quantity) => {
      if (quantity < 0 || quantity > 99) {
        setError("Quantity must be between 0 and 99");
        return;
      }

      try {
        setError(null);
        setUpdateLoading((prev) => ({ ...prev, [itemId]: true }));

        const response = await fetch("/api/cart-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "updateQuantity",
            data: { userId: user?.id, itemId, quantity },
          }),
        });

        if (!response.ok) {
          throw new Error(`Error updating cart: ${response.status}`);
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        await fetchCart();
      } catch (err) {
        console.error("Update quantity error:", err);
        setError("Could not update item quantity. Please try again.");
      } finally {
        setUpdateLoading((prev) => ({ ...prev, [itemId]: false }));
      }
    },
    [fetchCart, user]
  );

  const formatPrice = (price) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const subtotal = useMemo(() => {
    try {
      return cart.reduce((sum, item) => {
        const itemTotal = item.price * item.quantity;
        if (isNaN(itemTotal)) throw new Error("Invalid price calculation");
        return sum + itemTotal;
      }, 0);
    } catch (err) {
      console.error("Subtotal calculation error:", err);
      return 0;
    }
  }, [cart]);

  const tax = useMemo(() => {
    try {
      const calculatedTax = subtotal * 0.0825;
      if (isNaN(calculatedTax)) throw new Error("Invalid tax calculation");
      return calculatedTax;
    } catch (err) {
      console.error("Tax calculation error:", err);
      return 0;
    }
  }, [subtotal]);

  const shipping = cart.length > 0 ? 9.99 : 0;
  const total = subtotal + tax + shipping;

  const handleCheckout = async () => {
    if (!user) {
      window.location.href = "/account/signin?callbackUrl=/cart";
      return;
    }

    if (cart.length === 0) {
      setError("Your cart is empty");
      return;
    }

    try {
      setError(null);
      setLoading(true);

      const orderResponse = await fetch("/api/order-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "createOrder",
          data: {
            userId: user.id,
            items: cart.map((item) => ({
              id: item.id,
              price: item.price,
              quantity: item.quantity,
            })),
            totalAmount: total,
            shippingAddress: "123 Main St",
          },
        }),
      });

      if (!orderResponse.ok) {
        throw new Error(`Error creating order: ${orderResponse.status}`);
      }

      const clearCartResponse = await fetch("/api/cart-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "clearCart",
          data: { userId: user.id },
        }),
      });

      if (!clearCartResponse.ok) {
        throw new Error(`Error clearing cart: ${clearCartResponse.status}`);
      }

      window.location.href = "/orders";
    } catch (err) {
      console.error("Checkout error:", err);
      setError("Could not process your order. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  if (loading || authLoading) {
    return (
      <ErrorBoundary>
        <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="animate-pulse space-y-8">
              <div className="h-8 bg-gray-200 rounded w-1/4"></div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 space-y-4">
                  {[1, 2].map((i) => (
                    <div key={i} className="bg-gray-200 h-32 rounded"></div>
                  ))}
                </div>
                <div className="bg-gray-200 h-64 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-8">
            Your Cart
          </h1>

          {error && (
            <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
              {error}
            </div>
          )}

          {!user ? (
            <div className="text-center py-12 bg-white rounded-lg shadow-sm">
              <p className="text-xl text-[#475569] mb-6">
                Please sign in to view your cart
              </p>
              <button
                onClick={() => {
                  window.location.href = "/account/signin?callbackUrl=/cart";
                }}
                className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
              >
                Sign In
              </button>
            </div>
          ) : cart.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg shadow-sm">
              <i className="fas fa-shopping-cart text-4xl text-[#3b82f6] mb-4"></i>
              <p className="text-xl text-[#475569] mb-6">Your cart is empty</p>
              <button
                onClick={() => {
                  window.location.href = "/";
                }}
                className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-8">
              <div className="lg:col-span-2 space-y-4">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white p-4 rounded-lg shadow-sm"
                  >
                    <div className="flex flex-col sm:flex-row gap-4">
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="w-full sm:w-24 h-24 object-cover rounded"
                      />
                      <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-start">
                          <h3 className="font-crimson-text text-xl text-[#1e293b] font-bold">
                            {item.name}
                          </h3>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => saveForLater(item.id)}
                              className="text-[#475569] hover:text-[#1e293b]"
                              title="Save for later"
                            >
                              <i className="fas fa-bookmark"></i>
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="text-red-500 hover:text-red-700"
                              title="Remove item"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                          <div className="flex items-center space-x-4">
                            <button
                              onClick={() =>
                                updateQuantity(
                                  item.id,
                                  Math.max(0, item.quantity - 1)
                                )
                              }
                              className="text-[#475569] hover:text-[#1e293b] disabled:opacity-50"
                              disabled={
                                updateLoading[item.id] || item.quantity <= 1
                              }
                            >
                              <i className="fas fa-minus"></i>
                            </button>
                            <span className="font-bold text-[#1e293b]">
                              {updateLoading[item.id] ? (
                                <i className="fas fa-spinner fa-spin text-sm"></i>
                              ) : (
                                item.quantity
                              )}
                            </span>
                            <button
                              onClick={() =>
                                updateQuantity(item.id, item.quantity + 1)
                              }
                              className="text-[#475569] hover:text-[#1e293b] disabled:opacity-50"
                              disabled={
                                updateLoading[item.id] ||
                                item.quantity >= item.stock ||
                                item.quantity >= 99
                              }
                            >
                              <i className="fas fa-plus"></i>
                            </button>
                          </div>
                          <div className="flex flex-col items-end">
                            <span className="font-bold text-[#1e293b]">
                              {formatPrice(item.price * item.quantity)}
                            </span>
                            <span
                              className={`text-sm ${
                                item.stock < 5
                                  ? "text-red-500"
                                  : "text-green-500"
                              }`}
                            >
                              {item.stock < 5
                                ? `Only ${item.stock} left!`
                                : "In Stock"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm h-fit">
                <h2 className="font-crimson-text text-2xl text-[#1e293b] font-bold mb-6">
                  Order Summary
                </h2>
                <div className="space-y-4">
                  <div className="flex justify-between text-[#475569]">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-[#475569]">
                    <span>Tax</span>
                    <span>{formatPrice(tax)}</span>
                  </div>
                  <div className="flex justify-between text-[#475569]">
                    <span>Shipping</span>
                    <span>{formatPrice(shipping)}</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between font-bold text-[#1e293b] text-xl">
                      <span>Total</span>
                      <span>{formatPrice(total)}</span>
                    </div>
                  </div>
                  <button
                    onClick={handleCheckout}
                    disabled={loading || cart.length === 0}
                    className="w-full bg-[#3b82f6] text-white py-3 rounded-full hover:bg-[#2563eb] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <i className="fas fa-spinner fa-spin"></i>
                    ) : (
                      "Proceed to Checkout"
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {savedItems.length > 0 && (
            <div className="mt-8">
              <h2 className="font-crimson-text text-2xl text-[#1e293b] font-bold mb-6">
                Saved for Later
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {savedItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white p-4 rounded-lg shadow-sm"
                  >
                    <img
                      src={item.image_url}
                      alt={item.name}
                      className="w-full h-48 object-cover rounded mb-4"
                    />
                    <h3 className="font-crimson-text text-lg text-[#1e293b] font-bold mb-2">
                      {item.name}
                    </h3>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-[#1e293b]">
                        {formatPrice(item.price)}
                      </span>
                      <button
                        onClick={() => moveToCart(item.id)}
                        className="text-[#3b82f6] hover:text-[#2563eb]"
                      >
                        Move to Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {relatedProducts.length > 0 && (
            <div className="mt-16">
              <h2 className="font-crimson-text text-2xl text-[#1e293b] font-bold mb-6">
                You Might Also Like
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {relatedProducts.slice(0, 3).map((product) => (
                  <></>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default MainComponent;