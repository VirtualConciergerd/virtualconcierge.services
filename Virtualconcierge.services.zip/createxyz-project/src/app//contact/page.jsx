"use client";
import React from "react";

function MainComponent() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [status, setStatus] = useState({ type: "", message: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          data: {
            message: `New contact form submission from ${formData.name}: ${formData.message}`,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to send message");

      setStatus({ type: "success", message: "Message sent successfully!" });
      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (error) {
      setStatus({
        type: "error",
        message: "Failed to send message. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h1 className="text-4xl md:text-6xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
          Contact Us
        </h1>

        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <form
              onSubmit={handleSubmit}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="mb-6">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your Name"
                  className="w-full p-3 border rounded font-roboto"
                  required
                />
              </div>
              <div className="mb-6">
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Your Email"
                  className="w-full p-3 border rounded font-roboto"
                  required
                />
              </div>
              <div className="mb-6">
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="Subject"
                  className="w-full p-3 border rounded font-roboto"
                  required
                />
              </div>
              <div className="mb-6">
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Your Message"
                  className="w-full p-3 border rounded font-roboto h-32"
                  required
                />
              </div>
              {status.message && (
                <div
                  className={`mb-6 p-3 rounded ${
                    status.type === "success"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {status.message}
                </div>
              )}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#3b82f6] text-white px-6 py-3 rounded-full hover:bg-[#2563eb] transition-colors disabled:bg-[#93c5fd]"
              >
                {loading ? "Sending..." : "Send Message"}
              </button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-4">
                Office Hours
              </h2>
              <div className="space-y-2 font-roboto">
                <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                <p>Saturday: 10:00 AM - 4:00 PM</p>
                <p>Sunday: Closed</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-4">
                Connect With Us
              </h2>
              <div className="space-y-4 font-roboto">
                <p className="flex items-center">
                  <i className="fas fa-envelope text-[#3b82f6] mr-3"></i>
                  support@virtualconcierge.com
                </p>
                <div className="flex space-x-4">
                  <a href="#" className="text-[#3b82f6] hover:text-[#2563eb]">
                    <i className="fab fa-twitter text-2xl"></i>
                  </a>
                  <a href="#" className="text-[#3b82f6] hover:text-[#2563eb]">
                    <i className="fab fa-facebook text-2xl"></i>
                  </a>
                  <a href="#" className="text-[#3b82f6] hover:text-[#2563eb]">
                    <i className="fab fa-instagram text-2xl"></i>
                  </a>
                  <a href="#" className="text-[#3b82f6] hover:text-[#2563eb]">
                    <i className="fab fa-linkedin text-2xl"></i>
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-4">
                Support
              </h2>
              <p className="font-roboto mb-4">
                Need immediate assistance? Our support team is here to help you
                24/7.
              </p>
              <button className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors">
                Live Chat
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-8 text-center">
            Frequently Asked Questions
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-crimson-text text-xl text-[#1e293b] font-bold mb-3">
                How do I get started?
              </h3>
              <p className="font-roboto text-[#475569]">
                Simply sign up for an account and our virtual concierge will
                guide you through the process of planning your perfect trip.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-crimson-text text-xl text-[#1e293b] font-bold mb-3">
                Is the service available 24/7?
              </h3>
              <p className="font-roboto text-[#475569]">
                Yes, our AI concierge is available around the clock to assist
                you with any questions or travel planning needs.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-crimson-text text-xl text-[#1e293b] font-bold mb-3">
                Can I modify my bookings?
              </h3>
              <p className="font-roboto text-[#475569]">
                Yes, you can modify or cancel your bookings through your account
                dashboard or by contacting our support team.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-crimson-text text-xl text-[#1e293b] font-bold mb-3">
                What languages are supported?
              </h3>
              <p className="font-roboto text-[#475569]">
                We currently support English, Spanish, French, and German, with
                more languages coming soon.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;