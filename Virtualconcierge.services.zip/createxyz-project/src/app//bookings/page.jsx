"use client";
import React from "react";

function MainComponent() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [selectedBooking, setSelectedBooking] = useState(null);
  const { data: user } = useUser();

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch("/api/my-bookings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: user?.id }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch bookings");
        }

        const data = await response.json();
        setBookings(data);
      } catch (err) {
        console.error("Error fetching bookings:", err);
        setError("Could not load your bookings. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    if (user?.id) {
      fetchBookings();
    }
  }, [user]);

  const handleCancelBooking = async (bookingId) => {
    try {
      const response = await fetch("/api/cancel-booking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookingId }),
      });

      if (!response.ok) {
        throw new Error("Failed to cancel booking");
      }

      setBookings(
        bookings.map((booking) =>
          booking.id === bookingId
            ? { ...booking, status: "cancelled" }
            : booking
        )
      );
    } catch (err) {
      console.error("Error canceling booking:", err);
      setError("Could not cancel the booking. Please try again.");
    }
  };

  const filteredBookings = bookings.filter((booking) => {
    const matchesStatus =
      statusFilter === "all" || booking.status === statusFilter;
    const bookingDate = new Date(booking.date);
    const today = new Date();

    let matchesDate = true;
    if (dateFilter === "upcoming") {
      matchesDate = bookingDate > today;
    } else if (dateFilter === "past") {
      matchesDate = bookingDate < today;
    }

    return matchesStatus && matchesDate;
  });

  const upcomingBookings = bookings.filter(
    (booking) =>
      new Date(booking.date) > new Date() && booking.status !== "cancelled"
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#3b82f6] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">My Bookings</span>
        </nav>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {upcomingBookings.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Upcoming Bookings
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingBookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-white rounded-lg shadow-lg p-6"
                >
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-[#1e293b]">
                      {booking.serviceName}
                    </h3>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium
                      ${
                        booking.status === "confirmed"
                          ? "bg-green-100 text-green-800"
                          : booking.status === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {booking.status}
                    </span>
                  </div>
                  <p className="text-[#475569] mb-4">
                    <i className="far fa-calendar mr-2"></i>
                    {new Date(booking.date).toLocaleDateString()}
                  </p>
                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setSelectedBooking(booking)}
                      className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                    >
                      View Details
                    </button>
                    {booking.status !== "cancelled" && (
                      <button
                        onClick={() => handleCancelBooking(booking.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-4 md:mb-0">
              All Bookings
            </h2>
            <div className="flex flex-col md:flex-row gap-4">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
                <option value="completed">Completed</option>
              </select>
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              >
                <option value="all">All Dates</option>
                <option value="upcoming">Upcoming</option>
                <option value="past">Past</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredBookings.map((booking) => (
                  <tr key={booking.id}>
                    <td className="px-6 py-4">
                      <a
                        href={`/services/${booking.serviceId}`}
                        className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                      >
                        {booking.serviceName}
                      </a>
                    </td>
                    <td className="px-6 py-4 text-[#475569]">
                      {new Date(booking.date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                        ${
                          booking.status === "confirmed"
                            ? "bg-green-100 text-green-800"
                            : booking.status === "pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : booking.status === "cancelled"
                            ? "bg-red-100 text-red-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-[#475569]">
                      ${booking.price}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-4">
                        <button
                          onClick={() => setSelectedBooking(booking)}
                          className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                        >
                          <i className="fas fa-eye"></i>
                        </button>
                        {booking.status !== "cancelled" &&
                          booking.status !== "completed" && (
                            <button
                              onClick={() => handleCancelBooking(booking.id)}
                              className="text-red-500 hover:text-red-700 transition-colors"
                            >
                              <i className="fas fa-times"></i>
                            </button>
                          )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-[#1e293b]">
                Booking Details
              </h3>
              <button
                onClick={() => setSelectedBooking(null)}
                className="text-[#475569] hover:text-[#1e293b] transition-colors"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#475569]">
                  Service
                </label>
                <p className="text-[#1e293b]">{selectedBooking.serviceName}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#475569]">
                  Date
                </label>
                <p className="text-[#1e293b]">
                  {new Date(selectedBooking.date).toLocaleDateString()}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#475569]">
                  Status
                </label>
                <p className="text-[#1e293b]">{selectedBooking.status}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#475569]">
                  Price
                </label>
                <p className="text-[#1e293b]">${selectedBooking.price}</p>
              </div>
              {selectedBooking.notes && (
                <div>
                  <label className="block text-sm font-medium text-[#475569]">
                    Notes
                  </label>
                  <p className="text-[#1e293b]">{selectedBooking.notes}</p>
                </div>
              )}
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedBooking(null)}
                className="bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;