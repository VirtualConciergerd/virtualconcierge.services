"use client";
import React from "react";

function MainComponent() {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedBusinesses, setSelectedBusinesses] = useState([]);
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [businessType, setBusinessType] = useState("all");
  const { data: user } = useUser();

  useEffect(() => {
    if (user && user.role !== "admin") {
      window.location.href = "/";
    }
  }, [user]);

  const fetchFollowUps = async () => {
    try {
      const response = await fetch("/api/schedule-pending-follow-up", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dateRange,
          businessType: businessType === "all" ? null : businessType,
        }),
      });

      if (!response.ok) throw new Error("Failed to fetch follow-ups");
      const data = await response.json();
      setBusinesses(data);
    } catch (err) {
      setError("Could not load follow-ups");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFollowUps();
  }, [dateRange, businessType]);

  const handleBulkAction = async (action) => {
    if (!selectedBusinesses.length) return;

    try {
      const response = await fetch("/api/update-business-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businesses: selectedBusinesses,
          status: action,
        }),
      });

      if (!response.ok) throw new Error(`Failed to ${action} businesses`);
      fetchFollowUps();
      setSelectedBusinesses([]);
    } catch (err) {
      setError(`Failed to ${action} businesses`);
    }
  };

  const rescheduleFollowUp = async (businessId, newDate) => {
    try {
      const response = await fetch("/api/schedule-pending-follow-up", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessId,
          followUpDate: newDate,
        }),
      });

      if (!response.ok) throw new Error("Failed to reschedule follow-up");
      fetchFollowUps();
    } catch (err) {
      setError("Could not reschedule follow-up");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold">
            Follow-ups Dashboard
          </h1>
          <div className="flex space-x-4">
            <button
              onClick={() => handleBulkAction("approve")}
              disabled={!selectedBusinesses.length}
              className="bg-green-500 text-white px-4 py-2 rounded-lg disabled:opacity-50 hover:bg-green-600 transition-colors"
            >
              Approve Selected
            </button>
            <button
              onClick={() => handleBulkAction("reject")}
              disabled={!selectedBusinesses.length}
              className="bg-red-500 text-white px-4 py-2 rounded-lg disabled:opacity-50 hover:bg-red-600 transition-colors"
            >
              Reject Selected
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-[#475569] mb-2">
                Start Date
              </label>
              <input
                type="date"
                name="start_date"
                value={dateRange.start}
                onChange={(e) =>
                  setDateRange({ ...dateRange, start: e.target.value })
                }
                className="w-full p-2 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#475569] mb-2">
                End Date
              </label>
              <input
                type="date"
                name="end_date"
                value={dateRange.end}
                onChange={(e) =>
                  setDateRange({ ...dateRange, end: e.target.value })
                }
                className="w-full p-2 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#475569] mb-2">
                Business Type
              </label>
              <select
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="w-full p-2 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              >
                <option value="all">All Types</option>
                <option value="restaurant">Restaurant</option>
                <option value="hotel">Hotel</option>
                <option value="attraction">Attraction</option>
                <option value="shop">Shop</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedBusinesses(businesses.map((b) => b.id));
                        } else {
                          setSelectedBusinesses([]);
                        }
                      }}
                      className="rounded border-gray-300 focus:ring-[#3b82f6]"
                    />
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Business
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Follow-up Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {businesses.map((business) => (
                  <tr key={business.id}>
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={selectedBusinesses.includes(business.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedBusinesses([
                              ...selectedBusinesses,
                              business.id,
                            ]);
                          } else {
                            setSelectedBusinesses(
                              selectedBusinesses.filter(
                                (id) => id !== business.id
                              )
                            );
                          }
                        }}
                        className="rounded border-gray-300 focus:ring-[#3b82f6]"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-[#1e293b]">
                        {business.name}
                      </div>
                      <div className="text-sm text-[#475569]">
                        {business.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-[#475569]">
                      {business.type}
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="date"
                        name="follow_up_date"
                        value={business.followUpDate}
                        onChange={(e) =>
                          rescheduleFollowUp(business.id, e.target.value)
                        }
                        className="text-sm border rounded p-1 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${
                          business.emailStatus === "sent"
                            ? "bg-green-100 text-green-800"
                            : business.emailStatus === "failed"
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {business.emailStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-3">
                        <button
                          onClick={() =>
                            handleBulkAction("approve", [business.id])
                          }
                          className="text-green-500 hover:text-green-700 transition-colors"
                        >
                          <i className="fas fa-check"></i>
                        </button>
                        <button
                          onClick={() =>
                            handleBulkAction("reject", [business.id])
                          }
                          className="text-red-500 hover:text-red-700 transition-colors"
                        >
                          <i className="fas fa-times"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;