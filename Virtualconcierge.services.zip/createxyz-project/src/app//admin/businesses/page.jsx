"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedStatus, setSelectedStatus] = useState("pending");
  const [sortField, setSortField] = useState("created_at");
  const [sortOrder, setSortOrder] = useState("desc");
  const [selectedBusinesses, setSelectedBusinesses] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [filters, setFilters] = useState({
    businessType: "",
    country: "",
    dateRange: { start: "", end: "" },
    reviewStatus: "",
  });
  const [metrics, setMetrics] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    if (!userLoading && (!user || user.role !== "admin")) {
      window.location.href = "/";
    }
  }, [user, userLoading]);

  useEffect(() => {
    if (!userLoading && user?.role === "admin") {
      fetchMetrics();
    }
  }, [user, userLoading]);

  const fetchBusinesses = async (page, status) => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch("/api/list-businesses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          page,
          limit: 10,
          status,
          sortField,
          sortOrder,
          searchTerm: searchTerm.trim(),
          filters: {
            businessType: filters.businessType,
            country: filters.country,
            dateStart: filters.dateRange.start,
            dateEnd: filters.dateRange.end,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch businesses");
      }

      const data = await response.json();

      if (!Array.isArray(data.businesses)) {
        throw new Error("Invalid data format received");
      }

      setBusinesses(data.businesses);
      setTotalPages(Math.ceil(data.total / 10));
    } catch (err) {
      console.error("Fetch error:", err);
      setError(err.message || "Failed to load businesses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!userLoading && user?.role === "admin") {
      fetchBusinesses(currentPage, selectedStatus);
    }
  }, [
    currentPage,
    selectedStatus,
    sortField,
    sortOrder,
    searchTerm,
    filters,
    user,
    userLoading,
  ]);

  const handleSort = (field) => {
    setSortField(field);
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const handleBulkAction = async (action) => {
    if (selectedBusinesses.size === 0) return;

    setIsProcessing(true);
    try {
      const promises = Array.from(selectedBusinesses).map(async (id) => {
        const response = await fetch("/api/update-business-status", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, status: action }),
        });

        if (!response.ok) throw new Error("Failed to update status");

        await fetch("/api/admin-dashboard", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "systemStatus",
            logType: "audit",
            details: {
              action: "bulk_status_update",
              businessId: id,
              newStatus: action,
              adminId: user.id,
            },
          }),
        });
      });

      await Promise.all(promises);
      await fetchBusinesses(currentPage, selectedStatus);
      await fetchMetrics();
      setSelectedBusinesses(new Set());
    } catch (err) {
      setError("Failed to process bulk action");
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExport = async () => {
    try {
      const response = await fetch("/api/admin-dashboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "generateReport",
          reportType: "business",
          startDate: filters.dateRange.start || new Date(0).toISOString(),
          endDate: filters.dateRange.end || new Date().toISOString(),
        }),
      });

      if (!response.ok) throw new Error("Failed to generate report");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `business-report-${new Date().toISOString()}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError("Failed to export data");
      console.error(err);
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await fetch("/api/admin-dashboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "getMetrics" }),
      });

      if (!response.ok) throw new Error("Failed to fetch metrics");

      const data = await response.json();
      setMetrics(data.metrics);
    } catch (err) {
      console.error("Failed to fetch metrics:", err);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6] mb-4"></i>
          <p className="text-[#475569]">Loading businesses...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return null;
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <h1 className="text-2xl md:text-3xl font-crimson-text text-[#1e293b] font-bold">
              Business Review
            </h1>
            <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
              <input
                type="text"
                placeholder="Search businesses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent w-full md:w-64"
              />
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
              >
                <option value="pending">Pending Review</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          {metrics && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Total Businesses
                </h3>
                <p className="text-2xl text-[#3b82f6]">
                  {metrics.totalBusinesses}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Pending Review
                </h3>
                <p className="text-2xl text-[#f59e0b]">
                  {metrics.pendingReviews}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Approved Today
                </h3>
                <p className="text-2xl text-[#10b981]">
                  {metrics.approvedToday}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Rejection Rate
                </h3>
                <p className="text-2xl text-[#ef4444]">
                  {metrics.rejectionRate}%
                </p>
              </div>
            </div>
          )}

          <div className="flex flex-col md:flex-row justify-between items-center mb-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="mb-4 md:mb-0 px-4 py-2 bg-[#3b82f6] text-white rounded-lg hover:bg-[#2563eb]"
            >
              <i className="fas fa-filter mr-2"></i>
              {showFilters ? "Hide Filters" : "Show Filters"}
            </button>
            <button
              onClick={handleExport}
              className="px-4 py-2 bg-[#10b981] text-white rounded-lg hover:bg-[#059669]"
            >
              <i className="fas fa-download mr-2"></i>
              Export Data
            </button>
          </div>

          {showFilters && (
            <div className="bg-white p-4 rounded-lg shadow mb-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <select
                  value={filters.businessType}
                  onChange={(e) =>
                    setFilters({ ...filters, businessType: e.target.value })
                  }
                  className="border rounded-lg px-4 py-2"
                >
                  <option value="">All Business Types</option>
                  <option value="restaurant">Restaurant</option>
                  <option value="hotel">Hotel</option>
                  <option value="retail">Retail</option>
                </select>
                <select
                  value={filters.country}
                  onChange={(e) =>
                    setFilters({ ...filters, country: e.target.value })
                  }
                  className="border rounded-lg px-4 py-2"
                >
                  <option value="">All Countries</option>
                  <option value="US">United States</option>
                  <option value="UK">United Kingdom</option>
                  <option value="CA">Canada</option>
                </select>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={filters.dateRange.start}
                    onChange={(e) =>
                      setFilters({
                        ...filters,
                        dateRange: {
                          ...filters.dateRange,
                          start: e.target.value,
                        },
                      })
                    }
                    className="border rounded-lg px-4 py-2 w-1/2"
                  />
                  <input
                    type="date"
                    value={filters.dateRange.end}
                    onChange={(e) =>
                      setFilters({
                        ...filters,
                        dateRange: {
                          ...filters.dateRange,
                          end: e.target.value,
                        },
                      })
                    }
                    className="border rounded-lg px-4 py-2 w-1/2"
                  />
                </div>
              </div>
            </div>
          )}

          {selectedBusinesses.size > 0 && (
            <div className="mb-4 flex gap-2">
              <button
                onClick={() => handleBulkAction("approved")}
                disabled={isProcessing}
                className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50"
              >
                Approve Selected
              </button>
              <button
                onClick={() => handleBulkAction("rejected")}
                disabled={isProcessing}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 disabled:opacity-50"
              >
                Reject Selected
              </button>
            </div>
          )}

          {error && (
            <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      <input
                        type="checkbox"
                        checked={selectedBusinesses.size === businesses.length}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedBusinesses(
                              new Set(businesses.map((b) => b.id))
                            );
                          } else {
                            setSelectedBusinesses(new Set());
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => handleSort("name")}
                    >
                      Business{" "}
                      {sortField === "name" &&
                        (sortOrder === "asc" ? "↑" : "↓")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contact
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => handleSort("status")}
                    >
                      Status{" "}
                      {sortField === "status" &&
                        (sortOrder === "asc" ? "↑" : "↓")}
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => handleSort("created_at")}
                    >
                      Registered{" "}
                      {sortField === "created_at" &&
                        (sortOrder === "asc" ? "↑" : "↓")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {businesses.map((business) => (
                    <tr
                      key={business.id}
                      className={
                        selectedBusinesses.has(business.id) ? "bg-blue-50" : ""
                      }
                    >
                      <td className="px-6 py-4">
                        <input
                          type="checkbox"
                          checked={selectedBusinesses.has(business.id)}
                          onChange={(e) => {
                            const newSelected = new Set(selectedBusinesses);
                            if (e.target.checked) {
                              newSelected.add(business.id);
                            } else {
                              newSelected.delete(business.id);
                            }
                            setSelectedBusinesses(newSelected);
                          }}
                          className="rounded border-gray-300"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-[#1e293b]">
                          {business.name}
                        </div>
                        <div className="text-sm text-[#475569]">
                          {business.business_type}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-[#475569]">
                          {business.contact_email}
                        </div>
                        <div className="text-sm text-[#475569]">
                          {business.contact_phone}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-[#475569]">
                          {business.region_name}
                        </div>
                        <div className="text-sm text-[#475569]">
                          {business.country_name}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${
                            business.status === "approved"
                              ? "bg-green-100 text-green-800"
                              : business.status === "rejected"
                              ? "bg-red-100 text-red-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {business.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-[#475569]">
                        {new Date(business.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-3">
                          {business.status === "pending" && !isProcessing && (
                            <>
                              <button
                                onClick={async () => {
                                  setIsProcessing(true);
                                  try {
                                    const response = await fetch(
                                      "/api/update-business-status",
                                      {
                                        method: "POST",
                                        headers: {
                                          "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify({
                                          id: business.id,
                                          status: "approved",
                                        }),
                                      }
                                    );
                                    if (!response.ok)
                                      throw new Error(
                                        "Failed to update status"
                                      );
                                    await fetchBusinesses(
                                      currentPage,
                                      selectedStatus
                                    );
                                  } catch (err) {
                                    setError(
                                      "Failed to update business status"
                                    );
                                    console.error(err);
                                  } finally {
                                    setIsProcessing(false);
                                  }
                                }}
                                className="text-green-500 hover:text-green-700 transition-colors"
                              >
                                <i className="fas fa-check"></i>
                              </button>
                              <button
                                onClick={async () => {
                                  setIsProcessing(true);
                                  try {
                                    const response = await fetch(
                                      "/api/update-business-status",
                                      {
                                        method: "POST",
                                        headers: {
                                          "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify({
                                          id: business.id,
                                          status: "rejected",
                                        }),
                                      }
                                    );
                                    if (!response.ok)
                                      throw new Error(
                                        "Failed to update status"
                                      );
                                    await fetchBusinesses(
                                      currentPage,
                                      selectedStatus
                                    );
                                  } catch (err) {
                                    setError(
                                      "Failed to update business status"
                                    );
                                    console.error(err);
                                  } finally {
                                    setIsProcessing(false);
                                  }
                                }}
                                className="text-red-500 hover:text-red-700 transition-colors"
                              >
                                <i className="fas fa-times"></i>
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-[#475569] text-sm">
              Page {currentPage} of {totalPages} • Showing {businesses.length}{" "}
              businesses
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1 || isProcessing}
                className="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                Previous
              </button>
              <button
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages || isProcessing}
                className="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default MainComponent;