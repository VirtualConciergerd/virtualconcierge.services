"use client";
import React from "react";

function MainComponent() {
  const [countries, setCountries] = useState([]);
  const [editingCountry, setEditingCountry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showThemeEditor, setShowThemeEditor] = useState(false);
  const [editingTheme, setEditingTheme] = useState(null);
  const { data: user } = useUser();

  useEffect(() => {
    if (user && user.role !== "admin") {
      window.location.href = "/";
    }
  }, [user]);

  const fetchCountries = async () => {
    try {
      const response = await fetch("/api/admin/countries");
      if (!response.ok) throw new Error("Failed to fetch countries");
      const data = await response.json();
      setCountries(data);
    } catch (err) {
      setError("Failed to fetch countries");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (countryData) => {
    try {
      const response = await fetch("/api/admin/countries", {
        method: countryData.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(countryData),
      });

      if (!response.ok) throw new Error("Failed to save country");

      fetchCountries();
      setEditingCountry(null);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this country?")) return;

    try {
      const response = await fetch(`/api/admin/countries/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete country");

      fetchCountries();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleEditTheme = (country) => {
    setEditingTheme(country);
    setShowThemeEditor(true);
  };

  const handleSaveTheme = async (theme) => {
    try {
      const response = await fetch(
        `/api/admin/countries/${editingTheme.id}/theme`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ theme_settings: theme }),
        }
      );

      if (!response.ok) throw new Error("Failed to save theme");

      fetchCountries();
      setShowThemeEditor(false);
      setEditingTheme(null);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  if (loading)
    return (
      <div className="flex justify-center p-8">
        <i className="fas fa-spinner fa-spin text-3xl"></i>
      </div>
    );

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold">
            Country Management
          </h1>
          <button
            onClick={() => setEditingCountry({})}
            className="bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
          >
            Add New Country
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Code
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Currency
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Language
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {countries.map((country) => (
                <tr key={country.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {country.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {country.code}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {country.currency}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {country.language}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => setEditingCountry(country)}
                      className="text-[#3b82f6] hover:text-[#2563eb] mr-4 transition-colors"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button
                      onClick={() => handleEditTheme(country)}
                      className="text-[#3b82f6] hover:text-[#2563eb] mr-4 transition-colors"
                    >
                      <i className="fas fa-palette"></i>
                    </button>
                    <button
                      onClick={() => handleDelete(country.id)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {editingCountry && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-8 max-w-2xl w-full">
              <h2 className="text-2xl font-crimson-text font-bold mb-6">
                {editingCountry.id ? "Edit Country" : "Add New Country"}
              </h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSave(editingCountry);
                }}
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={editingCountry.name || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          name: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Code
                    </label>
                    <input
                      type="text"
                      name="code"
                      value={editingCountry.code || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          code: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                      required
                      maxLength="2"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Currency
                    </label>
                    <input
                      type="text"
                      name="currency"
                      value={editingCountry.currency || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          currency: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                      required
                      maxLength="3"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Language
                    </label>
                    <input
                      type="text"
                      name="language"
                      value={editingCountry.language || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          language: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                      required
                      maxLength="2"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Emergency Number
                    </label>
                    <input
                      type="text"
                      name="emergency_number"
                      value={editingCountry.emergency_number || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          emergency_number: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Tourist Hotline
                    </label>
                    <input
                      type="text"
                      name="tourist_hotline"
                      value={editingCountry.tourist_hotline || ""}
                      onChange={(e) =>
                        setEditingCountry({
                          ...editingCountry,
                          tourist_hotline: e.target.value,
                        })
                      }
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#3b82f6] focus:ring-[#3b82f6]"
                    />
                  </div>
                </div>
                <div className="mt-6 flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setEditingCountry(null)}
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-[#3b82f6] text-white px-4 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showThemeEditor && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-crimson-text font-bold">
                  Edit Theme: {editingTheme.name}
                </h2>
                <button
                  onClick={() => {
                    setShowThemeEditor(false);
                    setEditingTheme(null);
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <ThemeEditor
                countryId={editingTheme.id}
                initialTheme={editingTheme.theme_settings}
                onSave={handleSaveTheme}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;