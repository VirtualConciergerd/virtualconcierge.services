"use client";
import React from "react";

function MainComponent() {
  const [status, setStatus] = useState("loading");
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const paymentIntentId = params.get("payment_intent");

    if (!paymentIntentId) {
      setStatus("error");
      setError("No payment information found");
      return;
    }

    const verifyPayment = async () => {
      try {
        const response = await fetch("/api/process-payment-success", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ paymentIntentId }),
        });

        if (!response.ok) {
          throw new Error("Payment verification failed");
        }

        const data = await response.json();

        if (data.error) {
          throw new Error(data.error);
        }

        setOrder(data);
        setStatus("success");
      } catch (error) {
        console.error("Verification error:", error);
        setStatus("error");
        setError(error.message || "Payment verification failed");
      }
    };

    verifyPayment();
  }, [location]);

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-lg text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6] mb-4"></i>
          <p className="text-[#1e293b] font-crimson-text">
            Verifying your payment...
          </p>
        </div>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-lg text-center max-w-md mx-4">
          <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-times text-red-500 text-2xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-[#1e293b] mb-4 font-crimson-text">
            Payment Verification Failed
          </h1>
          <p className="text-[#475569] mb-6">
            {error || "An error occurred while verifying your payment"}
          </p>
          <button
            onClick={() => navigate("/")}
            className="bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors font-roboto"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center max-w-md mx-4">
        <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-check text-green-500 text-2xl"></i>
        </div>
        <h1 className="text-2xl font-bold text-[#1e293b] mb-4 font-crimson-text">
          Payment Successful!
        </h1>
        {order && (
          <div className="mb-6">
            <p className="text-[#475569] mb-2">Order ID: {order.orderId}</p>
            <p className="text-[#475569]">Thank you for your purchase!</p>
          </div>
        )}
        <div className="space-y-4">
          <button
            onClick={() => navigate("/")}
            className="bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors font-roboto w-full"
          >
            Return to Home
          </button>
          <button
            onClick={() => navigate("/account/orders")}
            className="border border-[#3b82f6] text-[#3b82f6] px-6 py-2 rounded-lg hover:bg-[#f8fafc] transition-colors font-roboto w-full"
          >
            View Orders
          </button>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;