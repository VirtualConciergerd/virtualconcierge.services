"use client";
import React from "react";

function MainComponent() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeSlides, setActiveSlides] = useState({});

  const fetchCategories = useCallback(async () => {
    try {
      const response = await fetch("/api/list-categories", {
        method: "POST",
        body: JSON.stringify({}),
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch categories: ${response.statusText}`);
      }
      const data = await response.json();
      setCategories(data.categories);
      const initialSlides = {};
      data.categories.forEach((cat) => {
        initialSlides[cat.id] = 0;
      });
      setActiveSlides(initialSlides);
    } catch (err) {
      console.error(err);
      setError("Could not load product categories");
    } finally {
      setLoading(false);
    }
  }, []);

  const nextSlide = (categoryId) => {
    setActiveSlides((prev) => ({
      ...prev,
      [categoryId]: (prev[categoryId] + 1) % 3,
    }));
  };

  const prevSlide = (categoryId) => {
    setActiveSlides((prev) => ({
      ...prev,
      [categoryId]: (prev[categoryId] - 1 + 3) % 3,
    }));
  };

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  return (
    <div className="min-h-screen bg-[#F4F3EE]">
      <nav className="fixed w-full bg-[#7E7F83] shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-crimson-text text-[#F3F3F4] font-bold">
            Virtual Concierge
          </div>
          <div className="flex gap-4 items-center">
            <a
              href="/"
              className="text-[#F3F3F4] hover:text-[#3b82f6] transition-colors"
            >
              Home
            </a>
            <a
              href="/about"
              className="text-[#F3F3F4] hover:text-[#3b82f6] transition-colors"
            >
              About
            </a>
            <a
              href="/contact"
              className="text-[#F3F3F4] hover:text-[#3b82f6] transition-colors"
            >
              Contact
            </a>
          </div>
        </div>
      </nav>

      <main className="pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#BCB8B1] rounded-lg p-8 mb-12">
            <h1 className="text-4xl md:text-6xl font-crimson-text text-[#F3F3F4] font-bold mb-6 text-center">
              Our Product Categories
            </h1>
            <p className="text-xl text-[#F3F3F4] mb-12 max-w-2xl mx-auto text-center">
              Explore our curated selection of Dominican experiences and
              products
            </p>
          </div>

          {error && (
            <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
              {error}
            </div>
          )}

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className="bg-white rounded-lg shadow-lg overflow-hidden hover:-translate-y-1 transition-all duration-300"
                >
                  <div className="relative pb-[60%]">
                    {category.images?.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`${category.name} category`}
                        className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-500 ${
                          activeSlides[category.id] === index
                            ? "opacity-100"
                            : "opacity-0"
                        }`}
                      />
                    ))}
                    <div className="absolute bottom-4 right-4 flex gap-2">
                      <button
                        onClick={() => prevSlide(category.id)}
                        className="bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
                      >
                        <i className="fas fa-chevron-left"></i>
                      </button>
                      <button
                        onClick={() => nextSlide(category.id)}
                        className="bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
                      >
                        <i className="fas fa-chevron-right"></i>
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-2">
                      {category.name}
                    </h2>
                    <p className="text-gray-600 mb-6 font-roboto">
                      {category.description}
                    </p>
                    <div className="flex justify-between items-center">
                      <a
                        href={`/products/category/${category.slug}`}
                        className="bg-[#FF6F00] text-white px-6 py-2 rounded-full hover:bg-[#FF8533] transition-colors font-roboto flex items-center"
                      >
                        Explore
                        <i className="fas fa-arrow-right ml-2"></i>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default MainComponent;