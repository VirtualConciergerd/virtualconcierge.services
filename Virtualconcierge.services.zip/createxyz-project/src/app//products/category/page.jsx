"use client";
import React from "react";

function MainComponent() {
  const { categorySlug } = useParams();
  const navigate = useNavigate();
  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCategoryProducts = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/get-products-by-category", {
          method: "POST",
          body: JSON.stringify({ categorySlug }),
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
          throw new Error(data.error);
        }

        setCategory(data.category);
        setProducts(data.products);
      } catch (err) {
        console.error(err);
        setError("Could not load products. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    if (categorySlug) {
      fetchCategoryProducts();
    }
  }, [categorySlug]);

  const handleBuyNow = useCallback(
    (product) => {
      navigate(
        `/payment?productId=${product.id}&name=${product.name}&price=${product.price}`
      );
    },
    [navigate]
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <div className="bg-red-100 text-red-700 p-4 rounded-lg">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <nav className="flex mb-8 text-[#475569] font-roboto">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6]"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <button
            onClick={() => navigate("/products")}
            className="hover:text-[#3b82f6]"
          >
            Products
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">{category?.category_name}</span>
        </nav>

        <div className="mb-12">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-4">
            {category?.category_name}
          </h1>
          <p className="text-[#475569] font-roboto max-w-3xl">
            {category?.category_description}
          </p>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-12 text-[#475569] font-roboto">
            No products found in this category.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                image={product.image_url}
                name={product.name}
                price={product.price}
                onBuyNow={() => handleBuyNow(product)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;