"use client";
import React from "react";

function MainComponent() {
  const [provinces, setProvinces] = useState(null);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [attractions, setAttractions] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [savedPlaces, setSavedPlaces] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const fetchProvinces = useCallback(async () => {
    try {
      const response = await fetch("/api/attractions-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "listProvinces" }),
      });
      if (!response.ok) throw new Error("Failed to fetch provinces");
      const data = await response.json();
      setProvinces(data);
    } catch (err) {
      console.error(err);
      setError("Could not load provinces");
    }
  }, []);
  const fetchAttractions = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/attractions-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: selectedProvince
            ? "getProvinceAttractions"
            : "searchAttractions",
          data: selectedProvince
            ? { provinceId: selectedProvince }
            : { query: searchQuery },
        }),
      });
      if (!response.ok) throw new Error("Failed to fetch attractions");
      const data = await response.json();
      setAttractions(data);
    } catch (err) {
      console.error(err);
      setError("Could not load attractions");
    } finally {
      setLoading(false);
    }
  }, [selectedProvince, searchQuery]);
  const handleSavePlace = useCallback(async (attraction) => {
    try {
      await fetch("/api/places-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "save",
          data: {
            userId: "123",
            placeId: attraction.id,
            placeType: "attraction",
            name: attraction.name,
            address: attraction.province_name,
          },
        }),
      });
      setSavedPlaces((prev) => [...prev, attraction.id]);
    } catch (err) {
      console.error(err);
      setError("Could not save place");
    }
  }, []);

  useEffect(() => {
    fetchProvinces();
  }, [fetchProvinces]);

  useEffect(() => {
    if (selectedProvince || searchQuery) {
      fetchAttractions();
    }
  }, [selectedProvince, searchQuery, fetchAttractions]);

  useEffect(() => {
    const detectCountry = async () => {
      try {
        const response = await fetch("/api/detect-country", {
          method: "POST",
        });
        if (!response.ok) throw new Error("Failed to detect country");
        const country = await response.json();

        if (country?.theme_settings) {
          const theme = country.theme_settings;
          document.documentElement.style.setProperty("--primary", "#0077B6");
          document.documentElement.style.setProperty("--secondary", "#FF5E62");
          document.documentElement.style.setProperty("--accent", "#FF5E62");
        }
      } catch (err) {
        console.error("Country detection failed:", err);
      }
    };

    detectCountry();
  }, []);

  const provincesOptions = provinces === null ? [] : provinces;

  return (
    <div className="min-h-screen bg-[#A99985]">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center mb-8">
          <img
            src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
            alt="Virtual Concierge Logo"
            className="h-16 w-auto mix-blend-multiply"
          />
        </div>
        <h1 className="text-4xl font-playfair text-white font-bold mb-8 text-center">
          Dominican Republic Attractions Guide
        </h1>
        <div className="bg-white/90 rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              className="flex-1 p-3 border rounded font-lato focus:ring-2 focus:ring-[#8B7355] focus:border-transparent"
            >
              <option value="">All Provinces</option>
              {provincesOptions.map((province) => (
                <option key={province.id} value={province.id}>
                  {province.name}
                </option>
              ))}
            </select>

            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search attractions..."
                className="w-full p-3 border rounded font-lato pr-10 focus:ring-2 focus:ring-[#8B7355] focus:border-transparent"
              />
              <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-[#8B7355]"></i>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded mb-6 font-lato">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <i className="fas fa-spinner fa-spin text-4xl text-white"></i>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {attractions.map((attraction) => (
              <div
                key={attraction.id}
                className="bg-white rounded-lg shadow-lg overflow-hidden hover:-translate-y-1 transition-all duration-300"
              >
                <img
                  src={attraction.image || "https://via.placeholder.com/300"}
                  alt={`View of ${attraction.name}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-sm text-[#8B7355] font-lato mb-2">
                    {attraction.province_name}
                  </div>
                  <h3 className="text-xl font-playfair text-[#8B7355] font-bold mb-2">
                    {attraction.name}
                  </h3>
                  <p className="text-[#666666] mb-4 font-lato">
                    {attraction.description}
                  </p>
                  <button
                    onClick={() => handleSavePlace(attraction)}
                    disabled={savedPlaces.includes(attraction.id)}
                    className="flex items-center justify-center w-full bg-[#8B7355] text-white px-4 py-2 rounded hover:bg-[#A99985] transition-colors disabled:bg-gray-300 font-lato"
                  >
                    <i
                      className={`fas fa-bookmark mr-2 ${
                        savedPlaces.includes(attraction.id) ? "text-white" : ""
                      }`}
                    ></i>
                    {savedPlaces.includes(attraction.id)
                      ? "Saved"
                      : "Save Place"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && attractions.length === 0 && (
          <div className="text-center text-white font-lato mt-8">
            No attractions found. Try adjusting your search or selecting a
            different province.
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;