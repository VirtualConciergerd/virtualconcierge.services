"use client";
import React from "react";

function MainComponent() {
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <></>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Shipping Policy</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Shipping Policy
          </h1>
          <p className="text-[#475569] mb-4">
            Last Updated: {new Date().toLocaleDateString()}
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                1. Shipping Methods
              </h2>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Standard Shipping
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>5-7 business days</li>
                  <li>Free for orders over $50</li>
                  <li>$4.99 for orders under $50</li>
                </ul>

                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Express Shipping
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>2-3 business days</li>
                  <li>$9.99 flat rate</li>
                  <li>Free for Premium members</li>
                </ul>

                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Next Day Delivery
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Next business day</li>
                  <li>$19.99 flat rate</li>
                  <li>Order by 2 PM for next-day delivery</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                2. Processing Time
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Orders processed within 24 hours</li>
                <li>Weekend orders processed next business day</li>
                <li>Holiday processing times may vary</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                3. Shipping Restrictions
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Some items restricted to certain regions</li>
                <li>International shipping available to select countries</li>
                <li>Additional fees may apply for remote areas</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                4. Order Tracking
              </h2>
              <p className="text-[#475569] mb-4">Track your order:</p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Tracking number provided via email</li>
                <li>Real-time updates in your account dashboard</li>
                <li>SMS notifications available</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                5. International Shipping
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Available to select countries</li>
                <li>Customs fees responsibility of recipient</li>
                <li>Delivery times vary by destination</li>
                <li>International tracking provided</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;