"use client";
import React from "react";

function MainComponent() {
  const [location, setLocation] = useState("San Francisco, USA");
  const [placeType, setPlaceType] = useState("attractions");
  const [places, setPlaces] = useState([]);
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [savedPlaces, setSavedPlaces] = useState([]);
  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "recommendations",
          data: { location, type: placeType },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await response.json();
      setPlaces(data.places || []);
      setWeather(data.weather);
    } catch (err) {
      setError("Unable to load places and weather");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [location, placeType]);
  const handleSavePlace = useCallback(
    async (place) => {
      try {
        await fetch("/api/places-management", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "save",
            data: {
              name: place.name,
              placeId: place.business_id,
              placeType,
              address: place.full_address,
            },
          }),
        });
        setSavedPlaces((prev) => [...prev, place.business_id]);
      } catch (err) {
        console.error(err);
      }
    },
    [placeType]
  );

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0077B6] to-[#FF5E62] relative overflow-hidden">
      <div className="absolute inset-0">
        <svg
          className="absolute bottom-0 left-0 right-0"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1440 320"
        >
          <path
            fill="rgba(255,255,255,0.1)"
            fillOpacity="1"
            d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,229.3C672,224,768,192,864,181.3C960,171,1056,181,1152,181.3C1248,181,1344,171,1392,165.3L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="bg-white/80 backdrop-blur-md rounded-lg shadow-lg p-6 mb-6">
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Enter location"
                  className="flex-1 p-2 border border-[#0077B6] rounded focus:outline-none focus:ring-2 focus:ring-[#0077B6]"
                />
                <select
                  value={placeType}
                  onChange={(e) => setPlaceType(e.target.value)}
                  className="p-2 border border-[#0077B6] rounded focus:outline-none focus:ring-2 focus:ring-[#0077B6]"
                >
                  <option value="attractions">Attractions</option>
                  <option value="restaurants">Restaurants</option>
                  <option value="hotels">Hotels</option>
                </select>
                <button
                  onClick={fetchData}
                  className="bg-[#0077B6] text-white px-4 py-2 rounded hover:bg-[#FF5E62] transition-colors duration-300"
                  disabled={loading}
                >
                  {loading ? "Loading..." : "Search"}
                </button>
              </div>
              <div className="h-[400px] bg-gray-200/50 backdrop-blur-md rounded mb-6">
                <div className="text-center py-20">
                  Map will be displayed here
                </div>
              </div>

              {error && <div className="text-red-500 mb-4">{error}</div>}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {places.map((place) => (
                  <div
                    key={place.business_id}
                    className="bg-white/80 backdrop-blur-md border-0 rounded-lg p-4 shadow-lg hover:shadow-xl transition-shadow duration-300"
                  >
                    {place.photos_sample?.[0]?.photo_url && (
                      <img
                        src={place.photos_sample[0].photo_url}
                        alt={place.name}
                        className="w-full h-48 object-cover rounded-lg mb-4"
                      />
                    )}
                    <h3 className="font-bold text-lg mb-2 text-[#0077B6]">
                      {place.name}
                    </h3>
                    <p className="text-gray-700 text-sm mb-2">
                      {place.full_address}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-[#FF5E62] mr-1">
                          <i className="fas fa-star"></i>
                        </span>
                        <span>{place.rating}</span>
                      </div>
                      <button
                        onClick={() => handleSavePlace(place)}
                        disabled={savedPlaces.includes(place.business_id)}
                        className="text-[#0077B6] hover:text-[#FF5E62] transition-colors duration-300"
                      >
                        <i
                          className={`fas fa-bookmark ${
                            savedPlaces.includes(place.business_id)
                              ? "text-[#FF5E62]"
                              : ""
                          }`}
                        ></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {weather && (
              <div className="bg-white/80 backdrop-blur-md rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                <h2 className="text-xl font-bold mb-4 text-[#0077B6]">
                  Weather
                </h2>
                <div className="flex items-center justify-between">
                  <div>
                    <img
                      src={weather.current.condition.icon}
                      alt={weather.current.condition.text}
                      className="w-16 h-16"
                    />
                    <p className="text-gray-700">
                      {weather.current.condition.text}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-[#0077B6]">
                      {weather.current.temp_c}°C
                    </p>
                    <p className="text-gray-700">
                      Feels like {weather.current.feelslike_c}°C
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white/80 backdrop-blur-md rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
              <h2 className="text-xl font-bold mb-4 text-[#0077B6]">
                Transportation
              </h2>
              <div className="space-y-3">
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-subway w-8 text-[#FF5E62]"></i>
                  <span>Metro/Subway</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-bus w-8 text-[#FF5E62]"></i>
                  <span>Bus</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-taxi w-8 text-[#FF5E62]"></i>
                  <span>Taxi</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <i className="fas fa-bicycle w-8 text-[#FF5E62]"></i>
                  <span>Bike Rental</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;