"use client";
import React from "react";

function MainComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [mapLocation, setMapLocation] = useState(null);
  const [country, setCountry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const detectCountry = async () => {
      try {
        const response = await fetch("/api/detect-country", {
          method: "POST",
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setCountry(data);
      } catch (err) {
        console.error(err);
        setError("Could not detect country. Using default settings.");
      } finally {
        setLoading(false);
      }
    };

    detectCountry();
  }, []);

  const categories = [
    {
      id: "emergency",
      name: "Emergency Numbers",
      icon: "phone-alt",
      entries: [
        {
          name: "National Emergency System",
          phone: "911",
          description:
            "For all emergencies including medical, police, and fire",
          emergency: true,
          priority: 1,
        },
        {
          name: "Tourist Assistance Hotline",
          phone: "1-809-200-3500",
          description: "24/7 tourist support in multiple languages",
          emergency: true,
          priority: 2,
        },
        {
          name: "Fire Department",
          phone: "809-682-2000",
          description: "Fire emergencies and rescue services",
          emergency: true,
          priority: 3,
        },
      ],
    },
    {
      id: "hospitals",
      name: "Emergency Hospitals",
      icon: "hospital",
      entries: [
        {
          name: "Hospital General de la Plaza de la Salud",
          address: "Av. Ortega y Gasset, Santo Domingo",
          phone: "+1 809-565-7477",
          hours: "24/7 Emergency Room",
          emergency: true,
          description: "Major trauma center with helicopter pad",
          location: { lat: 18.4861, lng: -69.9312 },
        },
        {
          name: "Centro Médico Punta Cana",
          address: "Av. Barceló, Punta Cana",
          phone: "+1 809-552-1506",
          hours: "24/7 Emergency Room",
          emergency: true,
          description: "International patient services available",
          location: { lat: 18.5818, lng: -68.4048 },
        },
        {
          name: "Hospital Metropolitano de Santiago (HOMS)",
          address: "Autopista Duarte Km 2.8, Santiago",
          phone: "+1 809-724-2222",
          hours: "24/7 Emergency Room",
          emergency: true,
          description: "Level I Trauma Center",
          location: { lat: 19.4517, lng: -70.6986 },
        },
      ],
    },
    {
      id: "police",
      name: "Police Emergency",
      icon: "shield-alt",
      entries: [
        {
          name: "National Police Emergency",
          phone: "911",
          description: "For immediate police assistance",
          emergency: true,
          priority: 1,
        },
        {
          name: "Tourist Police (POLITUR)",
          address: "Calle El Conde, Zona Colonial, Santo Domingo",
          phone: "+1 809-686-3424",
          hours: "24/7",
          description: "Specialized unit for tourist protection and assistance",
          emergency: true,
          location: { lat: 18.4718, lng: -69.8923 },
        },
        {
          name: "Anti-Kidnapping Unit",
          phone: "809-688-3510",
          description: "Immediate response for serious crimes",
          emergency: true,
        },
      ],
    },
    {
      id: "pharmacies",
      name: "24/7 Emergency Pharmacies",
      icon: "prescription-bottle-alt",
      entries: [
        {
          name: "Farmacia Carol 24/7",
          address: "Av. 27 de Febrero, Santo Domingo",
          phone: "+1 809-685-1166",
          hours: "24/7",
          description: "Full-service emergency pharmacy",
          location: { lat: 18.4615, lng: -69.9118 },
        },
        {
          name: "Farmacia Extra 24/7",
          address: "Av. Abraham Lincoln, Santo Domingo",
          phone: "+1 809-562-3333",
          hours: "24/7",
          description: "Emergency prescriptions available",
          location: { lat: 18.4766, lng: -69.9245 },
        },
      ],
    },
    {
      id: "embassies",
      name: "Emergency Embassy Contacts",
      icon: "flag",
      entries: [
        {
          name: "U.S. Embassy Emergency Line",
          address: "Av. República de Colombia, Santo Domingo",
          phone: "+1 809-567-7775",
          afterHours: "+1 809-567-7775 (press 1)",
          description: "24/7 emergency services for U.S. citizens",
          website: "do.usembassy.gov",
          location: { lat: 18.4783, lng: -69.9351 },
        },
        {
          name: "Canadian Embassy Emergency",
          address: "Av. Winston Churchill, Santo Domingo",
          phone: "+1 809-262-3100",
          afterHours: "+1 613-996-8885",
          description: "Emergency assistance for Canadian citizens",
          website: "canada.ca/dominican-republic",
          location: { lat: 18.4677, lng: -69.9327 },
        },
      ],
    },
    {
      id: "medical",
      name: "Medical Emergency Services",
      icon: "ambulance",
      entries: [
        {
          name: "Air Ambulance Service",
          phone: "829-200-0911",
          description: "Emergency medical evacuation",
          emergency: true,
        },
        {
          name: "Red Cross Ambulance",
          phone: "809-334-4545",
          description: "24/7 ambulance service",
          emergency: true,
        },
        {
          name: "Poison Control Center",
          phone: "809-681-7828",
          description: "Emergency toxicology assistance",
          emergency: true,
        },
      ],
    },
  ];

  const filteredCategories = categories.filter(
    (category) => selectedCategory === "all" || category.id === selectedCategory
  );

  const filteredEntries = filteredCategories.flatMap((category) =>
    category.entries.filter(
      (entry) =>
        entry.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.address &&
          entry.address.toLowerCase().includes(searchTerm.toLowerCase()))
    )
  );

  const handleLocationClick = (location) => {
    setMapLocation(location);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  const primaryColor = country?.cultural_colors?.primary || "#FF4B3E";
  const secondaryColor = country?.cultural_colors?.secondary || "#ff635c";
  const emergencyNumber = country?.emergency_number || "911";
  const touristHotline = country?.tourist_hotline || "1-809-200-3500";

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center justify-between text-[#475569]">
          <div className="flex items-center">
            <a
              href="/"
              className={`hover:text-[${primaryColor}] transition-colors flex items-center`}
            >
              <img
                src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
                alt="Emergency Services Logo"
                className="h-12 w-auto mr-4"
              />
              <span>Home</span>
            </a>
            <span className="mx-2">/</span>
            <span className="text-[#1e293b]">
              {emergencyNumber} Emergency Information
            </span>
          </div>
        </nav>
        <div
          className={`bg-[rgba(255,255,255,0.9)] border-l-4 border-[${primaryColor}] p-6 mb-8 rounded-r-lg transition-all duration-300`}
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <i
                className={`fas fa-exclamation-triangle text-[${primaryColor}] text-3xl`}
              ></i>
            </div>
            <div className="ml-4">
              <h1 className={`text-2xl font-bold text-[${primaryColor}] mb-2`}>
                Emergency? Dial {emergencyNumber} Immediately
              </h1>
              <p className={`text-[${secondaryColor}]`}>
                For any life-threatening emergency, medical crisis, fire, or
                crime in progress
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-1">
            <div className="bg-[rgba(255,255,255,0.9)] rounded-lg shadow-lg p-6 mb-6 transition-all duration-300 hover:transform hover:translate-y-[-3px] hover:shadow-[0_8px_16px_rgba(255,75,62,0.2)]">
              <div className="mb-6">
                <label
                  className="block text-[#1e293b] font-bold mb-2"
                  htmlFor="search"
                >
                  Quick Search
                </label>
                <input
                  type="text"
                  id="search"
                  name="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search emergency services..."
                  className="w-full p-3 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                />
              </div>

              <div className="mb-6">
                <label className="block text-[#1e293b] font-bold mb-2">
                  Emergency Category
                </label>
                <select
                  name="category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-3 border rounded focus:ring-2 focus:ring-[#FF4B3E] focus:border-transparent"
                >
                  <option value="all">All Emergency Services</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="bg-[rgba(255,255,255,0.9)] rounded-lg shadow-lg p-6 transition-all duration-300 hover:transform hover:translate-y-[-3px] hover:shadow-[0_8px_16px_rgba(255,75,62,0.2)]">
              <h2 className="text-xl font-bold text-[#1e293b] mb-4 flex items-center">
                <i className="fas fa-phone-alt text-[#FF4B3E] mr-2"></i>
                Critical Numbers
              </h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#FF4B3E] to-[#ff635c] rounded-lg text-white">
                  <span className="font-bold">Emergency</span>
                  <a
                    href="tel:911"
                    className="text-white hover:text-[#1e293b] text-xl font-bold transition-colors"
                  >
                    911
                  </a>
                </div>
                <div className="flex items-center justify-between p-4 bg-[rgba(255,255,255,0.9)] rounded-lg border border-[#FF4B3E]">
                  <span className="font-bold text-[#1e293b]">
                    Tourist Police
                  </span>
                  <a
                    href="tel:1-809-200-3500"
                    className="text-[#FF4B3E] hover:text-[#ff635c]"
                  >
                    1-809-200-3500
                  </a>
                </div>
                <div className="flex items-center justify-between p-4 bg-[rgba(255,255,255,0.9)] rounded-lg border border-[#FF4B3E]">
                  <span className="font-bold text-[#1e293b]">Ambulance</span>
                  <a
                    href="tel:829-200-0911"
                    className="text-[#FF4B3E] hover:text-[#ff635c]"
                  >
                    829-200-0911
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            {filteredCategories.map((category) => (
              <div
                key={category.id}
                className="bg-[rgba(255,255,255,0.9)] rounded-lg shadow-lg p-6 mb-6 transition-all duration-300 hover:transform hover:translate-y-[-3px] hover:shadow-[0_8px_16px_rgba(255,75,62,0.2)]"
              >
                <h2 className="text-2xl font-bold text-[#1e293b] mb-6 flex items-center">
                  <i
                    className={`fas fa-${category.icon} text-red-500 mr-3`}
                  ></i>
                  {category.name}
                </h2>
                <div className="space-y-6">
                  {category.entries
                    .sort((a, b) => (a.priority || 999) - (b.priority || 999))
                    .filter(
                      (entry) =>
                        entry.name
                          .toLowerCase()
                          .includes(searchTerm.toLowerCase()) ||
                        (entry.address &&
                          entry.address
                            .toLowerCase()
                            .includes(searchTerm.toLowerCase()))
                    )
                    .map((entry, index) => (
                      <div
                        key={index}
                        className={`border-b last:border-b-0 pb-6 last:pb-0 ${
                          entry.emergency
                            ? "bg-red-50 p-4 rounded-lg border border-red-100"
                            : ""
                        }`}
                      >
                        <h3 className="font-bold text-[#1e293b] mb-2 text-lg">
                          {entry.name}
                        </h3>
                        {entry.address && (
                          <p className="text-[#475569] mb-2 flex items-start">
                            <i className="fas fa-map-marker-alt text-red-500 mt-1 mr-2"></i>
                            {entry.address}
                            {entry.location && (
                              <button
                                onClick={() =>
                                  handleLocationClick(entry.location)
                                }
                                className="ml-2 text-blue-500 hover:text-blue-700"
                              >
                                <i className="fas fa-map"></i>
                              </button>
                            )}
                          </p>
                        )}
                        {entry.phone && (
                          <p className="text-[#475569] mb-2">
                            <a
                              href={`tel:${entry.phone}`}
                              className="flex items-center hover:text-red-500"
                            >
                              <i className="fas fa-phone text-red-500 mr-2"></i>
                              {entry.phone}
                            </a>
                          </p>
                        )}
                        {entry.afterHours && (
                          <p className="text-[#475569] mb-2">
                            <a
                              href={`tel:${entry.afterHours}`}
                              className="flex items-center hover:text-red-500"
                            >
                              <i className="fas fa-moon text-red-500 mr-2"></i>
                              After Hours: {entry.afterHours}
                            </a>
                          </p>
                        )}
                        {entry.hours && (
                          <p className="text-[#475569] mb-2 flex items-center">
                            <i className="fas fa-clock text-red-500 mr-2"></i>
                            {entry.hours}
                          </p>
                        )}
                        {entry.description && (
                          <p className="text-[#475569] mb-2 flex items-start">
                            <i className="fas fa-info-circle text-red-500 mt-1 mr-2"></i>
                            {entry.description}
                          </p>
                        )}
                        {entry.website && (
                          <p className="text-[#475569] mb-2">
                            <a
                              href={`https://${entry.website}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center hover:text-blue-500"
                            >
                              <i className="fas fa-globe text-blue-500 mr-2"></i>
                              {entry.website}
                            </a>
                          </p>
                        )}
                        {entry.emergency && (
                          <span className="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded mt-2">
                            24/7 Emergency Service
                          </span>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {mapLocation && (
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-[#1e293b]">
                Location Map
              </h2>
              <button
                onClick={() => setMapLocation(null)}
                className="text-[#475569] hover:text-red-500"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="h-96 rounded-lg overflow-hidden">
              <div
                id="map"
                className="w-full h-full bg-gray-100 flex items-center justify-center"
              >
                <p className="text-[#475569]">Map loading...</p>
              </div>
            </div>
          </div>
        )}

        <div
          className={`bg-gradient-to-r from-[${primaryColor}] to-[${secondaryColor}] text-white rounded-lg shadow-lg p-8 text-center`}
        >
          <h2 className="text-3xl font-bold mb-6">
            Need Non-Emergency Assistance?
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Our virtual concierge is available 24/7 to help you with any
            situation
          </p>
          <a
            href="/"
            className={`bg-white text-[${primaryColor}] px-8 py-3 rounded-full text-lg hover:bg-[rgba(255,255,255,0.9)] transition-colors inline-block`}
          >
            Chat with Concierge
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;