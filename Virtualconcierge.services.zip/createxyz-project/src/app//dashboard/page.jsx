"use client";
import React from "react";

function MainComponent() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isEditing, setIsEditing] = useState(false);
  const [currentService, setCurrentService] = useState(null);
  const { data: user } = useUser();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    location: "",
    price_range: "mid-range",
    booking_link: "",
    image_url: "",
  });

  useEffect(() => {
    if (!user) {
      window.location.href = "/account/signin?callbackUrl=/dashboard";
      return;
    }
    fetchServices();
  }, [user, currentPage]);

  const fetchServices = async () => {
    try {
      const response = await fetch("/api/list-concierge-services", {
        method: "POST",
        body: JSON.stringify({
          limit: 10,
          offset: (currentPage - 1) * 10,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch services");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setServices(data.services || []);
      setTotalPages(data.pages || 1);
    } catch (err) {
      console.error("Error:", err);
      setError("Could not load your services");
    } finally {
      setLoading(false);
    }
  };

  const handleEditService = (service) => {
    setCurrentService(service);
    setFormData({
      name: service.name,
      description: service.description,
      location: service.location,
      price_range: service.price_range,
      booking_link: service.booking_link,
      image_url: service.image_url,
    });
    setIsEditing(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      const endpoint = isEditing
        ? "/api/update-concierge-service"
        : "/api/create-concierge-service";

      const requestBody = {
        ...formData,
        ...(isEditing && { id: currentService.id }),
      };

      const response = await fetch(endpoint, {
        method: "POST",
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error("Failed to save service");
      }

      setIsEditing(false);
      setCurrentService(null);
      setFormData({
        name: "",
        description: "",
        location: "",
        price_range: "mid-range",
        booking_link: "",
        image_url: "",
      });

      fetchServices();
    } catch (err) {
      console.error("Error:", err);
      setError("Failed to save service");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-4xl text-[#3b82f6]"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8 flex justify-between items-center">
          <h1 className="text-3xl font-crimson-text font-bold text-[#1e293b]">
            My Services
          </h1>
          <button
            onClick={() => setIsEditing(false)}
            className="bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
          >
            Add New Service
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Form Section */}
          {(isEditing || currentService === null) && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4">
                {isEditing ? "Edit Service" : "Create New Service"}
              </h2>
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <input
                    type="text"
                    name="name"
                    placeholder="Service Name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                    required
                  />

                  <textarea
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                    rows="4"
                    required
                  />

                  <input
                    type="text"
                    name="location"
                    placeholder="Location"
                    value={formData.location}
                    onChange={(e) =>
                      setFormData({ ...formData, location: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />

                  <select
                    name="price_range"
                    value={formData.price_range}
                    onChange={(e) =>
                      setFormData({ ...formData, price_range: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  >
                    <option value="budget">Budget</option>
                    <option value="mid-range">Mid Range</option>
                    <option value="luxury">Luxury</option>
                  </select>

                  <input
                    type="url"
                    name="booking_link"
                    placeholder="Booking Link"
                    value={formData.booking_link}
                    onChange={(e) =>
                      setFormData({ ...formData, booking_link: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />

                  <input
                    type="url"
                    name="image_url"
                    placeholder="Image URL"
                    value={formData.image_url}
                    onChange={(e) =>
                      setFormData({ ...formData, image_url: e.target.value })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />

                  <button
                    type="submit"
                    className="w-full bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors"
                  >
                    {isEditing ? "Update Service" : "Create Service"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Services List */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Your Services</h2>
            {services.length === 0 ? (
              <p className="text-gray-500">
                No services found. Create one to get started!
              </p>
            ) : (
              <div className="space-y-4">
                {services.map((service) => (
                  <div key={service.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{service.name}</h3>
                        <p className="text-sm text-gray-600">
                          {service.location}
                        </p>
                        <span
                          className={`inline-block px-2 py-1 text-xs rounded-full mt-2 ${
                            service.price_range === "luxury"
                              ? "bg-purple-100 text-purple-800"
                              : service.price_range === "mid-range"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-green-100 text-green-800"
                          }`}
                        >
                          {service.price_range}
                        </span>
                      </div>
                      <button
                        onClick={() => handleEditService(service)}
                        className="text-[#3b82f6] hover:text-[#2563eb]"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {totalPages > 1 && (
              <div className="mt-6 flex justify-between items-center">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-4 py-2 border rounded-lg disabled:opacity-50"
                >
                  Previous
                </button>
                <span className="text-sm text-gray-600">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  onClick={() =>
                    setCurrentPage((p) => Math.min(totalPages, p + 1))
                  }
                  disabled={currentPage === totalPages}
                  className="px-4 py-2 border rounded-lg disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;