"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const { data: user, loading: authLoading } = useUser();
  const [userCountry, setUserCountry] = useState(null);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [orderStatus, setOrderStatus] = useState(null);
  const [processingOrder, setProcessingOrder] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [shippingAddress, setShippingAddress] = useState({
    street: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
  });
  const [orderSummary, setOrderSummary] = useState({
    subtotal: 99.99,
    tax: 8.25,
    shipping: 9.99,
    total: 118.23,
  });

  const validateAddress = (address) => {
    const errors = {};
    if (!address.street.trim()) errors.street = "Street address is required";
    if (!address.city.trim()) errors.city = "City is required";
    if (!address.state.trim()) errors.state = "State is required";
    if (!address.zipCode.trim()) errors.zipCode = "ZIP code is required";
    if (!address.country.trim()) errors.country = "Country is required";
    return errors;
  };

  const fetchUserLocation = useCallback(async () => {
    try {
      const response = await fetch("/api/get-user-location", {
        method: "POST",
      });
      if (!response.ok) throw new Error("Failed to detect location");
      const data = await response.json();
      setUserCountry(data.countryCode);
      setShippingAddress((prev) => ({ ...prev, country: data.countryName }));
      return data.countryCode;
    } catch (err) {
      console.error(err);
      setError("Could not detect your location");
      return "DEFAULT";
    }
  }, []);

  const fetchPaymentMethods = useCallback(async (countryCode) => {
    try {
      const response = await fetch("/api/get-payment-methods", {
        method: "POST",
        body: JSON.stringify({ countryCode }),
      });
      if (!response.ok) throw new Error("Failed to fetch payment methods");
      const data = await response.json();
      setPaymentMethods(data.paymentMethods || []);
    } catch (err) {
      console.error(err);
      setError("Could not load payment methods");
    }
  }, []);

  const handleOrderConfirmation = async (sessionId) => {
    try {
      setProcessingOrder(true);
      const response = await fetch("/api/handle-order-confirmation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });

      if (!response.ok) throw new Error("Failed to confirm order");

      const { orderId } = await response.json();
      await checkOrderStatus(orderId);
    } catch (err) {
      console.error(err);
      setError("Failed to confirm order");
    } finally {
      setProcessingOrder(false);
    }
  };
  const checkOrderStatus = async (orderId) => {
    try {
      const response = await fetch("/api/get-order-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });

      if (!response.ok) throw new Error("Failed to check order status");

      const status = await response.json();
      setOrderStatus(status);
    } catch (err) {
      console.error(err);
      setError("Failed to check order status");
    }
  };

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/account/signin?callbackUrl=/checkout");
      return;
    }
    const initCheckout = async () => {
      setLoading(true);
      const countryCode = await fetchUserLocation();
      await fetchPaymentMethods(countryCode);
      setLoading(false);
    };
    if (user) {
      initCheckout();
    }
  }, [fetchUserLocation, fetchPaymentMethods, user, authLoading]);

  useEffect(() => {
    const query = new URLSearchParams(window.location.search);
    const sessionId = query.get("session_id");

    if (sessionId) {
      handleOrderConfirmation(sessionId);
    }
  }, []);

  const handleMethodSelect = (method) => {
    setSelectedMethod(method);
    setError(null);
    setFormErrors({});
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setShippingAddress((prev) => ({
      ...prev,
      [name]: value,
    }));
    setFormErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const addressErrors = validateAddress(shippingAddress);
    if (Object.keys(addressErrors).length > 0) {
      setFormErrors(addressErrors);
      return;
    }

    if (!selectedMethod) {
      setError("Please select a payment method");
      return;
    }

    try {
      setProcessingOrder(true);
      setError(null);

      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: user.email,
          items: [
            {
              id: selectedMethod.id,
              name: selectedMethod.name,
              price: parseFloat(selectedMethod.localPrice),
              quantity: 1,
              image_url: selectedMethod.iconUrl,
            },
          ],
          shippingAddress: Object.values(shippingAddress).join(", "),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create checkout session");
      }

      const { sessionId } = await response.json();
      const stripe = await loadStripe(
        process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
      );

      const { error: stripeError } = await stripe.redirectToCheckout({
        sessionId,
      });

      if (stripeError) {
        throw stripeError;
      }
    } catch (err) {
      console.error(err);
      setError(err.message || "Could not process your payment");
    } finally {
      setProcessingOrder(false);
    }
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-white pt-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#DAA520]"></i>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white pt-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-[#DAA520]"></i>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-24 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-8">
          Checkout
        </h1>

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="bg-white p-6 rounded-lg border-2 border-[#DAA520]">
                <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                  Shipping Address
                </h2>
                <div className="space-y-4">
                  <div>
                    <input
                      type="text"
                      name="street"
                      placeholder="Street Address"
                      value={shippingAddress.street}
                      onChange={handleAddressChange}
                      className={`w-full p-2 border rounded-lg ${
                        formErrors.street
                          ? "border-red-500"
                          : "border-[#DAA520]"
                      }`}
                    />
                    {formErrors.street && (
                      <p className="text-red-500 text-sm mt-1">
                        {formErrors.street}
                      </p>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <input
                        type="text"
                        name="city"
                        placeholder="City"
                        value={shippingAddress.city}
                        onChange={handleAddressChange}
                        className={`w-full p-2 border rounded-lg ${
                          formErrors.city
                            ? "border-red-500"
                            : "border-[#DAA520]"
                        }`}
                      />
                      {formErrors.city && (
                        <p className="text-red-500 text-sm mt-1">
                          {formErrors.city}
                        </p>
                      )}
                    </div>
                    <div>
                      <input
                        type="text"
                        name="state"
                        placeholder="State"
                        value={shippingAddress.state}
                        onChange={handleAddressChange}
                        className={`w-full p-2 border rounded-lg ${
                          formErrors.state
                            ? "border-red-500"
                            : "border-[#DAA520]"
                        }`}
                      />
                      {formErrors.state && (
                        <p className="text-red-500 text-sm mt-1">
                          {formErrors.state}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <input
                        type="text"
                        name="zipCode"
                        placeholder="ZIP Code"
                        value={shippingAddress.zipCode}
                        onChange={handleAddressChange}
                        className={`w-full p-2 border rounded-lg ${
                          formErrors.zipCode
                            ? "border-red-500"
                            : "border-[#DAA520]"
                        }`}
                      />
                      {formErrors.zipCode && (
                        <p className="text-red-500 text-sm mt-1">
                          {formErrors.zipCode}
                        </p>
                      )}
                    </div>
                    <div>
                      <input
                        type="text"
                        name="country"
                        placeholder="Country"
                        value={shippingAddress.country}
                        onChange={handleAddressChange}
                        className={`w-full p-2 border rounded-lg ${
                          formErrors.country
                            ? "border-red-500"
                            : "border-[#DAA520]"
                        }`}
                      />
                      {formErrors.country && (
                        <p className="text-red-500 text-sm mt-1">
                          {formErrors.country}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border-2 border-[#DAA520]">
                <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                  Payment Method
                </h2>
                <div className="space-y-4">
                  {paymentMethods.map((method) => (
                    <div
                      key={method.id}
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                        selectedMethod?.id === method.id
                          ? "border-[#DAA520] bg-[#FFF8DC]"
                          : "border-[#DAA520] hover:border-[#B8860B]"
                      }`}
                      onClick={() => handleMethodSelect(method)}
                    >
                      <div className="flex items-center space-x-4">
                        <img
                          src={method.iconUrl}
                          alt={method.name}
                          className="w-8 h-8 object-contain"
                        />
                        <div>
                          <div className="font-bold text-[#1e293b]">
                            {method.name}
                          </div>
                          <div className="text-sm text-[#475569]">
                            {method.description}
                          </div>
                          <div className="text-xs text-[#DAA520]">
                            {method.localCurrency} {method.localPrice}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={processingOrder || !selectedMethod}
                className="w-full bg-[#DAA520] text-white py-3 rounded-full hover:bg-[#B8860B] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {processingOrder ? (
                  <span className="flex items-center justify-center">
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Processing...
                  </span>
                ) : (
                  "Complete Purchase"
                )}
              </button>
            </form>
          </div>

          <div>
            <div className="bg-white p-6 rounded-lg border-2 border-[#DAA520]">
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                Order Summary
              </h2>
              <div className="space-y-4">
                <div className="flex justify-between text-[#475569]">
                  <span>Subtotal</span>
                  <span>${orderSummary.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#475569]">
                  <span>Tax</span>
                  <span>${orderSummary.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#475569]">
                  <span>Shipping</span>
                  <span>${orderSummary.shipping.toFixed(2)}</span>
                </div>
                <div className="border-t border-[#DAA520] pt-4">
                  <div className="flex justify-between font-bold text-[#1e293b] text-xl">
                    <span>Total</span>
                    <span>${orderSummary.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {userCountry && userCountry !== "DEFAULT" && (
                <div className="mt-4 text-sm text-[#475569]">
                  {userCountry === "DO"
                    ? "ITBIS included where applicable. Cash on delivery available."
                    : "Tax rates calculated based on shipping destination."}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;