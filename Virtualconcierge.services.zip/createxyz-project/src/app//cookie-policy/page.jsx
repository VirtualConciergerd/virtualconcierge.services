"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#3b82f6] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Cookie Policy</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Cookie Policy
          </h1>
          <p className="text-[#475569] mb-4">
            Last Updated: {new Date().toLocaleDateString()}
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                1. What Are Cookies
              </h2>
              <p className="text-[#475569] mb-4">
                Cookies are small text files that are placed on your computer or
                mobile device when you visit our website. They are widely used
                to make websites work more efficiently and provide a better
                browsing experience.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                2. How We Use Cookies
              </h2>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Essential Cookies
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Authentication and security</li>
                  <li>Shopping cart functionality</li>
                  <li>Session management</li>
                </ul>

                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Analytical Cookies
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Website traffic analysis</li>
                  <li>User behavior tracking</li>
                  <li>Performance monitoring</li>
                </ul>

                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Functional Cookies
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Remember your preferences</li>
                  <li>Personalization settings</li>
                  <li>Language selection</li>
                </ul>

                <h3 className="text-lg font-semibold text-[#1e293b]">
                  Marketing Cookies
                </h3>
                <ul className="list-disc pl-6 text-[#475569] space-y-2">
                  <li>Targeted advertising</li>
                  <li>Social media integration</li>
                  <li>Marketing analytics</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                3. Third-Party Cookies
              </h2>
              <p className="text-[#475569] mb-4">
                We use services from these third parties that may place cookies:
              </p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Google Analytics - Analytics</li>
                <li>Stripe - Payment processing</li>
                <li>Social media platforms - Sharing and integration</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                4. Managing Cookies
              </h2>
              <p className="text-[#475569] mb-4">
                You can control cookies through your browser settings:
              </p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Chrome: Settings → Privacy and Security → Cookies</li>
                <li>Firefox: Options → Privacy & Security → Cookies</li>
                <li>Safari: Preferences → Privacy → Cookies</li>
                <li>Edge: Settings → Privacy & Security → Cookies</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                5. Cookie Consent
              </h2>
              <p className="text-[#475569] mb-4">
                When you first visit our website, you'll be asked to accept or
                decline non-essential cookies. You can change your preferences
                at any time through our cookie settings.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;