"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <nav className="fixed w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <img
              src="https://ucarecdn.com/14ced8ff-eb12-41f4-9957-49f8f6cab876/-/format/auto/"
              alt="Virtual Concierge Logo"
              className="h-10 w-auto"
            />
            <div className="text-2xl font-crimson-text text-[#1e293b] font-bold">
              Virtual Concierge
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <a
              href="mailto:Contactus@virtualconcierge.services"
              className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
            >
              <i className="fas fa-envelope mr-2"></i>
              Contact Us
            </a>
            <a
              href="/"
              className="bg-[#3b82f6] text-white px-6 py-2 rounded-full hover:bg-[#2563eb] transition-colors"
            >
              Try Now
            </a>
          </div>
        </div>
      </nav>

      <main className="pt-24">
        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-crimson-text text-[#1e293b] font-bold mb-6 text-center">
              About Virtual Concierge
            </h1>
            <p className="text-xl text-[#475569] mb-12 max-w-3xl mx-auto text-center">
              Revolutionizing travel experiences through AI-powered personalized
              assistance
            </p>
          </div>
        </section>
        <section className="py-16 px-4 bg-white">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-8">
              Our Mission
            </h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <p className="text-lg text-[#475569] mb-6">
                  At Virtual Concierge, we're dedicated to making travel more
                  accessible, enjoyable, and enriching for everyone. Our
                  AI-powered platform breaks down language barriers, provides
                  real-time assistance, and offers personalized recommendations
                  to ensure every journey is memorable.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                    <p className="text-[#475569]">
                      Commitment to innovation and technological excellence
                    </p>
                  </div>
                  <div className="flex items-start">
                    <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                    <p className="text-[#475569]">
                      Dedication to cultural understanding and respect
                    </p>
                  </div>
                  <div className="flex items-start">
                    <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                    <p className="text-[#475569]">
                      Focus on sustainable and responsible tourism
                    </p>
                  </div>
                </div>
              </div>
              <div className="relative h-[400px]">
                <img
                  src="/images/mission.jpg"
                  alt="Team collaborating on travel solutions"
                  className="rounded-lg shadow-lg object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
              Meet Our Team
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <img
                  src="https://ucarecdn.com/f7a305e7-c34a-4962-9a1d-668223a474a1/-/format/auto/"
                  alt="CEO and Founder"
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Nino Acosta
                </h3>
                <p className="text-[#3b82f6]">CEO & Founder</p>
              </div>
              <div className="text-center">
                <img
                  src="https://ucarecdn.com/ace54da1-c23e-4177-84cf-95c1cba4d606/-/format/auto/-/scale_crop/300x300/center/"
                  alt="Chief Technology Officer"
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Alberto Rodriguez
                </h3>
                <p className="text-[#3b82f6]">Chief Technology Officer</p>
              </div>
              <div className="text-center">
                <img
                  src="https://ucarecdn.com/2d255821-74fc-4255-aab7-56fd91696890/-/format/auto/-/scale_crop/300x300/center/"
                  alt="Head of Customer Experience"
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Luna Chavez
                </h3>
                <p className="text-[#3b82f6]">Head of Customer Experience</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-white">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
              How It Works
            </h2>
            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#3b82f6] rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4">
                  1
                </div>
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Sign Up
                </h3>
                <p className="text-[#475569]">Create your account in seconds</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#3b82f6] rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4">
                  2
                </div>
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Set Preferences
                </h3>
                <p className="text-[#475569]">Tell us your travel style</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#3b82f6] rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4">
                  3
                </div>
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Get Recommendations
                </h3>
                <p className="text-[#475569]">
                  Receive personalized suggestions
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#3b82f6] rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4">
                  4
                </div>
                <h3 className="text-xl font-bold text-[#1e293b] mb-2">
                  Travel Smart
                </h3>
                <p className="text-[#475569]">Enjoy your enhanced experience</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-12 text-center">
              What Our Users Say
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "Virtual Concierge made our family trip to the Dominican
                  Republic absolutely seamless. The real-time translations and
                  local insights were invaluable!"
                </p>
                <div className="font-bold text-[#1e293b]">Michael P.</div>
                <div className="text-sm text-[#475569]">Family Traveler</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "As a solo traveler, having this AI companion gave me the
                  confidence to explore off-the-beaten-path locations with peace
                  of mind."
                </p>
                <div className="font-bold text-[#1e293b]">Lisa R.</div>
                <div className="text-sm text-[#475569]">Solo Adventurer</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-yellow-400 mb-4">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <p className="text-[#475569] mb-4">
                  "The restaurant recommendations were spot-on! It felt like
                  having a local friend showing you around the city."
                </p>
                <div className="font-bold text-[#1e293b]">David K.</div>
                <div className="text-sm text-[#475569]">Food Enthusiast</div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-[#1e293b] text-white text-center">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-crimson-text font-bold mb-6">
              Ready to Transform Your Travel Experience?
            </h2>
            <p className="text-xl mb-8">
              Join thousands of satisfied travelers using Virtual Concierge
            </p>
            <a
              href="/"
              className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-[#f8fafc] transition-colors inline-block"
            >
              Get Started Now
            </a>
          </div>
        </section>
      </main>

      <footer className="bg-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-crimson-text text-xl font-bold text-[#1e293b] mb-4">
                Virtual Concierge
              </h3>
              <p className="text-[#475569]">Your AI-powered travel companion</p>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Features</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>AI Assistant</li>
                <li>Translation Services</li>
                <li>Local Recommendations</li>
                <li>Travel Planning</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Company</h4>
              <ul className="space-y-2 text-[#475569]">
                <li>About Us</li>
                <li>
                  <a
                    href="mailto:Contactus@virtualconcierge.services"
                    className="text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                  >
                    <i className="fas fa-envelope mr-2"></i>
                    Contactus@virtualconcierge.services
                  </a>
                </li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#1e293b] mb-4">Connect</h4>
              <div className="flex space-x-4">
                <i className="fab fa-twitter text-[#3b82f6] text-xl"></i>
                <i className="fab fa-facebook text-[#3b82f6] text-xl"></i>
                <i className="fab fa-instagram text-[#3b82f6] text-xl"></i>
                <i className="fab fa-linkedin text-[#3b82f6] text-xl"></i>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-200 text-center text-[#475569]">
            <p>&copy; 2025 Virtual Concierge. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;