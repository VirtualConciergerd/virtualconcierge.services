"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const { settings, updateSettings, detectedTimezone, countryFormats } =
    useRegional();
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const [error, setError] = useState(null);
  const [recentActivity, setRecentActivity] = useState([]);
  const [country, setCountry] = useState(null);
  const [countryLoading, setCountryLoading] = useState(true);
  const [systemStatus, setSystemStatus] = useState({
    database: "loading",
    api: "loading",
    storage: "loading",
    lastChecked: new Date(),
  });
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    pending: 0,
  });
  const [preferences, setPreferences] = useState({
    theme: "light",
    notifications: true,
    autoRefresh: true,
    communication: {
      email_digest: "weekly",
      do_not_disturb: false,
      digest_day: "Monday",
      notification_schedule: "08:00-17:00",
    },
  });
  const [tasksLoading, setTasksLoading] = useState(true);
  const [preferencesLoading, setPreferencesLoading] = useState(true);

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin?callbackUrl=/home";
    }
  }, [user, userLoading]);

  useEffect(() => {
    const detectCountry = async () => {
      try {
        const response = await fetch("/api/detect-country", { method: "POST" });
        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const data = await response.json();
        setCountry(data);
      } catch (err) {
        console.error(err);
        setError("Could not detect country");
      } finally {
        setCountryLoading(false);
      }
    };

    const checkSystemStatus = async () => {
      try {
        const response = await fetch("/api/system-status", { method: "POST" });
        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const data = await response.json();
        setSystemStatus({
          ...data,
          lastChecked: new Date(),
        });
      } catch (err) {
        console.error(err);
        setSystemStatus((prev) => ({
          ...prev,
          database: "error",
          api: "error",
          storage: "error",
        }));
      }
    };

    detectCountry();
    checkSystemStatus();
  }, []);

  const fetchTasks = async () => {
    setTasksLoading(true);
    try {
      const response = await fetch("/api/tasks");
      if (!response.ok) throw new Error("Failed to fetch tasks");
      const data = await response.json();
      setTasks(data);

      const completed = data.filter((task) => task.completed).length;
      setStats({
        total: data.length,
        completed,
        pending: data.length - completed,
      });
    } catch (err) {
      console.error(err);
      setError("Could not load tasks");
    } finally {
      setTasksLoading(false);
    }
  };

  const addTask = async (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;

    try {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: newTask }),
      });

      if (!response.ok) throw new Error("Failed to add task");

      setNewTask("");
      fetchTasks();
      setRecentActivity((prev) => [
        {
          type: "add",
          task: newTask,
          timestamp: new Date(),
        },
        ...prev.slice(0, 4),
      ]);
    } catch (err) {
      console.error(err);
      setError("Could not add task");
    }
  };

  const toggleTask = async (taskId) => {
    try {
      const task = tasks.find((t) => t.id === taskId);
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: !task.completed }),
      });

      if (!response.ok) throw new Error("Failed to update task");

      fetchTasks();
      setRecentActivity((prev) => [
        {
          type: "update",
          task: task.title,
          timestamp: new Date(),
        },
        ...prev.slice(0, 4),
      ]);
    } catch (err) {
      console.error(err);
      setError("Could not update task");
    }
  };

  const deleteTask = async (taskId) => {
    try {
      const task = tasks.find((t) => t.id === taskId);
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete task");

      fetchTasks();
      setRecentActivity((prev) => [
        {
          type: "delete",
          task: task.title,
          timestamp: new Date(),
        },
        ...prev.slice(0, 4),
      ]);
    } catch (err) {
      console.error(err);
      setError("Could not delete task");
    }
  };

  const updatePreferences = async (newPreferences) => {
    try {
      const response = await fetch("/api/user/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPreferences),
      });

      if (!response.ok) throw new Error("Failed to update preferences");
      setPreferences(newPreferences);
    } catch (err) {
      console.error(err);
      setError("Could not update preferences");
    }
  };

  const updateCommunicationPreferences = async (newPrefs) => {
    try {
      const response = await fetch("/api/update-communication-preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPrefs),
      });

      if (!response.ok) throw new Error("Failed to update preferences");
      const data = await response.json();
      setPreferences((prev) => ({
        ...prev,
        communication: data.preferences,
      }));
    } catch (err) {
      setError("Could not update communication preferences");
    }
  };

  const requestDataExport = async () => {
    try {
      const response = await fetch("/api/export-user-data", { method: "POST" });
      if (!response.ok) throw new Error("Failed to export data");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "user-data.json";
      a.click();
    } catch (err) {
      console.error(err);
      setError("Could not export data");
    }
  };

  const requestAccountDeletion = async (reason) => {
    try {
      const response = await fetch("/api/request-account-deletion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });

      if (!response.ok) throw new Error("Failed to request deletion");
      window.location.href = "/account/logout";
    } catch (err) {
      console.error(err);
      setError("Could not submit deletion request");
    }
  };

  useEffect(() => {
    if (user) {
      fetchTasks();
      const interval = setInterval(fetchTasks, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  if (userLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <i className="fas fa-spinner fa-spin text-4xl text-[#2EC4B6] mb-4"></i>
        <p className="text-[#4F5D75] text-lg">Loading your dashboard...</p>
      </div>
    );
  }

  if (!user) return null;

  const isAdmin = user.role === "admin";

  return (
    <ErrorBoundary
      fallbackUI={({ error, reset }) => (
        <div className="bg-red-100 p-4 rounded-lg">
          <p className="text-red-800 mb-2">Error: {error.message}</p>
          <button
            onClick={reset}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Retry
          </button>
        </div>
      )}
    >
      <div className="min-h-screen bg-[#FDFFFC] pt-16 md:pt-24 px-2 md:px-4">
        <div className="max-w-7xl mx-auto">
          <nav className="mb-4 flex items-center text-sm">
            <a href="/" className="text-[#4F5D75] hover:text-[#2EC4B6]">
              Home
            </a>
            <i className="fas fa-chevron-right mx-2 text-[#4F5D75]/50"></i>
            <span className="text-[#4F5D75]/70">Dashboard</span>
          </nav>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-8">
            <div className="card rounded-lg shadow-lg p-4 md:p-6 col-span-2">
              <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-crimson-text text-white font-bold mb-2">
                    Welcome back, {user.name || "Guest"}!
                  </h1>
                  <p className="text-white/80">Here's your system overview</p>
                </div>
                {isAdmin && (
                  <div className="flex flex-wrap gap-2 md:gap-4">
                    <a
                      href="/admin/countries"
                      className="btn px-3 md:px-4 py-2 rounded interactive text-sm md:text-base"
                    >
                      Manage Countries
                    </a>
                    <a
                      href="/411"
                      className="btn px-3 md:px-4 py-2 rounded interactive text-sm md:text-base"
                    >
                      Emergency Info
                    </a>
                  </div>
                )}
              </div>
            </div>
            <div className="card rounded-lg shadow-lg p-4 md:p-6">
              <div className="flex flex-col gap-4">
                <h3 className="text-white font-bold">User Preferences</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Theme</span>
                    <select
                      value={preferences.theme}
                      onChange={(e) =>
                        updatePreferences({
                          ...preferences,
                          theme: e.target.value,
                        })
                      }
                      className="bg-white/10 text-white border-0 rounded p-1"
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Notifications</span>
                    <input
                      type="checkbox"
                      checked={preferences.notifications}
                      onChange={(e) =>
                        updatePreferences({
                          ...preferences,
                          notifications: e.target.checked,
                        })
                      }
                      className="bg-white/10 rounded"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Auto-refresh</span>
                    <input
                      type="checkbox"
                      checked={preferences.autoRefresh}
                      onChange={(e) =>
                        updatePreferences({
                          ...preferences,
                          autoRefresh: e.target.checked,
                        })
                      }
                      className="bg-white/10 rounded"
                    />
                  </div>
                </div>
                <div className="pt-4 border-t border-white/10">
                  <h3 className="text-white font-bold mb-4">
                    Communication Preferences
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-white/80">Email Digest</span>
                      <select
                        value={
                          preferences.communication?.email_digest || "weekly"
                        }
                        onChange={(e) =>
                          updateCommunicationPreferences({
                            email_digest: e.target.value,
                          })
                        }
                        className="bg-white/10 text-white border-0 rounded p-1"
                      >
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                      </select>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/80">Do Not Disturb</span>
                      <input
                        type="checkbox"
                        checked={
                          preferences.communication?.do_not_disturb || false
                        }
                        onChange={(e) =>
                          updateCommunicationPreferences({
                            do_not_disturb: e.target.checked,
                          })
                        }
                        className="bg-white/10 rounded"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-8">
            <div className="card rounded-lg shadow-lg p-4 md:p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-bold">Country Status</h3>
                <div className="flex items-center">
                  <span
                    className={`w-3 h-3 rounded-full mr-2 ${
                      countryLoading
                        ? "bg-yellow-400"
                        : country
                        ? "bg-green-400"
                        : "bg-red-400"
                    }`}
                  ></span>
                  <span className="text-sm text-white/80">
                    {countryLoading
                      ? "Detecting..."
                      : country
                      ? country.name
                      : "Not Detected"}
                  </span>
                </div>
              </div>
            </div>
            <div className="card rounded-lg shadow-lg p-4 md:p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-bold">System Status</h3>
                <button
                  onClick={() => {
                    const checkSystemStatus = async () => {
                      try {
                        const response = await fetch("/api/system-status", {
                          method: "POST",
                        });
                        if (!response.ok)
                          throw new Error(`Error: ${response.status}`);
                        const data = await response.json();
                        setSystemStatus({
                          ...data,
                          lastChecked: new Date(),
                        });
                      } catch (err) {
                        console.error(err);
                        setSystemStatus((prev) => ({
                          ...prev,
                          database: "error",
                          api: "error",
                          storage: "error",
                        }));
                      }
                    };
                    checkSystemStatus();
                  }}
                  className="text-white/80 hover:text-white"
                >
                  <i className="fas fa-sync-alt"></i>
                </button>
              </div>
              <div className="mt-3 space-y-2">
                {Object.entries(systemStatus).map(
                  ([key, status]) =>
                    key !== "lastChecked" && (
                      <div
                        key={key}
                        className="flex items-center justify-between"
                      >
                        <span className="text-sm text-white/80 capitalize">
                          {key}
                        </span>
                        <span
                          className={`text-sm ${
                            status === "operational"
                              ? "text-green-400"
                              : status === "loading"
                              ? "text-yellow-400"
                              : "text-red-400"
                          }`}
                        >
                          {status === "operational"
                            ? "✓"
                            : status === "loading"
                            ? "..."
                            : "✗"}
                        </span>
                      </div>
                    )
                )}
              </div>
            </div>
            <div className="card rounded-lg shadow-lg p-4 md:p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-bold">Task Stats</h3>
                <div className="text-sm text-white/80">
                  {stats.completed}/{stats.total}
                </div>
              </div>
              <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-400 transition-all duration-500"
                  style={{
                    width: `${
                      stats.total ? (stats.completed / stats.total) * 100 : 0
                    }%`,
                  }}
                ></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
            <div className="lg:col-span-2">
              <div className="card rounded-lg shadow-lg p-4 md:p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-crimson-text text-white font-bold">
                    Task Management
                  </h2>
                  <button
                    onClick={fetchTasks}
                    className="text-white/80 hover:text-white"
                    disabled={tasksLoading}
                  >
                    <i
                      className={`fas fa-sync-alt ${
                        tasksLoading ? "fa-spin" : ""
                      }`}
                    ></i>
                  </button>
                </div>

                {error && (
                  <div className="bg-red-500/10 text-red-400 p-4 rounded mb-4 flex items-center justify-between">
                    <span>{error}</span>
                    <button
                      onClick={() => setError(null)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <i className="fas fa-times"></i>
                    </button>
                  </div>
                )}

                <form onSubmit={addTask} className="mb-6">
                  <div className="flex flex-col md:flex-row gap-2">
                    <input
                      type="text"
                      value={newTask}
                      onChange={(e) => setNewTask(e.target.value)}
                      placeholder="Add a new task..."
                      className="flex-1 p-2 border rounded bg-white text-[#4F5D75] placeholder-[#4F5D75]/60 focus:ring-2 focus:ring-white focus:border-transparent interactive"
                    />
                    <button
                      type="submit"
                      className="btn px-4 py-2 rounded interactive whitespace-nowrap"
                    >
                      Add Task
                    </button>
                  </div>
                </form>

                <div className="space-y-4">
                  {tasksLoading ? (
                    <div className="flex justify-center py-8">
                      <i className="fas fa-spinner fa-spin text-2xl text-white/50"></i>
                    </div>
                  ) : tasks.length === 0 ? (
                    <div className="text-center py-8 text-white/50">
                      No tasks yet. Add your first task above!
                    </div>
                  ) : (
                    tasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between p-4 bg-white/10 rounded-lg interactive"
                      >
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            checked={task.completed}
                            onChange={() => toggleTask(task.id)}
                            className="mr-3 h-5 w-5 bg-white text-[#4F5D75] rounded interactive"
                          />
                          <span
                            className={
                              task.completed
                                ? "line-through text-white/50"
                                : "text-white"
                            }
                          >
                            {task.title}
                          </span>
                        </div>
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="text-white/80 hover:text-white interactive ml-4"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="lg:col-span-1 space-y-8">
              <div className="card rounded-lg shadow-lg p-4 md:p-6">
                <h3 className="text-xl font-crimson-text text-white font-bold mb-6">
                  Regional Settings
                </h3>
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <label className="text-white/80" htmlFor="timezone">
                      Time Zone
                    </label>
                    <div className="text-white text-sm">
                      {detectedTimezone}
                      <span className="ml-2 text-white/60">
                        (Auto-detected)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white/80" htmlFor="dateFormat">
                      Date Format
                    </label>
                    <select
                      id="dateFormat"
                      value={settings.date_format}
                      onChange={(e) =>
                        updateSettings({
                          ...settings,
                          date_format: e.target.value,
                        })
                      }
                      className="bg-white/10 text-white border-0 rounded p-2"
                    >
                      {countryFormats?.date_formats.map((format) => (
                        <option key={format} value={format}>
                          {new Date().toLocaleDateString(undefined, {
                            dateStyle: "short",
                          })}
                          ({format})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white/80" htmlFor="timeFormat">
                      Time Format
                    </label>
                    <select
                      id="timeFormat"
                      value={settings.time_format}
                      onChange={(e) =>
                        updateSettings({
                          ...settings,
                          time_format: e.target.value,
                        })
                      }
                      className="bg-white/10 text-white border-0 rounded p-2"
                    >
                      <option value="12h">12-hour (1:00 PM)</option>
                      <option value="24h">24-hour (13:00)</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white/80" htmlFor="firstDayOfWeek">
                      First Day of Week
                    </label>
                    <select
                      id="firstDayOfWeek"
                      value={settings.first_day_of_week}
                      onChange={(e) =>
                        updateSettings({
                          ...settings,
                          first_day_of_week: e.target.value,
                        })
                      }
                      className="bg-white/10 text-white border-0 rounded p-2"
                    >
                      <option value="sunday">Sunday</option>
                      <option value="monday">Monday</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white/80" htmlFor="calendarType">
                      Calendar Type
                    </label>
                    <select
                      id="calendarType"
                      value={settings.calendar_type}
                      onChange={(e) =>
                        updateSettings({
                          ...settings,
                          calendar_type: e.target.value,
                        })
                      }
                      className="bg-white/10 text-white border-0 rounded p-2"
                    >
                      <option value="gregorian">Gregorian</option>
                      <option value="lunar">Lunar</option>
                      <option value="islamic">Islamic</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white/80">Show Local Holidays</label>
                    <div className="relative inline-block w-12 h-6">
                      <input
                        type="checkbox"
                        className="sr-only"
                        checked={settings.show_holidays}
                        onChange={(e) =>
                          updateSettings({
                            ...settings,
                            show_holidays: e.target.checked,
                          })
                        }
                      />
                      <div
                        className={`absolute inset-0 rounded-full transition ${
                          settings.show_holidays
                            ? "bg-green-400"
                            : "bg-gray-400"
                        }`}
                      ></div>
                      <div
                        className={`absolute inset-y-0 left-0 w-6 h-6 bg-white rounded-full transition transform ${
                          settings.show_holidays
                            ? "translate-x-6"
                            : "translate-x-0"
                        }`}
                      ></div>
                    </div>
                  </div>

                  {settings.show_holidays && (
                    <div className="space-y-2">
                      <label className="text-white/80 block">
                        Holiday Calendar Preferences
                      </label>
                      <div className="max-h-40 overflow-y-auto bg-white/10 rounded p-2">
                        {countryFormats?.holidays.map((holiday) => (
                          <label
                            key={holiday.name}
                            className="flex items-center space-x-2 text-white/80 py-1"
                          >
                            <input
                              type="checkbox"
                              checked={settings.preferred_holidays.includes(
                                holiday.name
                              )}
                              onChange={(e) => {
                                const newHolidays = e.target.checked
                                  ? [
                                      ...settings.preferred_holidays,
                                      holiday.name,
                                    ]
                                  : settings.preferred_holidays.filter(
                                      (h) => h !== holiday.name
                                    );
                                updateSettings({
                                  ...settings,
                                  preferred_holidays: newHolidays,
                                });
                              }}
                            />
                            <span>{holiday.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="card rounded-lg shadow-lg p-6">
                  <h2 className="text-xl font-crimson-text text-white font-bold mb-6">
                    Recent Activity
                  </h2>
                  <div className="space-y-4">
                    {recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`mt-1 text-lg text-white`}>
                          <i
                            className={`fas fa-${
                              activity.type === "add"
                                ? "plus-circle"
                                : activity.type === "delete"
                                ? "trash"
                                : "check-circle"
                            }`}
                          ></i>
                        </div>
                        <div>
                          <p className="text-white/80">
                            {activity.type === "add"
                              ? "Added task: "
                              : activity.type === "delete"
                              ? "Deleted task: "
                              : "Updated task: "}
                            {activity.task}
                          </p>
                          <p className="text-sm text-white/60">
                            {new Date(activity.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="card rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-crimson-text text-white font-bold mb-6">
                  Emergency Contacts
                </h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white/10 rounded-lg interactive">
                    <div className="flex items-center">
                      <i className="fas fa-phone-alt text-white mr-3"></i>
                      <div>
                        <p className="font-bold text-white">Emergency Number</p>
                        <p className="text-white/80">
                          {country?.emergency_number || "911"}
                        </p>
                      </div>
                    </div>
                    <a
                      href="/411"
                      className="text-white hover:text-white/80 interactive"
                    >
                      <i className="fas fa-external-link-alt"></i>
                    </a>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/10 rounded-lg interactive">
                    <div className="flex items-center">
                      <i className="fas fa-info-circle text-white mr-3"></i>
                      <div>
                        <p className="font-bold text-white">Tourist Support</p>
                        <p className="text-white/80">
                          {country?.tourist_hotline || "1-809-200-3500"}
                        </p>
                      </div>
                    </div>
                    <a
                      href="/411"
                      className="text-white hover:text-white/80 interactive"
                    >
                      <i className="fas fa-external-link-alt"></i>
                    </a>
                  </div>
                </div>
              </div>

              <div className="card rounded-lg shadow-lg p-4 md:p-6">
                <h3 className="text-white font-bold mb-4">Data & Privacy</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Export Your Data</span>
                    <button
                      onClick={requestDataExport}
                      className="btn px-4 py-2 rounded interactive"
                    >
                      Download Data
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-white/80">Account Deletion</span>
                    <button
                      onClick={() => {
                        const reason = window.prompt(
                          "Please tell us why you want to delete your account:"
                        );
                        if (reason) requestAccountDeletion(reason);
                      }}
                      className="btn bg-red-500 text-white px-4 py-2 rounded interactive"
                    >
                      Request Deletion
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default MainComponent;