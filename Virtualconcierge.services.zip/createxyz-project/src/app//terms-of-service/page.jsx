"use client";
import React from "react";

function MainComponent() {
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#3b82f6] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Terms of Service</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Terms of Service
          </h1>
          <p className="text-[#475569] mb-4">
            Last Updated: {new Date().toLocaleDateString()}
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                1. Agreement to Terms
              </h2>
              <p className="text-[#475569] mb-4">
                By accessing or using Virtual Concierge's services, you agree to
                be bound by these Terms of Service and all applicable laws and
                regulations. If you do not agree with any of these terms, you
                are prohibited from using or accessing our services.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                2. Use License
              </h2>
              <div className="space-y-4 text-[#475569]">
                <p>
                  Permission is granted to temporarily access our services for
                  personal, non-commercial transitory viewing only. This is the
                  grant of a license, not a transfer of title, and under this
                  license you may not:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Modify or copy the materials</li>
                  <li>Use the materials for any commercial purpose</li>
                  <li>Attempt to decompile or reverse engineer any software</li>
                  <li>Remove any copyright or other proprietary notations</li>
                  <li>Transfer the materials to another person</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                3. Account Terms
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>You must be 18 years or older to use our services</li>
                <li>
                  You must provide accurate and complete information when
                  creating an account
                </li>
                <li>
                  You are responsible for maintaining the security of your
                  account
                </li>
                <li>
                  You must notify us immediately of any unauthorized use of your
                  account
                </li>
                <li>
                  We reserve the right to suspend or terminate accounts at our
                  discretion
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                4. Purchases and Payment
              </h2>
              <div className="space-y-4 text-[#475569]">
                <p>By making a purchase, you agree to:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>
                    Provide current, complete, and accurate purchase and account
                    information
                  </li>
                  <li>Pay all charges at the prices in effect when incurred</li>
                  <li>Pay all applicable taxes and charges</li>
                  <li>Use a valid payment method</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                5. Service Availability and Modifications
              </h2>
              <p className="text-[#475569] mb-4">We reserve the right to:</p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Modify or withdraw our services at any time</li>
                <li>Change our prices and fees at our discretion</li>
                <li>Limit service availability based on geographic location</li>
                <li>Modify these terms with reasonable notice</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                6. Intellectual Property
              </h2>
              <p className="text-[#475569] mb-4">
                The Virtual Concierge service and its original content,
                features, and functionality are owned by us and are protected by
                international copyright, trademark, patent, trade secret, and
                other intellectual property laws.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                7. User Content
              </h2>
              <p className="text-[#475569] mb-4">
                By posting content through our services, you grant us a
                non-exclusive, worldwide, royalty-free license to use, modify,
                publicly perform, publicly display, reproduce, and distribute
                such content.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                8. Prohibited Activities
              </h2>
              <p className="text-[#475569] mb-4">You may not:</p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Use our service for any illegal purpose</li>
                <li>Violate any laws in your jurisdiction</li>
                <li>Interfere with or disrupt our services</li>
                <li>Harass, abuse, or harm another person</li>
                <li>Attempt to gain unauthorized access to our systems</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                9. Disclaimer of Warranties
              </h2>
              <p className="text-[#475569] mb-4">
                Our services are provided "as is" without any warranties,
                expressed or implied. We do not guarantee that our services will
                be uninterrupted, secure, or error-free.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                10. Limitation of Liability
              </h2>
              <p className="text-[#475569] mb-4">
                We shall not be liable for any indirect, incidental, special,
                consequential, or punitive damages resulting from your use of
                our services.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                11. Indemnification
              </h2>
              <p className="text-[#475569] mb-4">
                You agree to indemnify and hold us harmless from any claims,
                losses, or damages, including legal fees, resulting from your
                violation of these terms or your use of our services.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                12. Governing Law
              </h2>
              <p className="text-[#475569] mb-4">
                These terms shall be governed by and construed in accordance
                with the laws of the Dominican Republic, without regard to its
                conflict of law provisions.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                13. Contact Information
              </h2>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-[#475569]">
                  For any questions regarding these Terms of Service, please
                  contact us at:
                </p>
                <p className="text-[#475569]">
                  Email: legal@virtualconcierge.com
                </p>
                <p className="text-[#475569]">Phone: +1 (809) 555-0123</p>
              </div>
            </section>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-[#475569] text-center">
              © {currentYear} Virtual Concierge. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;