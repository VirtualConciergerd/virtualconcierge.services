"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();

  const benefits = [
    {
      icon: "handshake",
      title: "Revenue Share",
      description: "Earn up to 30% commission on referred bookings",
    },
    {
      icon: "tools",
      title: "Marketing Tools",
      description: "Access to custom marketing materials and analytics",
    },
    {
      icon: "graduation-cap",
      title: "Training",
      description: "Comprehensive training and certification program",
    },
    {
      icon: "support",
      title: "Dedicated Support",
      description: "Personal partner success manager",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6] transition-colors"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Partner Program</span>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Join Our Partner Network
          </h1>
          <p className="text-xl text-[#475569] max-w-3xl mx-auto">
            Become part of the fastest-growing travel platform in the Dominican
            Republic
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-lg p-6 text-center"
            >
              <i
                className={`fas fa-${benefit.icon} text-3xl text-[#3b82f6] mb-4`}
              ></i>
              <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
                {benefit.title}
              </h3>
              <p className="text-[#475569]">{benefit.description}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Partner Requirements
            </h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">
                    Licensed Business
                  </h3>
                  <p className="text-[#475569]">
                    Valid business registration and licenses
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">Experience</h3>
                  <p className="text-[#475569]">
                    Minimum 2 years in tourism or hospitality
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-[#3b82f6] mt-1 mr-3"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">
                    Customer Service
                  </h3>
                  <p className="text-[#475569]">
                    Excellent customer service track record
                  </p>
                </div>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Partnership Levels
            </h2>
            <div className="space-y-6">
              <div className="border-l-4 border-[#3b82f6] pl-4">
                <h3 className="font-bold text-[#1e293b] mb-1">
                  Silver Partner
                </h3>
                <p className="text-[#475569]">
                  20% commission, basic tools access
                </p>
              </div>
              <div className="border-l-4 border-[#3b82f6] pl-4">
                <h3 className="font-bold text-[#1e293b] mb-1">Gold Partner</h3>
                <p className="text-[#475569]">
                  25% commission, premium tools, priority support
                </p>
              </div>
              <div className="border-l-4 border-[#3b82f6] pl-4">
                <h3 className="font-bold text-[#1e293b] mb-1">
                  Platinum Partner
                </h3>
                <p className="text-[#475569]">
                  30% commission, full suite access, dedicated manager
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] text-white rounded-lg shadow-lg p-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-crimson-text font-bold mb-6">
              Apply to Become a Partner
            </h2>
            <p className="text-lg mb-8">
              Join our network of successful partners and grow your business
              with Virtual Concierge
            </p>
            <button
              onClick={() => navigate("/business/partner-application")}
              className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-gray-100 transition-colors"
            >
              Apply Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;