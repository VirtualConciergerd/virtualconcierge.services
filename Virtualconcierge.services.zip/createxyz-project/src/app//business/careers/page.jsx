"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();

  const departments = [
    {
      name: "Engineering",
      positions: [
        {
          title: "Senior Full Stack Developer",
          location: "Santo Domingo",
          type: "Full-time",
        },
        {
          title: "AI/ML Engineer",
          location: "Remote",
          type: "Full-time",
        },
      ],
    },
    {
      name: "Product & Design",
      positions: [
        {
          title: "UX/UI Designer",
          location: "Santo Domingo",
          type: "Full-time",
        },
        {
          title: "Product Manager",
          location: "Hybrid",
          type: "Full-time",
        },
      ],
    },
    {
      name: "Sales & Marketing",
      positions: [
        {
          title: "Business Development Representative",
          location: "Santo Domingo",
          type: "Full-time",
        },
        {
          title: "Digital Marketing Specialist",
          location: "Remote",
          type: "Full-time",
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6] transition-colors"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Careers</span>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Join Our Team
          </h1>
          <p className="text-xl text-[#475569] max-w-3xl mx-auto">
            Help us revolutionize the travel industry in the Dominican Republic
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <i className="fas fa-rocket text-3xl text-[#3b82f6] mb-4"></i>
            <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
              Innovation
            </h3>
            <p className="text-[#475569]">
              Work on cutting-edge technology and shape the future of travel
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <i className="fas fa-users text-3xl text-[#3b82f6] mb-4"></i>
            <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
              Culture
            </h3>
            <p className="text-[#475569]">
              Join a diverse, inclusive team passionate about making an impact
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <i className="fas fa-chart-line text-3xl text-[#3b82f6] mb-4"></i>
            <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-2">
              Growth
            </h3>
            <p className="text-[#475569]">
              Accelerate your career with continuous learning and development
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 mb-16">
          <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-8">
            Open Positions
          </h2>
          <div className="space-y-8">
            {departments.map((dept, index) => (
              <div key={index}>
                <h3 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                  {dept.name}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {dept.positions.map((position, posIndex) => (
                    <div
                      key={posIndex}
                      className="border rounded-lg p-4 hover:border-[#3b82f6] transition-colors"
                    >
                      <h4 className="font-bold text-[#1e293b] mb-2">
                        {position.title}
                      </h4>
                      <div className="flex items-center text-[#475569] space-x-4">
                        <span className="flex items-center">
                          <i className="fas fa-map-marker-alt mr-2"></i>
                          {position.location}
                        </span>
                        <span className="flex items-center">
                          <i className="fas fa-clock mr-2"></i>
                          {position.type}
                        </span>
                      </div>
                      <button
                        onClick={() =>
                          navigate(
                            `/business/careers/${position.title
                              .toLowerCase()
                              .replace(/ /g, "-")}`
                          )
                        }
                        className="mt-4 text-[#3b82f6] hover:text-[#2563eb] transition-colors"
                      >
                        Learn More →
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1e293b] text-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-3xl font-crimson-text font-bold mb-6">
            Don't See the Right Fit?
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            We're always looking for talented individuals to join our team. Send
            us your resume and we'll keep you in mind for future opportunities.
          </p>
          <button
            onClick={() => navigate("/business/careers/general-application")}
            className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-gray-100 transition-colors"
          >
            Submit General Application
          </button>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;