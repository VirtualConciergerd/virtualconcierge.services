"use client";
import React from "react";
import BusinessTestimonials from "../../components/business-testimonials";
import BusinessFeatures from "../../components/business-features";

("use client");

function MainComponent() {
  const [formData, setFormData] = useState({
    businessName: "",
    businessType: "",
    contactPerson: "",
    email: "",
    phone: "",
    address: "",
    website: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const { data: user, loading: authLoading } = useUser();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (!user) {
        throw new Error("Please sign in to register your business");
      }

      const response = await fetch("/api/business/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to register business");
      }

      setSuccess(true);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0]">
      <BusinessHero
        title="Join Our Business Network"
        subtitle="Connect with travelers through AI-powered recommendations and grow your business"
        buttonText="Get Started"
        heroImage="https://picsum.photos/1920/1080"
      />

      <BusinessFeatures />

      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-3xl font-crimson-text font-bold text-[#1e293b] mb-6">
              Register Your Business
            </h2>
            <div className="bg-blue-50 text-blue-600 p-4 rounded-lg mb-6">
              <div className="flex items-start">
                <i className="fas fa-info-circle mt-1 mr-3"></i>
                <p>
                  All business registrations are carefully reviewed by our admin
                  team to ensure quality and authenticity. This process
                  typically takes 1-2 business days. You'll receive an email
                  notification once your registration has been approved.
                </p>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-500 p-4 rounded-lg mb-6">
                {error}
              </div>
            )}

            {success ? (
              <div className="bg-green-50 text-green-500 p-4 rounded-lg">
                Business registration submitted successfully! We'll review your
                application and contact you soon.
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-[#475569] mb-2">
                    Business Name *
                  </label>
                  <input
                    type="text"
                    name="businessName"
                    required
                    value={formData.businessName}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-[#475569] mb-2">
                    Business Type *
                  </label>
                  <select
                    name="businessType"
                    required
                    value={formData.businessType}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  >
                    <option value="">Select Type</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="hotel">Hotel</option>
                    <option value="attraction">Tourist Attraction</option>
                    <option value="tour">Tour Company</option>
                    <option value="transport">Transportation</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#475569] mb-2">
                    Contact Person *
                  </label>
                  <input
                    type="text"
                    name="contactPerson"
                    required
                    value={formData.contactPerson}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-[#475569] mb-2">Email *</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-[#475569] mb-2">Phone *</label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-[#475569] mb-2">Address *</label>
                  <textarea
                    name="address"
                    required
                    value={formData.address}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                    rows="3"
                  />
                </div>
                <div>
                  <label className="block text-[#475569] mb-2">
                    Website (Optional)
                  </label>
                  <input
                    type="url"
                    name="website"
                    value={formData.website}
                    onChange={handleChange}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading || authLoading}
                  className="w-full bg-[#3b82f6] text-white py-3 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50"
                >
                  {loading ? "Submitting..." : "Register Business"}
                </button>
              </form>
            )}
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-4">
                Verification Process
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-[#3b82f6] rounded-full flex items-center justify-center text-white">
                    1
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-[#1e293b]">
                      Submit Registration
                    </h4>
                    <p className="text-[#475569]">
                      Complete the registration form with your business details
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-[#3b82f6] rounded-full flex items-center justify-center text-white">
                    2
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-[#1e293b]">
                      Document Review
                    </h4>
                    <p className="text-[#475569]">
                      Our team reviews your business documentation
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-[#3b82f6] rounded-full flex items-center justify-center text-white">
                    3
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-[#1e293b]">
                      Verification
                    </h4>
                    <p className="text-[#475569]">
                      Quick verification of your business location and services
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-[#3b82f6] rounded-full flex items-center justify-center text-white">
                    4
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-[#1e293b]">
                      Activation
                    </h4>
                    <p className="text-[#475569]">
                      Your business goes live on our platform
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-crimson-text font-bold text-[#1e293b] mb-4">
                Integration Benefits
              </h3>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  <span className="text-[#475569]">
                    AI-powered customer matching
                  </span>
                </li>
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  <span className="text-[#475569]">
                    Real-time booking management
                  </span>
                </li>
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  <span className="text-[#475569]">
                    Multilingual customer support
                  </span>
                </li>
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  <span className="text-[#475569]">
                    Analytics and insights dashboard
                  </span>
                </li>
                <li className="flex items-center">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  <span className="text-[#475569]">
                    Virtual concierge promotion
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <BusinessTestimonials />
    </div>
  );
}

export default MainComponent;