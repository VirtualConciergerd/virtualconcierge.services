"use client";
import React from "react";

function MainComponent() {
  const [selectedPlan, setSelectedPlan] = useState(null);

  const adPlans = [
    {
      id: 1,
      name: "Starter",
      price: 299,
      period: "month",
      features: [
        "Featured listing in one province",
        "Basic analytics dashboard",
        "Monthly performance report",
        "Standard customer support",
      ],
      recommended: false,
    },
    {
      id: 2,
      name: "Professional",
      price: 799,
      period: "month",
      features: [
        "Featured listing in three provinces",
        "Advanced analytics dashboard",
        "Weekly performance reports",
        "Priority customer support",
        "Social media promotion",
      ],
      recommended: true,
    },
    {
      id: 3,
      name: "Enterprise",
      price: 1499,
      period: "month",
      features: [
        "Featured listing in all provinces",
        "Real-time analytics dashboard",
        "Daily performance reports",
        "Dedicated account manager",
        "Custom marketing campaigns",
        "API access",
      ],
      recommended: false,
    },
  ];

  const handleContactSales = (plan) => {
    setSelectedPlan(plan);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#3b82f6] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Advertise With Us</span>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Grow Your Business with Virtual Concierge
          </h1>
          <p className="text-xl text-[#475569] max-w-3xl mx-auto">
            Reach millions of travelers planning their Dominican Republic
            experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {adPlans.map((plan) => (
            <div
              key={plan.id}
              className={`bg-white rounded-lg shadow-lg overflow-hidden ${
                plan.recommended ? "ring-2 ring-[#3b82f6]" : ""
              }`}
            >
              {plan.recommended && (
                <div className="bg-[#3b82f6] text-white text-center py-2">
                  Recommended
                </div>
              )}
              <div className="p-6">
                <h3 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-4">
                  {plan.name}
                </h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-[#1e293b]">
                    ${plan.price}
                  </span>
                  <span className="text-[#475569]">/{plan.period}</span>
                </div>
                <ul className="space-y-4 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <i className="fas fa-check text-[#3b82f6] mt-1 mr-2"></i>
                      <span className="text-[#475569]">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => handleContactSales(plan)}
                  className="w-full bg-[#3b82f6] text-white py-3 rounded-lg hover:bg-[#2563eb] transition-colors"
                >
                  Contact Sales
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Why Advertise with Us?
            </h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fas fa-users text-[#3b82f6] mt-1 mr-3 text-xl"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">
                    Targeted Audience
                  </h3>
                  <p className="text-[#475569]">
                    Reach travelers actively planning their Dominican Republic
                    experience
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <i className="fas fa-chart-line text-[#3b82f6] mt-1 mr-3 text-xl"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">
                    Performance Tracking
                  </h3>
                  <p className="text-[#475569]">
                    Detailed analytics and ROI reporting
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <i className="fas fa-bullseye text-[#3b82f6] mt-1 mr-3 text-xl"></i>
                <div>
                  <h3 className="font-bold text-[#1e293b] mb-1">
                    Smart Targeting
                  </h3>
                  <p className="text-[#475569]">
                    AI-powered matching with interested travelers
                  </p>
                </div>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Success Stories
            </h2>
            <div className="space-y-6">
              <div className="border-l-4 border-[#3b82f6] pl-4">
                <p className="text-[#475569] mb-2">
                  "Our bookings increased by 200% within the first three months
                  of advertising with Virtual Concierge."
                </p>
                <p className="font-bold text-[#1e293b]">
                  - Luxury Resort, Punta Cana
                </p>
              </div>
              <div className="border-l-4 border-[#3b82f6] pl-4">
                <p className="text-[#475569] mb-2">
                  "The targeted approach helped us reach exactly the kind of
                  travelers we were looking for."
                </p>
                <p className="font-bold text-[#1e293b]">
                  - Tour Operator, Santo Domingo
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] text-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-3xl font-crimson-text font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Our advertising specialists are here to help you create the perfect
            campaign for your business
          </p>
          <a
            href="/business/contact-sales"
            className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-gray-100 transition-colors inline-block"
          >
            Schedule a Consultation
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;