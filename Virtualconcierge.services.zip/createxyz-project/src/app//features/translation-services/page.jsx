"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const [sourceText, setSourceText] = useState("");
  const [targetLanguage, setTargetLanguage] = useState("es");
  const [translatedText, setTranslatedText] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const languages = [
    { code: "es", name: "Spanish" },
    { code: "fr", name: "French" },
    { code: "de", name: "German" },
    { code: "it", name: "Italian" },
    { code: "pt", name: "Portuguese" },
    { code: "ru", name: "Russian" },
    { code: "zh", name: "Chinese" },
    { code: "ja", name: "Japanese" },
    { code: "ko", name: "Korean" },
    { code: "ar", name: "Arabic" },
  ];

  const handleTranslate = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch(
        "/integrations/google-translate/language/translate/v2",
        {
          method: "POST",
          body: new URLSearchParams({
            q: sourceText,
            target: targetLanguage,
          }),
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      setTranslatedText(result.data.translations[0].translatedText);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <a href="/" className="hover:text-[#3b82f6] transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Translation Services</span>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Break Language Barriers
          </h1>
          <p className="text-xl text-[#475569] max-w-3xl mx-auto">
            Communicate effortlessly with real-time translation powered by
            Google Translate
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Features & Benefits
              </h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <i className="fas fa-sync text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Real-Time Translation
                    </h3>
                    <p className="text-[#475569]">
                      Instant translation for seamless communication
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-globe text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Multiple Languages
                    </h3>
                    <p className="text-[#475569]">
                      Support for 10+ major languages
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-check-circle text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      High Accuracy
                    </h3>
                    <p className="text-[#475569]">
                      Powered by Google's advanced translation AI
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-mobile-alt text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Mobile-Friendly
                    </h3>
                    <p className="text-[#475569]">
                      Translate on any device, anywhere
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Supported Languages
              </h2>
              <div className="grid grid-cols-2 gap-4">
                {languages.map((lang) => (
                  <div key={lang.code} className="flex items-center space-x-2">
                    <i className="fas fa-check text-[#3b82f6]"></i>
                    <span className="text-[#475569]">{lang.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Try It Now
            </h2>
            <form onSubmit={handleTranslate} className="space-y-6">
              <div>
                <label
                  className="block text-[#1e293b] font-bold mb-2"
                  htmlFor="source-text"
                >
                  Enter Text
                </label>
                <textarea
                  name="sourceText"
                  id="source-text"
                  value={sourceText}
                  onChange={(e) => setSourceText(e.target.value)}
                  placeholder="Type or paste your text here"
                  className="w-full p-3 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent h-32"
                ></textarea>
              </div>

              <div>
                <label
                  className="block text-[#1e293b] font-bold mb-2"
                  htmlFor="target-language"
                >
                  Translate To
                </label>
                <select
                  name="targetLanguage"
                  id="target-language"
                  value={targetLanguage}
                  onChange={(e) => setTargetLanguage(e.target.value)}
                  className="w-full p-3 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={isLoading || !sourceText}
                className="w-full bg-[#3b82f6] text-white py-3 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50"
              >
                {isLoading ? (
                  <i className="fas fa-spinner fa-spin"></i>
                ) : (
                  "Translate"
                )}
              </button>

              {translatedText && (
                <div className="mt-6">
                  <h3 className="font-bold text-[#1e293b] mb-2">
                    Translation:
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-[#475569]">{translatedText}</p>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-language text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">1M+</h3>
              <p className="text-[#475569]">Translations performed</p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-globe-americas text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">10+</h3>
              <p className="text-[#475569]">Languages supported</p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-check-circle text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">99%</h3>
              <p className="text-[#475569]">Translation accuracy</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] text-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-3xl font-crimson-text font-bold mb-6">
            Start Communicating Globally
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Break down language barriers and connect with travelers from around
            the world
          </p>
          <a
            href="/account/signup"
            className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-gray-100 transition-colors inline-block"
          >
            Try It Free
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;