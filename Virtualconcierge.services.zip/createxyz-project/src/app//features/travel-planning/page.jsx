"use client";
import React from "react";

function MainComponent() {
  const [selectedDuration, setSelectedDuration] = useState("3");
  const [interests, setInterests] = useState([]);
  const [budget, setBudget] = useState("medium");
  const [sampleItinerary, setSampleItinerary] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const interestOptions = [
    { id: "beaches", label: "Beaches", icon: "umbrella-beach" },
    { id: "culture", label: "Culture & History", icon: "landmark" },
    { id: "food", label: "Food & Dining", icon: "utensils" },
    { id: "adventure", label: "Adventure", icon: "hiking" },
    { id: "nightlife", label: "Nightlife", icon: "moon" },
    { id: "shopping", label: "Shopping", icon: "shopping-bag" },
  ];
  const handleInterestToggle = (interestId) => {
    if (interests.includes(interestId)) {
      setInterests(interests.filter((id) => id !== interestId));
    } else {
      setInterests([...interests, interestId]);
    }
  };
  const generateSampleItinerary = async () => {
    setIsLoading(true);
    try {
      const prompt = `Create a ${selectedDuration}-day itinerary for the Dominican Republic focusing on ${interests.join(
        ", "
      )} with a ${budget} budget.`;

      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          data: { message: prompt },
        }),
      });

      const data = await response.json();
      setSampleItinerary(data.response);
    } catch (error) {
      console.error("Error generating itinerary:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#E63946] pt-24 px-4 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 25C20 25 20 75 40 75C60 75 60 25 80 25"
            fill="none"
            stroke="white"
            strokeWidth="2"
            className="animate-wave"
          />
        </svg>
      </div>
      <div className="max-w-7xl mx-auto mb-16 relative">
        <nav className="mb-8 flex items-center text-white">
          <a href="/" className="hover:text-white/80 transition-colors">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-white/80">Travel Planning</span>
        </nav>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-white font-bold mb-6">
            Plan Your Perfect Dominican Adventure
          </h1>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            Create personalized itineraries with AI-powered recommendations
            tailored to your interests
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-8">
            <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 border border-white/20">
              <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-6">
                Key Features
              </h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <i className="fas fa-calendar-alt text-[#FF5E62] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">
                      Smart Itinerary Creation
                    </h3>
                    <p className="text-gray-600">
                      AI-powered itinerary generation based on your preferences
                      and travel style
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-clock text-[#FF5E62] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">
                      Real-Time Updates
                    </h3>
                    <p className="text-gray-600">
                      Stay informed about weather changes, event updates, and
                      scheduling modifications
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-map-marked-alt text-[#FF5E62] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">
                      Interactive Maps
                    </h3>
                    <p className="text-gray-600">
                      Visual journey planning with integrated maps and location
                      services
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-bookmark text-[#FF5E62] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">
                      Bookable Activities
                    </h3>
                    <p className="text-gray-600">
                      Direct booking integration for tours, restaurants, and
                      activities
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 border border-white/20">
              <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-6">
                How It Works
              </h2>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#FF5E62] text-white rounded-full flex items-center justify-center mr-4">
                    1
                  </div>
                  <p className="text-gray-600">
                    Share your travel preferences and interests
                  </p>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#FF5E62] text-white rounded-full flex items-center justify-center mr-4">
                    2
                  </div>
                  <p className="text-gray-600">
                    Get AI-generated personalized itinerary suggestions
                  </p>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#FF5E62] text-white rounded-full flex items-center justify-center mr-4">
                    3
                  </div>
                  <p className="text-gray-600">
                    Customize and fine-tune your perfect schedule
                  </p>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#FF5E62] text-white rounded-full flex items-center justify-center mr-4">
                    4
                  </div>
                  <p className="text-gray-600">
                    Book activities and manage your trip in real-time
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 border border-white/20">
            <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-6">
              Try Our Itinerary Generator
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-gray-800 font-bold mb-2">
                  Trip Duration
                </label>
                <select
                  value={selectedDuration}
                  onChange={(e) => setSelectedDuration(e.target.value)}
                  className="w-full p-3 rounded bg-white border border-gray-300 text-gray-800 focus:ring-2 focus:ring-[#FF5E62] focus:border-transparent"
                >
                  <option value="3">3 Days</option>
                  <option value="5">5 Days</option>
                  <option value="7">7 Days</option>
                  <option value="10">10 Days</option>
                  <option value="14">14 Days</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-800 font-bold mb-2">
                  Your Interests
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {interestOptions.map((interest) => (
                    <button
                      key={interest.id}
                      onClick={() => handleInterestToggle(interest.id)}
                      className={`flex items-center p-3 rounded-lg border transition-colors ${
                        interests.includes(interest.id)
                          ? "bg-[#FF5E62] text-white border-[#FF5E62]"
                          : "border-gray-300 text-gray-800 hover:border-[#FF5E62]"
                      }`}
                    >
                      <i className={`fas fa-${interest.icon} mr-2`}></i>
                      {interest.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-800 font-bold mb-2">
                  Budget Level
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {["budget", "medium", "luxury"].map((level) => (
                    <button
                      key={level}
                      onClick={() => setBudget(level)}
                      className={`p-3 rounded-lg border transition-colors ${
                        budget === level
                          ? "bg-[#FF5E62] text-white border-[#FF5E62]"
                          : "border-gray-300 text-gray-800 hover:border-[#FF5E62]"
                      }`}
                    >
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={generateSampleItinerary}
                disabled={isLoading || interests.length === 0}
                className="w-full bg-[#FF5E62] text-white py-3 rounded-lg hover:bg-[#ff4b4f] transition-colors disabled:opacity-50"
              >
                {isLoading ? (
                  <i className="fas fa-spinner fa-spin"></i>
                ) : (
                  "Generate Sample Itinerary"
                )}
              </button>

              {sampleItinerary && (
                <div className="mt-6">
                  <h3 className="font-bold text-gray-800 mb-2">
                    Your Personalized Itinerary:
                  </h3>
                  <div className="bg-white border border-gray-300 p-4 rounded-lg">
                    <p className="text-gray-600 whitespace-pre-line">
                      {sampleItinerary}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-6 border border-white/20">
            <div className="text-center mb-4">
              <i className="fas fa-users text-[#FF5E62] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-gray-800 mb-2">50,000+</h3>
              <p className="text-gray-600">Trips planned</p>
            </div>
          </div>
          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-6 border border-white/20">
            <div className="text-center mb-4">
              <i className="fas fa-star text-[#FF5E62] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-gray-800 mb-2">4.8/5</h3>
              <p className="text-gray-600">Average rating</p>
            </div>
          </div>
          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-6 border border-white/20">
            <div className="text-center mb-4">
              <i className="fas fa-map-marker-alt text-[#FF5E62] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-gray-800 mb-2">1,000+</h3>
              <p className="text-gray-600">Available activities</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 border border-white/20">
            <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-6">
              Travel Tips & Resources
            </h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <i className="fas fa-check-circle text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">
                  Best times to visit different regions
                </p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-check-circle text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">
                  Local customs and etiquette guides
                </p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-check-circle text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">Transportation options and tips</p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-check-circle text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">
                  Packing suggestions for your trip
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 border border-white/20">
            <h2 className="text-2xl font-crimson-text text-gray-800 font-bold mb-6">
              Premium Features
            </h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <i className="fas fa-crown text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">
                  Priority booking for popular activities
                </p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-crown text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">24/7 concierge support</p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-crown text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">Exclusive deals and discounts</p>
              </div>
              <div className="flex items-start">
                <i className="fas fa-crown text-[#FF5E62] mt-1 mr-3"></i>
                <p className="text-gray-600">Offline access to itineraries</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#A8DADC] rounded-lg shadow-lg p-8 text-center border border-white/20">
          <h2 className="text-3xl font-crimson-text text-gray-800 font-bold mb-6">
            Start Planning Your Dream Vacation
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto text-gray-600">
            Create your personalized travel itinerary in minutes with our
            AI-powered planning tool
          </p>
          <a
            href="/account/signup"
            className="bg-[#FF5E62] text-white px-8 py-3 rounded-full text-lg hover:bg-[#ff4b4f] transition-colors inline-block"
          >
            Get Started Free
          </a>
        </div>
      </div>
      <style jsx global>{`
        @keyframes wave {
          0% { transform: translateX(0); }
          100% { transform: translateX(-100px); }
        }
        .animate-wave {
          animation: wave 3s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;