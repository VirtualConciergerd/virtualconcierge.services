"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const [demoMessage, setDemoMessage] = useState("");
  const [demoResponse, setDemoResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleDemoSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch("/api/concierge-service", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          data: { message: demoMessage },
        }),
      });
      const data = await response.json();
      setDemoResponse(data.response);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-7xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6] transition-colors"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">AI Assistant</span>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-4xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Your Personal Travel AI Assistant
          </h1>
          <p className="text-xl text-[#475569] max-w-3xl mx-auto">
            Experience the future of travel planning with our AI-powered virtual
            concierge
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                Key Features
              </h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <i className="fas fa-brain text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Smart Recommendations
                    </h3>
                    <p className="text-[#475569]">
                      Get personalized suggestions based on your preferences and
                      travel style
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-clock text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      24/7 Availability
                    </h3>
                    <p className="text-[#475569]">
                      Access instant assistance anytime, anywhere
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-language text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Multilingual Support
                    </h3>
                    <p className="text-[#475569]">
                      Communicate in your preferred language with real-time
                      translation
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="fas fa-route text-[#3b82f6] text-2xl mt-1 mr-4"></i>
                  <div>
                    <h3 className="font-bold text-[#1e293b] mb-2">
                      Itinerary Planning
                    </h3>
                    <p className="text-[#475569]">
                      Create custom travel plans tailored to your interests and
                      schedule
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
                How It Works
              </h2>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#3b82f6] text-white rounded-full flex items-center justify-center mr-4">
                    1
                  </div>
                  <p className="text-[#475569]">
                    Ask any question about your Dominican Republic trip
                  </p>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#3b82f6] text-white rounded-full flex items-center justify-center mr-4">
                    2
                  </div>
                  <p className="text-[#475569]">
                    Get instant, accurate responses based on real-time data
                  </p>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-[#3b82f6] text-white rounded-full flex items-center justify-center mr-4">
                    3
                  </div>
                  <p className="text-[#475569]">
                    Receive personalized recommendations and booking options
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-crimson-text text-[#1e293b] font-bold mb-6">
              Try It Now
            </h2>
            <div className="space-y-6">
              <form onSubmit={handleDemoSubmit} className="space-y-4">
                <div>
                  <label
                    className="block text-[#1e293b] font-bold mb-2"
                    htmlFor="demo-message"
                  >
                    Ask anything about Dominican Republic
                  </label>
                  <input
                    type="text"
                    id="demo-message"
                    name="demo-message"
                    value={demoMessage}
                    onChange={(e) => setDemoMessage(e.target.value)}
                    placeholder="e.g., What are the best beaches in Punta Cana?"
                    className="w-full p-3 border rounded focus:ring-2 focus:ring-[#3b82f6] focus:border-transparent"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-[#3b82f6] text-white py-3 rounded-lg hover:bg-[#2563eb] transition-colors disabled:opacity-50"
                >
                  {isLoading ? (
                    <i className="fas fa-spinner fa-spin"></i>
                  ) : (
                    "Get Answer"
                  )}
                </button>
              </form>
              {demoResponse && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-bold text-[#1e293b] mb-2">Response:</h3>
                  <p className="text-[#475569]">{demoResponse}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-star text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">4.9/5 Rating</h3>
              <p className="text-[#475569]">Average user satisfaction score</p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-users text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">100,000+</h3>
              <p className="text-[#475569]">Questions answered monthly</p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-center mb-4">
              <i className="fas fa-globe text-[#3b82f6] text-3xl"></i>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-[#1e293b] mb-2">10+ Languages</h3>
              <p className="text-[#475569]">Supported languages</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] text-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-3xl font-crimson-text font-bold mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Experience the power of AI-assisted travel planning today
          </p>
          <a
            href="/account/signup"
            className="bg-white text-[#1e293b] px-8 py-3 rounded-full text-lg hover:bg-gray-100 transition-colors inline-block"
          >
            Get Started Free
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;