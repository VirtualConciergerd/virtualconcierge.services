"use client";
import React from "react";

function MainComponent() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] pt-24 px-4">
      <div className="max-w-4xl mx-auto mb-16">
        <nav className="mb-8 flex items-center text-[#475569]">
          <button
            onClick={() => navigate("/")}
            className="hover:text-[#3b82f6] transition-colors"
          >
            Home
          </button>
          <span className="mx-2">/</span>
          <span className="text-[#1e293b]">Return & Refund Policy</span>
        </nav>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-crimson-text text-[#1e293b] font-bold mb-6">
            Return & Refund Policy
          </h1>
          <p className="text-[#475569] mb-4">
            Last Updated: {new Date().toLocaleDateString()}
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                1. Return Period
              </h2>
              <p className="text-[#475569] mb-4">
                We accept returns within 30 days of purchase for most items.
                Items must be unused and in their original packaging.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                2. Refund Process
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Initiate return through your account dashboard</li>
                <li>Print return shipping label</li>
                <li>Package item securely with original packaging</li>
                <li>Drop off at authorized shipping location</li>
                <li>Refund processed within 5-7 business days after receipt</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                3. Non-Returnable Items
              </h2>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Personalized or custom-made items</li>
                <li>Digital products</li>
                <li>Gift cards</li>
                <li>Perishable goods</li>
                <li>Items marked as final sale</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                4. Return Shipping
              </h2>
              <p className="text-[#475569] mb-4">Return shipping costs:</p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Free for defective items</li>
                <li>Customer pays return shipping for non-defective items</li>
                <li>Free returns for Premium members</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-crimson-text text-[#1e293b] font-bold mb-4">
                5. Damaged or Defective Items
              </h2>
              <p className="text-[#475569] mb-4">
                For damaged or defective items:
              </p>
              <ul className="list-disc pl-6 text-[#475569] space-y-2">
                <li>Contact customer service within 48 hours of receipt</li>
                <li>Provide photos of damage</li>
                <li>Receive prepaid return label</li>
                <li>Full refund or replacement offered</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;