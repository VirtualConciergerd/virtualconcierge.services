"use client";
import React from "react";

function MainComponent() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      image:
        "https://ucarecdn.com/8462a4df-485d-4753-b9b0-337c25e26fae/-/format/auto/",
      title: "Bahía de las Águilas",
      description:
        "Experience one of the Caribbean's most pristine beaches with crystal-clear turquoise waters",
    },
    {
      image:
        "https://ucarecdn.com/e8024184-bb47-41b7-b088-36ab39c18a9d/-/format/auto/",
      title: "Pristine Paradise",
      description:
        "8 kilometers of untouched white sand beach in the Jaragua National Park",
    },
    {
      image:
        "https://ucarecdn.com/66b57df7-88b7-47c3-89f2-9df5b8803e6e/-/format/auto/",
      title: "Adventure Tours",
      description:
        "Guided excursions to this remote paradise in Dominican Republic's southwest",
    },
    {
      image: "https://ucarecdn.com/3ec4320a-3d69-4366-9e7d-98da2b9ed3a3/",
      title: "Sunset Experience",
      description: "Watch breathtaking sunsets over the Caribbean Sea",
    },
    {
      image:
        "https://ucarecdn.com/ade48f14-cc75-4886-80c6-324633285031/-/format/auto/",
      title: "Natural Reserve",
      description: "Explore the protected wildlife and pristine ecosystem",
    },
  ];

  useEffect(() => {
    try {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      }, 5000);
      return () => clearInterval(timer);
    } catch (err) {
      setError("Failed to initialize slideshow");
      console.error(err);
    }
  }, [slides.length]);

  useEffect(() => {
    const loadPage = async () => {
      try {
        setLoading(true);
        await new Promise((resolve) => setTimeout(resolve, 1000));
        setLoading(false);
      } catch (err) {
        setError("Failed to load page content");
        console.error(err);
      }
    };
    loadPage();
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl text-[#4F5D75]">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl text-red-500">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFFFC]">
      <nav className="fixed w-full bg-[#4F5D75] backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-2xl font-crimson-text text-white font-bold">
            Virtual Concierge
          </div>
          <div className="flex gap-4 items-center">
            <a
              href="/about"
              className="text-white hover:text-[#00BFFF] transition-colors interactive"
            >
              About Us
            </a>
            <a
              href="/contact"
              className="text-white hover:text-[#00BFFF] transition-colors interactive"
            >
              Contact
            </a>
            {!user ? (
              <a
                href="/account/signin?callbackUrl=/virtual-concierge"
                className="bg-[#00BFFF] text-white px-6 py-2 rounded-full hover:bg-[#FFD700] transition-all interactive"
              >
                Get Started
              </a>
            ) : (
              <a
                href="/virtual-concierge"
                className="bg-[#00BFFF] text-white px-6 py-2 rounded-full hover:bg-[#FFD700] transition-all interactive"
              >
                Dashboard
              </a>
            )}
          </div>
        </div>
      </nav>

      <main className="px-4 md:px-6 lg:px-8">
        <section className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-crimson-text text-[#4F5D75] font-bold mb-6">
              Discover Bahía de las Águilas
            </h1>
            <p className="text-xl text-[#4F5D75] mb-12 max-w-2xl mx-auto">
              Embark on a journey to one of the Caribbean's last untouched
              paradises - where pristine white sands meet crystal-clear
              turquoise waters in the heart of the Dominican Republic.
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <a
                href={
                  user
                    ? "/virtual-concierge"
                    : "/account/signin?callbackUrl=/virtual-concierge"
                }
                className="bg-[#4F5D75] text-white px-8 py-3 rounded-full text-lg hover:bg-[#00BFFF] transition-all interactive"
              >
                Start Planning
              </a>
              <a
                href="/explore"
                className="bg-[#4F5D75] text-white px-8 py-3 rounded-full text-lg border-2 border-[#00BFFF] hover:bg-[#00BFFF] transition-all interactive"
              >
                Explore Features
              </a>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-crimson-text text-center text-[#4F5D75] font-bold mb-16">
              How It Works
            </h2>
            <div className="grid md:grid-cols-4 gap-8">
              {[
                {
                  number: 1,
                  title: "Sign Up",
                  desc: "Create your account in seconds",
                },
                {
                  number: 2,
                  title: "Set Preferences",
                  desc: "Tell us what you like",
                },
                {
                  number: 3,
                  title: "Ask Questions",
                  desc: "Get instant assistance",
                },
                {
                  number: 4,
                  title: "Explore",
                  desc: "Discover amazing places",
                },
              ].map((step) => (
                <div
                  key={step.number}
                  className="text-center bg-[#4F5D75] p-6 rounded-lg interactive"
                >
                  <div className="w-12 h-12 bg-[#00BFFF] rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">
                    {step.number}
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">
                    {step.title}
                  </h3>
                  <p className="text-white/80">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 px-4 bg-[#34312D] text-white text-center">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-crimson-text font-bold mb-6">
              Ready to Start Your Journey?
            </h2>
            <p className="text-xl mb-8">
              Join thousands of travelers using Virtual Concierge
            </p>
            <a
              href="/virtual-concierge"
              className="bg-[#00BFFF] text-white px-8 py-3 rounded-full text-lg hover:bg-[#FFD700] transition-all glow-effect"
            >
              Get Started Now
            </a>
          </div>
        </section>

        <section className="py-20 px-4 bg-[#34312D]">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-crimson-text text-center text-white font-bold mb-8">
              About Bahía de las Águilas
            </h2>
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-lg text-white/80 mb-6">
                Welcome to Bahía de las Águilas, a hidden gem in the Dominican
                Republic's southwest region. This pristine 8-kilometer stretch
                of white sand beach remains one of the Caribbean's most
                unspoiled natural treasures, protected within Jaragua National
                Park.
              </p>
              <p className="text-lg text-white/80">
                Whether you're seeking pristine beaches, rich marine life, or
                untouched natural beauty, Bahía de las Águilas offers an
                unforgettable experience in one of the Caribbean's last
                paradises.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#4F5D75] py-12 px-4 md:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-crimson-text text-xl font-bold text-white mb-4">
                Virtual Concierge
              </h3>
              <p className="text-white/80">Your AI-powered travel companion</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Features</h4>
              <ul className="space-y-2 text-white/80">
                <li className="interactive">AI Assistant</li>
                <li className="interactive">Translation Services</li>
                <li className="interactive">Local Recommendations</li>
                <li className="interactive">Travel Planning</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-white/80">
                <li className="interactive">About Us</li>
                <li className="interactive">Contact</li>
                <li className="interactive">Privacy Policy</li>
                <li className="interactive">Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Connect</h4>
              <div className="flex space-x-4">
                <i className="fab fa-twitter text-white text-xl interactive"></i>
                <i className="fab fa-facebook text-white text-xl interactive"></i>
                <i className="fab fa-instagram text-white text-xl interactive"></i>
                <i className="fab fa-linkedin text-white text-xl interactive"></i>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-white/20 text-center text-white/80">
            <p>&copy; 2025 Virtual Concierge. All rights reserved.</p>
          </div>
        </div>
      </footer>
      <style jsx global>{`
        .interactive {
          transition: all 0.3s ease;
        }
        .interactive:hover {
          box-shadow: 0 0 15px rgba(79, 93, 117, 0.3);
          transform: translateY(-2px);
        }
        .glow-effect {
          box-shadow: 0 0 15px rgba(79, 93, 117, 0.3);
          transition: all 0.3s ease;
        }
        .glow-effect:hover {
          box-shadow: 0 0 25px rgba(79, 93, 117, 0.5);
        }
      `}</style>
    </div>
  );
}

export default MainComponent;