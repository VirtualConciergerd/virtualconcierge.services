async function handler({ method, body }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  if (method !== "POST") {
    return { status: 405, body: { error: "Method not allowed" } };
  }

  const { eventType, message } = body;

  if (!eventType || !message) {
    return { status: 400, body: { error: "Missing required fields" } };
  }

  try {
    // Get relevant emergency contacts based on event type
    const contacts = await sql`
      SELECT * FROM emergency_contacts 
      WHERE user_id = ${session.user.id} 
      AND CASE 
        WHEN ${eventType} = 'login_attempt' THEN notify_on_login_attempts
        WHEN ${eventType} = 'password_change' THEN notify_on_password_changes
        WHEN ${eventType} = 'security_event' THEN notify_on_security_events
        ELSE false
      END
    `;

    const notificationResults = await sql.transaction(async (sql) => {
      const results = [];

      for (const contact of contacts) {
        // Record notification attempt
        const notification = await sql`
          INSERT INTO emergency_contact_notifications 
          (contact_id, event_type, message, status)
          VALUES (${contact.id}, ${eventType}, ${message}, 'pending')
          RETURNING id
        `;

        // Update last notified timestamp
        await sql`
          UPDATE emergency_contacts 
          SET last_notified = CURRENT_TIMESTAMP 
          WHERE id = ${contact.id}
        `;

        if (contact.email) {
          await fetch("/api/send-email", {
            method: "POST",
            body: JSON.stringify({
              to: contact.email,
              subject: `Security Alert for ${session.user.email}`,
              text: message,
            }),
          });
        }

        if (contact.phone) {
          await fetch("/api/send-sms", {
            method: "POST",
            body: JSON.stringify({
              to: contact.phone,
              message: message,
            }),
          });
        }

        results.push(notification[0]);
      }

      return results;
    });

    return {
      status: 200,
      body: {
        success: true,
        notificationsSent: notificationResults.length,
      },
    };
  } catch (error) {
    console.error("Error notifying emergency contacts:", error);
    return {
      status: 500,
      body: { error: "Failed to notify emergency contacts" },
    };
  }
}