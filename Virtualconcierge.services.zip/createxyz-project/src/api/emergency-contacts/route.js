async function handler({ method, body, query }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  if (method === "GET") {
    try {
      const contacts = await sql`
        SELECT * FROM emergency_contacts 
        WHERE user_id = ${session.user.id} 
        ORDER BY is_primary DESC, created_at ASC
      `;
      return { status: 200, body: contacts };
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
      return {
        status: 500,
        body: { error: "Failed to fetch emergency contacts" },
      };
    }
  }

  if (method === "POST") {
    const { name, relationship, phone, email, notificationPreferences } = body;

    if (!name || !relationship || !phone) {
      return { status: 400, body: { error: "Missing required fields" } };
    }

    try {
      const existingContacts = await sql`
        SELECT COUNT(*) FROM emergency_contacts WHERE user_id = ${session.user.id}
      `;
      const isPrimary = parseInt(existingContacts[0].count) === 0;

      const result = await sql`
        INSERT INTO emergency_contacts (
          user_id, name, relationship, phone, email, is_primary,
          notify_on_login_attempts, notify_on_password_changes, notify_on_security_events
        ) VALUES (
          ${session.user.id}, ${name}, ${relationship}, ${phone}, ${email}, ${isPrimary},
          ${notificationPreferences.loginAttempts},
          ${notificationPreferences.passwordChanges},
          ${notificationPreferences.securityEvents}
        ) RETURNING *
      `;

      return { status: 201, body: result[0] };
    } catch (error) {
      console.error("Error creating emergency contact:", error);
      return {
        status: 500,
        body: { error: "Failed to create emergency contact" },
      };
    }
  }

  if (method === "PUT") {
    const { id, name, relationship, phone, email, notificationPreferences } =
      body;

    try {
      const result = await sql`
        UPDATE emergency_contacts 
        SET name = ${name},
            relationship = ${relationship},
            phone = ${phone},
            email = ${email},
            notify_on_login_attempts = ${notificationPreferences.loginAttempts},
            notify_on_password_changes = ${notificationPreferences.passwordChanges},
            notify_on_security_events = ${notificationPreferences.securityEvents}
        WHERE id = ${id} AND user_id = ${session.user.id}
        RETURNING *
      `;

      if (!result.length) {
        return { status: 404, body: { error: "Contact not found" } };
      }

      return { status: 200, body: result[0] };
    } catch (error) {
      console.error("Error updating emergency contact:", error);
      return {
        status: 500,
        body: { error: "Failed to update emergency contact" },
      };
    }
  }

  if (method === "DELETE") {
    const { id } = query;

    try {
      const result = await sql`
        DELETE FROM emergency_contacts 
        WHERE id = ${id} AND user_id = ${session.user.id}
        RETURNING *
      `;

      if (!result.length) {
        return { status: 404, body: { error: "Contact not found" } };
      }

      return { status: 200, body: { message: "Contact deleted successfully" } };
    } catch (error) {
      console.error("Error deleting emergency contact:", error);
      return {
        status: 500,
        body: { error: "Failed to delete emergency contact" },
      };
    }
  }

  return { status: 405, body: { error: "Method not allowed" } };
}