async function handler() {
  const now = new Date();
  const hourAgo = new Date(now.getTime() - 3600000);
  const dayAgo = new Date(now.getTime() - 86400000);

  try {
    const [queueStats, processingTimes, errorRates, currentLoad] =
      await sql.transaction([
        sql`
        SELECT 
          COUNT(*) as queue_length,
          COUNT(*) FILTER (WHERE status = 'pending') as pending,
          COUNT(*) FILTER (WHERE status = 'processing') as processing
        FROM enhanced_images 
        WHERE created_at > $1
      `,
        [hourAgo],

        sql`
        SELECT 
          AVG(EXTRACT(EPOCH FROM (updated_at - created_at))) as avg_processing_time,
          MAX(EXTRACT(EPOCH FROM (updated_at - created_at))) as max_processing_time
        FROM enhanced_images 
        WHERE status = 'completed' 
        AND created_at > $1
      `,
        [hourAgo],

        sql`
        SELECT 
          COUNT(*) FILTER (WHERE status = 'failed') * 100.0 / COUNT(*) as error_rate,
          COUNT(*) FILTER (WHERE status = 'failed') as total_errors
        FROM enhanced_images 
        WHERE created_at > $1
      `,
        [dayAgo],

        sql`
        SELECT 
          COUNT(*) as total_jobs,
          COUNT(*) FILTER (WHERE processing_attempts > 2) as retry_count
        FROM enhanced_images 
        WHERE created_at > $1
      `,
        [hourAgo],
      ]);

    const metrics = {
      timestamp: now.toISOString(),
      queue: {
        total: parseInt(queueStats[0].queue_length),
        pending: parseInt(queueStats[0].pending),
        processing: parseInt(queueStats[0].processing),
      },
      performance: {
        avgProcessingTime: processingTimes[0].avg_processing_time
          ? parseFloat(processingTimes[0].avg_processing_time).toFixed(2)
          : 0,
        maxProcessingTime: processingTimes[0].max_processing_time
          ? parseFloat(processingTimes[0].max_processing_time).toFixed(2)
          : 0,
        retryCount: parseInt(currentLoad[0].retry_count),
      },
      errors: {
        rate: parseFloat(errorRates[0].error_rate).toFixed(2),
        count: parseInt(errorRates[0].total_errors),
      },
      alerts: [],
    };

    // Alert thresholds
    if (metrics.queue.pending > 100) {
      metrics.alerts.push({
        level: "warning",
        message: "Queue length exceeds 100 pending items",
        metric: "queue_length",
        value: metrics.queue.pending,
      });
    }

    if (parseFloat(metrics.errors.rate) > 10) {
      metrics.alerts.push({
        level: "critical",
        message: "Error rate exceeds 10%",
        metric: "error_rate",
        value: metrics.errors.rate,
      });
    }

    if (parseFloat(metrics.performance.avgProcessingTime) > 300) {
      metrics.alerts.push({
        level: "warning",
        message: "Average processing time exceeds 5 minutes",
        metric: "processing_time",
        value: metrics.performance.avgProcessingTime,
      });
    }

    if (metrics.performance.retryCount > 50) {
      metrics.alerts.push({
        level: "critical",
        message: "High number of retry attempts",
        metric: "retry_count",
        value: metrics.performance.retryCount,
      });
    }

    if (metrics.queue.processing > 50) {
      metrics.alerts.push({
        level: "warning",
        message: "High number of concurrent processing jobs",
        metric: "processing_count",
        value: metrics.queue.processing,
      });
    }

    // Health status
    metrics.status =
      metrics.alerts.length === 0
        ? "healthy"
        : metrics.alerts.some((a) => a.level === "critical")
        ? "critical"
        : "degraded";

    // Log alerts and status to admin_audit_log
    if (metrics.alerts.length > 0 || metrics.status !== "healthy") {
      await sql`
        INSERT INTO admin_audit_log 
        (action, entity_type, changes)
        VALUES 
        ('queue_monitor', 'system_health', ${JSON.stringify({
          status: metrics.status,
          alerts: metrics.alerts,
          metrics: {
            queue: metrics.queue,
            performance: metrics.performance,
            errors: metrics.errors,
          },
        })})
      `;
    }

    return metrics;
  } catch (error) {
    const errorData = {
      status: "error",
      timestamp: now.toISOString(),
      error: error.message,
    };

    await sql`
      INSERT INTO admin_audit_log 
      (action, entity_type, changes)
      VALUES 
      ('queue_monitor', 'system_error', ${JSON.stringify(errorData)})
    `;

    return errorData;
  }
}