async function handler({ sessionId }) {
  const session = getSession();
  if (!session) {
    return { error: "Authentication required" };
  }

  if (!sessionId) {
    return { error: "Session ID is required" };
  }

  try {
    const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
    const stripeSession = await stripe.checkout.sessions.retrieve(sessionId);

    if (stripeSession.payment_status === "paid") {
      const orders = await sql`
        UPDATE orders 
        SET status = 'paid' 
        WHERE stripe_session_id = ${sessionId} 
        AND user_id = ${session.user.id}
        RETURNING id, email
      `;

      if (orders.length === 0) {
        return { error: "Order not found" };
      }

      await fetch("/api/send-order-confirmation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: orders[0].id,
          email: orders[0].email,
        }),
      });

      return {
        success: true,
        orderId: orders[0].id,
      };
    }

    return { error: "Payment not completed" };
  } catch (error) {
    console.error("Confirmation error:", error);
    return { error: "Failed to confirm order" };
  }
}