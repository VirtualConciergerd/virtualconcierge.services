async function handler({ serviceId }) {
  if (!serviceId) {
    throw new Error("Service ID is required");
  }

  try {
    const reviews = await sql`
      SELECT 
        sr.*,
        au.name as user_name
      FROM service_reviews sr
      JOIN auth_users au ON sr.user_id = au.id
      WHERE sr.service_id = ${serviceId}
      ORDER BY sr.created_at DESC
    `;

    return reviews;
  } catch (error) {
    throw new Error("Failed to fetch reviews");
  }
}