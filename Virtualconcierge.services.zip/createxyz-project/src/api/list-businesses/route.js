async function handler({ page = 1, limit = 10, status = null }) {
  try {
    // Input validation
    if (typeof page !== "number" || page < 1) {
      return { error: "Invalid page number" };
    }

    if (typeof limit !== "number" || limit < 1 || limit > 100) {
      return { error: "Invalid limit value" };
    }

    if (status && !["pending", "approved", "rejected"].includes(status)) {
      return { error: "Invalid status value" };
    }

    const offset = (page - 1) * limit;
    let whereClause = "1=1";
    const queryParams = [];
    let paramCount = 1;

    if (status) {
      whereClause = "b.status = $1";
      queryParams.push(status);
    }

    // Execute queries inside transaction to ensure consistency
    const [totalResult, businesses] = await sql.transaction([
      sql(
        `SELECT COUNT(*) FROM businesses b WHERE ${whereClause}`,
        queryParams
      ),

      sql(
        `SELECT 
        b.*,
        c.name as country_name,
        r.name as region_name
      FROM businesses b
      LEFT JOIN countries c ON b.country_id = c.id
      LEFT JOIN regions r ON b.region_id = r.id
      WHERE ${whereClause}
      ORDER BY b.created_at DESC
      LIMIT $${paramCount + 1} 
      OFFSET $${paramCount + 2}`,
        [...queryParams, limit, offset]
      ),
    ]);

    const totalCount = parseInt(totalResult[0].count);
    const totalPages = Math.ceil(totalCount / limit);

    if (page > totalPages && totalCount > 0) {
      return { error: "Page number exceeds total pages" };
    }

    return {
      businesses,
      total: totalCount,
      page,
      limit,
      totalPages,
      hasMore: page < totalPages,
    };
  } catch (error) {
    console.error("Error in list-businesses:", error);
    return {
      error: "Failed to fetch businesses",
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    };
  }
}