async function handler({ action, data }) {
  if (action !== "create-payment-intent") {
    return { error: "Invalid action" };
  }

  const { amount, description } = data;

  if (!amount || amount <= 0) {
    return { error: "Invalid amount" };
  }

  try {
    const response = await fetch("https://api.stripe.com/v2/payment_intents", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        amount: Math.round(amount * 100),
        currency: "usd",
        description,
        automatic_payment_methods: {
          enabled: true,
        },
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to create payment intent");
    }

    const paymentIntent = await response.json();

    await sql`
      INSERT INTO payment_intents (
        stripe_payment_intent_id,
        amount,
        description,
        status,
        created_at
      ) VALUES (
        ${paymentIntent.id},
        ${amount},
        ${description},
        ${paymentIntent.status},
        NOW()
      )
    `;

    return {
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error) {
    console.error("Payment processing error:", error);
    return {
      error: "Payment processing failed. Please try again.",
    };
  }
}