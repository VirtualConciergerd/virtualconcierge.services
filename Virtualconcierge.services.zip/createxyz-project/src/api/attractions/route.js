async function handler({ action, data }) {
  switch (action) {
    case "listProvinces":
      const provinces = await sql`
        SELECT * FROM provinces 
        ORDER BY name ASC`;
      return provinces;

    case "getProvinceAttractions":
      const { provinceId } = data;
      const attractions = await sql`
        SELECT a.*, p.name as province_name 
        FROM attractions a
        JOIN provinces p ON a.province_id = p.id
        WHERE p.id = ${provinceId}
        ORDER BY a.name ASC`;
      return attractions;

    case "searchAttractions":
      const { query } = data;
      const searchResults = await sql`
        SELECT a.*, p.name as province_name 
        FROM attractions a
        JOIN provinces p ON a.province_id = p.id
        WHERE 
          a.name ILIKE ${`%${query}%`} OR 
          a.description ILIKE ${`%${query}%`} OR
          p.name ILIKE ${`%${query}%`}
        ORDER BY p.name ASC, a.name ASC`;
      return searchResults;

    default:
      return null;
  }
}