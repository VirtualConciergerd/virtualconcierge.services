async function handler({ serviceId, rating, reviewText }) {
  const session = getSession();
  if (!session?.user) {
    throw new Error("Authentication required");
  }

  if (!serviceId || !rating || rating < 1 || rating > 5) {
    throw new Error("Invalid review data");
  }

  try {
    const review = await sql`
      INSERT INTO service_reviews 
        (service_id, user_id, rating, review_text)
      VALUES 
        (${serviceId}, ${session.user.id}, ${rating}, ${reviewText})
      RETURNING *`;

    return review[0];
  } catch (error) {
    throw new Error("Failed to create review");
  }
}