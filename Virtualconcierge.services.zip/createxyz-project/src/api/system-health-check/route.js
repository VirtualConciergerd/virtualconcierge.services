async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const stripeTest = await fetch(
      "https://api.stripe.com/v1/payment_methods?limit=1",
      {
        headers: {
          Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        },
      }
    );

    const [
      dbCheck,
      recentRegistrations,
      pendingVerifications,
      dbStats,
      businessStats,
      systemBackups,
    ] = await sql.transaction([
      sql`SELECT 1`,
      sql`
        SELECT COUNT(*) 
        FROM businesses 
        WHERE created_at > NOW() - INTERVAL '24 hours'
      `,
      sql`
        SELECT COUNT(*) 
        FROM businesses 
        WHERE status = 'pending'
      `,
      sql`
        SELECT 
          (SELECT COUNT(*) FROM businesses) as total_businesses,
          (SELECT COUNT(*) FROM countries) as total_countries,
          (SELECT COUNT(*) FROM regions) as total_regions
      `,
      sql`
        SELECT 
          COUNT(*) FILTER (WHERE status = 'verified') as verified_businesses,
          COUNT(*) FILTER (WHERE status = 'pending') as pending_businesses,
          COUNT(*) FILTER (WHERE status = 'rejected') as rejected_businesses
        FROM businesses
      `,
      sql`
        SELECT status, COUNT(*) 
        FROM system_backups 
        WHERE backup_date > NOW() - INTERVAL '24 hours' 
        GROUP BY status
      `,
    ]);

    const requiredEnvVars = [
      "DATABASE_URL",
      "GOOGLE_TRANSLATE_API_KEY",
      "WEATHER_API_KEY",
      "STRIPE_SECRET_KEY",
      "STRIPE_WEBHOOK_SECRET",
      "NEXTAUTH_SECRET",
      "NEXTAUTH_URL",
    ];

    const missingEnvVars = requiredEnvVars.filter((env) => !process.env[env]);

    return {
      success: true,
      status: {
        services: {
          database: dbCheck.length > 0 ? "healthy" : "error",
          stripe: stripeTest.ok ? "healthy" : "error",
          backups: systemBackups.length > 0 ? "active" : "inactive",
        },
        environment:
          missingEnvVars.length === 0
            ? "complete"
            : `missing: ${missingEnvVars.join(", ")}`,
        last24hRegistrations: Number(recentRegistrations[0].count),
        pendingVerifications: Number(pendingVerifications[0].count),
        timestamp: new Date().toISOString(),
        stats: {
          businesses: Number(dbStats[0].total_businesses),
          countries: Number(dbStats[0].total_countries),
          regions: Number(dbStats[0].total_regions),
          businessStatus: {
            verified: Number(businessStats[0].verified_businesses),
            pending: Number(businessStats[0].pending_businesses),
            rejected: Number(businessStats[0].rejected_businesses),
          },
          backups: systemBackups.reduce((acc, row) => {
            acc[row.status] = Number(row.count);
            return acc;
          }, {}),
        },
      },
    };
  } catch (error) {
    console.error("Health check error:", error);
    return {
      error: "Health check failed",
      timestamp: new Date().toISOString(),
    };
  }
}