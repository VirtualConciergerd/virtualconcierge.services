const crypto = require("crypto");

const IV_LENGTH = 16;

async function handler({ action, guideId, token }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "prepareDownload": {
      const access = await sql`
        SELECT * FROM user_purchases 
        WHERE user_id = ${session.user.id} 
        AND guide_id = ${guideId}
        UNION
        SELECT p.* FROM user_subscriptions s
        JOIN subscription_plans p ON s.plan_id = p.id
        WHERE s.user_id = ${session.user.id}
        AND p.features->>'offline_access' = 'true'
        AND s.status = 'active'
      `;

      if (access.length === 0) {
        return { error: "No offline access" };
      }

      const iv = crypto.randomBytes(IV_LENGTH);
      const encryptionKey = crypto.randomBytes(32);

      await sql`
        INSERT INTO offline_content (
          user_id,
          guide_id, 
          encryption_key,
          last_synced
        ) VALUES (
          ${session.user.id},
          ${guideId},
          ${encryptionKey.toString("hex")},
          NOW()
        )
      `;

      return {
        downloadToken: encryptionKey.toString("hex"),
        iv: iv.toString("hex"),
      };
    }

    case "downloadContent": {
      const download = await sql`
        SELECT * FROM offline_content
        WHERE user_id = ${session.user.id}
        AND guide_id = ${guideId}
        AND encryption_key = ${token}
      `;

      if (download.length === 0) {
        return { error: "Invalid download token" };
      }

      const guide = await sql`
        SELECT * FROM premium_guides
        WHERE id = ${guideId}
      `;

      const content = {
        guide: guide[0],
        timestamp: new Date().toISOString(),
        expiresAt: new Date(
          Date.now() + 30 * 24 * 60 * 60 * 1000
        ).toISOString(),
      };

      const iv = crypto.randomBytes(IV_LENGTH);
      const cipher = crypto.createCipheriv(
        "aes-256-gcm",
        Buffer.from(token, "hex"),
        iv
      );

      let encrypted = cipher.update(JSON.stringify(content), "utf8", "hex");
      encrypted += cipher.final("hex");

      const authTag = cipher.getAuthTag();

      return {
        data: JSON.stringify({
          iv: iv.toString("hex"),
          content: encrypted,
          authTag: authTag.toString("hex"),
        }),
        metadata: {
          size: Buffer.byteLength(encrypted, "utf8"),
          expiresAt: content.expiresAt,
        },
      };
    }

    default:
      return { error: "Invalid action" };
  }
}