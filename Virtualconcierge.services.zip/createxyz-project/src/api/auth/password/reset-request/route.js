async function handler({ email }) {
  if (!email || !email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i)) {
    return { error: "Invalid email address" };
  }

  const users = await sql`
    SELECT id, email 
    FROM auth_users 
    WHERE email = ${email}
  `;

  if (!users[0]) {
    // Don't reveal if email exists or not
    return { success: true };
  }

  const token = Buffer.from(crypto.randomBytes(32)).toString("hex");
  const expires = new Date(Date.now() + 3600000); // 1 hour

  await sql`
    INSERT INTO auth_verification_token 
    (identifier, token, expires) 
    VALUES (${email}, ${token}, ${expires})
  `;

  const resetLink = `${
    process.env.NEXT_PUBLIC_APP_URL
  }/account/reset-password?token=${token}&email=${encodeURIComponent(email)}`;

  // Send email with reset link
  await fetch("https://api.resend.com/v1/email/send", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "noreply@yourdomain.com",
      to: email,
      subject: "Password Reset Request",
      html: `Click this link to reset your password: <a href="${resetLink}">${resetLink}</a>`,
    }),
  });

  return { success: true };
}