async function handler({ token, email, newPassword }) {
  if (!token || !email || !newPassword) {
    return { error: "Missing required fields" };
  }

  try {
    // Check token validity
    const tokens = await sql`
      SELECT * FROM auth_verification_token 
      WHERE identifier = ${email} 
      AND token = ${token} 
      AND expires > NOW()
    `;

    if (!tokens[0]) {
      return { error: "Invalid or expired reset token" };
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password and delete token in a transaction
    await sql.transaction([
      sql`
        UPDATE auth_accounts 
        SET password = ${hashedPassword} 
        WHERE "userId" IN (
          SELECT id FROM auth_users WHERE email = ${email}
        )
      `,
      sql`
        DELETE FROM auth_verification_token 
        WHERE identifier = ${email} 
        AND token = ${token}
      `,
    ]);

    return { success: true };
  } catch (error) {
    return { error: "Failed to reset password" };
  }
}