async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Not authenticated" };
  }

  const token = Buffer.from(crypto.randomBytes(32)).toString("hex");
  const expires = new Date(Date.now() + 24 * 3600000); // 24 hours

  try {
    await sql`
      INSERT INTO auth_verification_token 
      (identifier, token, expires) 
      VALUES (${session.user.email}, ${token}, ${expires})
    `;

    const verifyLink = `${
      process.env.NEXT_PUBLIC_APP_URL
    }/account/verify-email?token=${token}&email=${encodeURIComponent(
      session.user.email
    )}`;

    await fetch("https://api.resend.com/v1/email/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "noreply@yourdomain.com",
        to: session.user.email,
        subject: "Verify Your Email Address",
        html: `Click this link to verify your email: <a href="${verifyLink}">${verifyLink}</a>`,
      }),
    });

    return { success: true };
  } catch (error) {
    return { error: "Failed to send verification email" };
  }
}