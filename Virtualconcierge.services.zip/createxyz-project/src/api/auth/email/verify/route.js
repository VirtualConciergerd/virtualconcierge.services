async function handler({ token, email }) {
  if (!token || !email) {
    return { error: "Missing required fields" };
  }

  try {
    const result = await sql.transaction([
      // Check token validity
      sql`
        SELECT * FROM auth_verification_token 
        WHERE identifier = ${email} 
        AND token = ${token} 
        AND expires > NOW()
      `,
      // Update user verification status
      sql`
        UPDATE auth_users 
        SET email_verified = true 
        WHERE email = ${email}
      `,
      // Delete used token
      sql`
        DELETE FROM auth_verification_token 
        WHERE identifier = ${email} 
        AND token = ${token}
      `,
    ]);

    if (!result[0][0]) {
      return { error: "Invalid or expired verification token" };
    }

    return { success: true };
  } catch (error) {
    return { error: "Failed to verify email" };
  }
}