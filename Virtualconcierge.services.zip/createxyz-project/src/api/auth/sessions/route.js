async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized", status: 401 };
  }

  try {
    const activeSessions = await sql`
      SELECT id, device_info, last_active, ip_address, created_at 
      FROM active_sessions 
      WHERE user_id = ${session.user.id} 
      AND is_revoked = false
    `;

    return { sessions: activeSessions, status: 200 };
  } catch (error) {
    console.error("Error fetching sessions:", error);
    return { error: "Failed to fetch sessions", status: 500 };
  }
}