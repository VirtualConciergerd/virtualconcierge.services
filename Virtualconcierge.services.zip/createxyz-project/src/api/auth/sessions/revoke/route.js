async function handler({ sessionId }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized", status: 401 };
  }

  if (!sessionId) {
    return { error: "Session ID is required", status: 400 };
  }

  try {
    await sql`
      UPDATE active_sessions 
      SET is_revoked = true 
      WHERE id = ${sessionId} 
      AND user_id = ${session.user.id}
    `;

    return { message: "Session revoked successfully", status: 200 };
  } catch (error) {
    console.error("Error revoking session:", error);
    return { error: "Failed to revoke session", status: 500 };
  }
}