async function handler({ token, backupCode }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized", status: 401 };
  }

  try {
    const twoFAData = await sql`
      SELECT * FROM two_factor_auth 
      WHERE user_id = ${session.user.id}
    `;

    if (!twoFAData[0]) {
      return { error: "2FA not setup", status: 404 };
    }

    if (backupCode) {
      const isValidBackupCode = twoFAData[0].backup_codes.includes(backupCode);

      if (isValidBackupCode) {
        const updatedBackupCodes = twoFAData[0].backup_codes.filter(
          (code) => code !== backupCode
        );

        await sql`
          UPDATE two_factor_auth 
          SET backup_codes = ${updatedBackupCodes}
          WHERE user_id = ${session.user.id}
        `;

        return { verified: true, status: 200 };
      }
    } else if (token) {
      const verified = speakeasy.totp.verify({
        secret: twoFAData[0].secret_key,
        encoding: "base32",
        token: token,
      });

      if (verified) {
        return { verified: true, status: 200 };
      }
    }

    return { error: "Invalid code", status: 400 };
  } catch (error) {
    console.error("Error verifying 2FA:", error);
    return { error: "Failed to verify 2FA", status: 500 };
  }
}