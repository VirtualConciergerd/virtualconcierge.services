async function handler({ method }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized", status: 401 };
  }

  if (method !== "POST") {
    return { error: "Method not allowed", status: 405 };
  }

  try {
    const secret = {
      ascii: Math.random().toString(36).slice(2),
      base32: Array.from(Array.from({ length: 32 }), () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join(""),
      otpauth_url: `otpauth://totp/YourApp:${
        session.user.email
      }?secret=${Array.from(Array.from({ length: 32 }), () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("")}&issuer=YourApp`,
    };

    const backupCodes = Array.from({ length: 10 }, () =>
      Array.from(Array.from({ length: 10 }), () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("")
    );

    await sql`
      INSERT INTO two_factor_auth 
      (user_id, secret_key, backup_codes, enabled) 
      VALUES 
      (${session.user.id}, ${secret.base32}, ${backupCodes}, false)
    `;

    const qrCodeDataUrl = secret.otpauth_url;

    return {
      secret: secret.base32,
      qrCode: qrCodeDataUrl,
      backupCodes,
      status: 200,
    };
  } catch (error) {
    console.error("Error setting up 2FA:", error);
    return { error: "Failed to setup 2FA", status: 500 };
  }
}