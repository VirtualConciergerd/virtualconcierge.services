async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const history = await sql`
      SELECT 
        id,
        login_timestamp,
        ip_address,
        user_agent,
        success,
        failure_reason,
        location
      FROM login_history 
      WHERE user_id = ${session.user.id}
      ORDER BY login_timestamp DESC 
      LIMIT 50
    `;

    return { history };
  } catch (error) {
    return { error: "Failed to fetch login history" };
  }
}