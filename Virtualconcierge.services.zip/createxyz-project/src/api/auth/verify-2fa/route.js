async function handler({ token }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const twoFactorData = await sql`
      SELECT secret_key, backup_codes 
      FROM two_factor_auth 
      WHERE user_id = ${session.user.id} AND enabled = true
    `;

    if (!twoFactorData?.[0]) {
      return { error: "2FA is not enabled for this account" };
    }

    const isBackupCode = twoFactorData[0].backup_codes?.includes(token);

    let verified = false;
    if (isBackupCode) {
      const updatedBackupCodes = twoFactorData[0].backup_codes.filter(
        (code) => code !== token
      );
      await sql`
        UPDATE two_factor_auth 
        SET backup_codes = ${updatedBackupCodes}
        WHERE user_id = ${session.user.id}
      `;
      verified = true;
    } else {
      verified = speakeasy.totp.verify({
        secret: twoFactorData[0].secret_key,
        encoding: "base32",
        token: token,
      });
    }

    if (!verified) {
      return { error: "Invalid token" };
    }

    return { success: true };
  } catch (error) {
    return { error: "Failed to verify 2FA token" };
  }
}