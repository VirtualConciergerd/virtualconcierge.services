async function handler({ sessionId }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    await sql`
      UPDATE active_sessions 
      SET is_revoked = true 
      WHERE id = ${sessionId} 
      AND user_id = ${session.user.id}
    `;

    return { success: true };
  } catch (error) {
    return { error: "Failed to revoke session" };
  }
}