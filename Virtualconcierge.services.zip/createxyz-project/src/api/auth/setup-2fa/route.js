async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const secret = {
      base32: Buffer.from(crypto.randomBytes(20)).toString("base32"),
      otpauth_url: `otpauth://totp/VirtualConcierge:${
        session.user.email
      }?secret=${Buffer.from(crypto.randomBytes(20)).toString(
        "base32"
      )}&issuer=VirtualConcierge`,
    };

    const qrCodeResult = await fetch(
      "https://api.qrserver.com/v1/create-qr-code/",
      {
        method: "POST",
        body: JSON.stringify({
          data: secret.otpauth_url,
          size: "200x200",
        }),
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    const qrCode = await qrCodeResult.url;

    const backupCodes = Array.from({ length: 10 }, () =>
      crypto.randomBytes(4).toString("hex")
    );

    await sql`
      INSERT INTO two_factor_auth (user_id, secret_key, backup_codes, enabled)
      VALUES (${session.user.id}, ${secret.base32}, ${backupCodes}, true)
      ON CONFLICT (user_id) 
      DO UPDATE SET 
        secret_key = ${secret.base32}, 
        backup_codes = ${backupCodes},
        enabled = true,
        updated_at = CURRENT_TIMESTAMP
    `;

    return {
      qrCode,
      backupCodes,
      secret: secret.base32,
    };
  } catch (error) {
    return { error: "Failed to setup 2FA" };
  }
}