async function handler({ reason }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    await sql`
      UPDATE auth_users 
      SET account_deletion_requested = CURRENT_TIMESTAMP,
          deletion_reason = ${reason}
      WHERE id = ${session.user.id}
    `;

    await sql`
      UPDATE active_sessions
      SET is_revoked = true 
      WHERE user_id = ${session.user.id}
    `;

    return { success: true };
  } catch (error) {
    return { error: "Failed to process account deletion request" };
  }
}