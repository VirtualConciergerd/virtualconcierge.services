async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const activeSessions = await sql`
      SELECT 
        id,
        session_token,
        device_info,
        last_active,
        ip_address,
        created_at
      FROM active_sessions 
      WHERE user_id = ${session.user.id} 
      AND is_revoked = false
      ORDER BY last_active DESC
    `;

    return { sessions: activeSessions };
  } catch (error) {
    return { error: "Failed to fetch active sessions" };
  }
}