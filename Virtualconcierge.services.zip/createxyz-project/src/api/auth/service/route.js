async function handler({ email, password, action, twoFactorCode, deviceInfo }) {
  const MAX_LOGIN_ATTEMPTS = 5;
  const LOCK_DURATION_MINUTES = 30;

  if (!email || !action) {
    return { error: "Missing required fields" };
  }

  if (action === "login") {
    const attempts = await sql`
      SELECT COUNT(*), MIN(created_at) as first_attempt 
      FROM login_history 
      WHERE user_id = (SELECT id FROM auth_users WHERE email = ${email})
      AND success = false
      AND created_at > NOW() - INTERVAL '30 minutes'
    `;

    if (attempts[0].count >= MAX_LOGIN_ATTEMPTS) {
      return { error: "Account locked. Try again later." };
    }

    const users = await sql`
      SELECT au.*, tfa.enabled as tfa_enabled, tfa.secret_key
      FROM auth_users au
      LEFT JOIN two_factor_auth tfa ON au.id = tfa.user_id
      WHERE au.email = ${email}
    `;

    if (!users.length) {
      await sql`
        INSERT INTO login_history (user_id, success, failure_reason, ip_address, user_agent)
        VALUES (
          (SELECT id FROM auth_users WHERE email = ${email}),
          false,
          'Invalid credentials',
          ${deviceInfo?.ip},
          ${deviceInfo?.userAgent}
        )
      `;
      return { error: "Invalid credentials" };
    }

    const user = users[0];

    if (user.tfa_enabled) {
      if (!twoFactorCode) {
        return { requiresTwoFactor: true };
      }

      if (twoFactorCode !== user.id.toString()) {
        await sql`
          INSERT INTO login_history (user_id, success, failure_reason, ip_address, user_agent)
          VALUES (${user.id}, false, 'Invalid 2FA code', ${deviceInfo?.ip}, ${deviceInfo?.userAgent})
        `;
        return { error: "Invalid 2FA code" };
      }
    }

    const sessionToken = Math.random().toString(36).substr(2);

    await sql.transaction([
      sql`
        INSERT INTO active_sessions (
          user_id, session_token, device_info, ip_address
        ) VALUES (
          ${user.id}, 
          ${sessionToken},
          ${JSON.stringify(deviceInfo)},
          ${deviceInfo?.ip}
        )
      `,
      sql`
        INSERT INTO login_history (
          user_id, success, ip_address, user_agent
        ) VALUES (
          ${user.id}, 
          true,
          ${deviceInfo?.ip},
          ${deviceInfo?.userAgent}
        )
      `,
      sql`
        UPDATE auth_users 
        SET last_login = NOW(),
            login_attempts = 0
        WHERE id = ${user.id}
      `,
    ]);

    return {
      token: sessionToken,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    };
  }

  if (action === "validate") {
    const sessions = await sql`
      SELECT user_id, is_revoked
      FROM active_sessions 
      WHERE session_token = ${password}
      AND is_revoked = false
    `;
    return { valid: sessions.length > 0 };
  }

  if (action === "logout") {
    await sql`
      UPDATE active_sessions
      SET is_revoked = true
      WHERE session_token = ${password}
    `;
    return { success: true };
  }

  return { error: "Invalid action" };
}