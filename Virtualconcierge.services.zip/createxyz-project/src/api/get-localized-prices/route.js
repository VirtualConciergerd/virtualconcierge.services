async function handler({ countryCode }) {
  try {
    const session = getSession();
    const userCountry = countryCode || session?.user?.country || "US";

    const countrySettings = await sql`
      SELECT currency_code, price_multiplier, vat_rate 
      FROM country_pricing 
      WHERE country_code = ${userCountry}
    `;

    if (countrySettings.length === 0) {
      return {
        currency: "USD",
        multiplier: 1,
        vatRate: 0,
      };
    }

    const settings = countrySettings[0];

    const plans = await sql`
      SELECT id, name, price_usd, regional_prices, default_currency
      FROM subscription_plans
    `;

    const guides = await sql`
      SELECT id, title, price_usd, regional_prices, default_currency 
      FROM premium_guides
    `;

    const localizedPlans = plans.map((plan) => {
      const regionalPrice = plan.regional_prices[settings.currency_code];
      const basePrice =
        regionalPrice || plan.price_usd * settings.price_multiplier;
      const vatAmount = basePrice * (settings.vat_rate / 100);

      return {
        ...plan,
        localizedPrice: basePrice + vatAmount,
        currency: settings.currency_code,
        vatRate: settings.vat_rate,
      };
    });

    const localizedGuides = guides.map((guide) => {
      const regionalPrice = guide.regional_prices[settings.currency_code];
      const basePrice =
        regionalPrice || guide.price_usd * settings.price_multiplier;
      const vatAmount = basePrice * (settings.vat_rate / 100);

      return {
        ...guide,
        localizedPrice: basePrice + vatAmount,
        currency: settings.currency_code,
        vatRate: settings.vat_rate,
      };
    });

    return {
      currency: settings.currency_code,
      multiplier: settings.price_multiplier,
      vatRate: settings.vat_rate,
      plans: localizedPlans,
      guides: localizedGuides,
    };
  } catch (error) {
    console.error("Price localization error:", error);
    return null;
  }
}