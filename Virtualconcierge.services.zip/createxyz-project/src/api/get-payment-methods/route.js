async function handler({ countryCode }) {
  try {
    const paymentMethods = await sql`
      SELECT 
        pm.id,
        pm.name,
        pm.description,
        pm.icon_url,
        pm.currency_code,
        pc.is_available,
        pc.restrictions,
        pc.conversion_rate
      FROM payment_methods pm
      LEFT JOIN payment_country_settings pc 
      ON pm.id = pc.payment_method_id 
      AND pc.country_code = ${countryCode}
      WHERE pc.is_available = true
    `;

    if (!paymentMethods.length) {
      return {
        error: "No payment methods available for this country",
        countryCode,
      };
    }

    const methods = paymentMethods.map((method) => {
      const basePrice = 99.99;
      const convertedPrice = basePrice * method.conversion_rate;

      return {
        id: method.id,
        name: method.name,
        description: method.description,
        iconUrl: method.icon_url,
        localCurrency: method.currency_code,
        localPrice: convertedPrice.toFixed(2),
        restrictions: method.restrictions || [],
      };
    });

    return {
      countryCode,
      paymentMethods: methods,
    };
  } catch (error) {
    return {
      error: "Failed to fetch payment methods",
      countryCode,
    };
  }
}