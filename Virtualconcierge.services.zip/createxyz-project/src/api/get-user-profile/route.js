async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  const [userProfile] = await sql`
    SELECT 
      u.*,
      au.name,
      au.email,
      au.image as avatar_url
    FROM users u
    LEFT JOIN auth_users au ON au.id = u.id
    WHERE u.id = ${userId}
  `;

  if (!userProfile) {
    return { error: "User profile not found" };
  }

  return {
    id: userProfile.id,
    name: userProfile.name,
    email: userProfile.email,
    phone: userProfile.phone,
    avatar_url: userProfile.avatar_url,
    timezone: userProfile.timezone,
    language: userProfile.language,
    display_name: userProfile.display_name,
    preferences: userProfile.preferences,
    notification_preferences: userProfile.notification_preferences,
    account_settings: userProfile.account_settings,
    created_at: userProfile.created_at,
    updated_at: userProfile.updated_at,
  };
}