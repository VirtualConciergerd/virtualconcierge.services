async function handler({ method, body, query }) {
  const session = getSession();
  if (!session?.user?.isAdmin) {
    return { error: "Unauthorized", status: 403 };
  }

  try {
    const { action, data } = body || {};

    switch (action) {
      case "list": {
        const countries = await sql(
          "SELECT * FROM countries ORDER BY sort_order ASC, name ASC"
        );
        return { data: countries };
      }

      case "create": {
        const columns = Object.keys(data);
        const values = Object.values(data);
        const placeholders = values.map((_, i) => `$${i + 1}`).join(", ");
        const columnList = columns.join(", ");

        const newCountry = await sql(
          `INSERT INTO countries (${columnList}) VALUES (${placeholders}) RETURNING *`,
          values
        );
        return { data: newCountry[0] };
      }

      case "update": {
        const { id, ...updateData } = data;
        const columns = Object.keys(updateData);
        const values = Object.values(updateData);
        const setClause = columns
          .map((col, i) => `${col} = $${i + 1}`)
          .join(", ");

        const updatedCountry = await sql(
          `UPDATE countries SET ${setClause} WHERE id = $${
            values.length + 1
          } RETURNING *`,
          [...values, id]
        );
        return { data: updatedCountry[0] };
      }

      case "delete": {
        await sql("DELETE FROM countries WHERE id = $1", [data.id]);
        return { data: { success: true } };
      }

      default:
        return { error: "Invalid action", status: 400 };
    }
  } catch (error) {
    console.error("Country management error:", error);
    return { error: "Internal server error", status: 500 };
  }
}