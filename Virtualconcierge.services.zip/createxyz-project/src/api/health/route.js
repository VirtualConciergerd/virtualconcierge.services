async function handler() {
  console.log(`Health check started at ${new Date().toISOString()}`);

  const healthStatus = {
    status: "ok",
    timestamp: new Date().toISOString(),
    checks: {
      database: { status: "pending" },
      imageProcessing: { status: "pending" },
      memory: { status: "pending" },
      responseTime: { status: "pending" },
    },
  };

  const startTime = Date.now();

  try {
    try {
      await sql`SELECT 1`;
      healthStatus.checks.database = {
        status: "healthy",
        responseTime: `${Date.now() - startTime}ms`,
      };
    } catch (error) {
      console.error("Database check failed:", error);
      healthStatus.status = "error";
      healthStatus.checks.database = {
        status: "error",
        error: "Database connection failed",
        details: error.message,
      };
    }

    try {
      const response = await fetch("https://api.create.xyz/v1/image/process", {
        method: "HEAD",
      });
      healthStatus.checks.imageProcessing = {
        status: response.ok ? "healthy" : "error",
        responseTime: `${Date.now() - startTime}ms`,
        statusCode: response.status,
      };
    } catch (error) {
      console.error("Image processing check failed:", error);
      healthStatus.status = "error";
      healthStatus.checks.imageProcessing = {
        status: "error",
        error: "Image processing service unavailable",
        details: error.message,
      };
    }

    try {
      const used = process.memoryUsage();
      healthStatus.checks.memory = {
        status: "healthy",
        heap: Math.round(used.heapUsed / 1024 / 1024) + "MB",
        total: Math.round(used.heapTotal / 1024 / 1024) + "MB",
        rss: Math.round(used.rss / 1024 / 1024) + "MB",
      };
    } catch (error) {
      console.error("Memory check failed:", error);
      healthStatus.status = "error";
      healthStatus.checks.memory = {
        status: "error",
        error: "Memory check failed",
        details: error.message,
      };
    }

    healthStatus.checks.responseTime = {
      status: "healthy",
      total: `${Date.now() - startTime}ms`,
    };

    return {
      statusCode: healthStatus.status === "ok" ? 200 : 500,
      body: healthStatus,
    };
  } catch (error) {
    console.error("Health check failed with critical error:", error);
    return {
      statusCode: 500,
      body: {
        status: "error",
        error: "Health check failed",
        details: error.message,
        timestamp: new Date().toISOString(),
      },
    };
  }
}