async function handler({ action, guideId }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "purchaseGuide": {
      const existing = await sql(
        "SELECT id FROM user_purchases WHERE user_id = $1 AND guide_id = $2",
        [session.user.id, guideId]
      );

      if (existing.length > 0) {
        return { error: "Already purchased" };
      }

      const guides = await sql("SELECT * FROM premium_guides WHERE id = $1", [
        guideId,
      ]);

      if (!guides.length) {
        return { error: "Guide not found" };
      }

      const guide = guides[0];

      const response = await fetch(
        "https://api.stripe.com/v1/payment_intents",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            amount: Math.round(guide.price_usd * 100),
            currency: "usd",
            customer: session.user.stripeCustomerId,
            metadata: JSON.stringify({ guideId }),
          }),
        }
      );

      const paymentIntent = await response.json();

      if (paymentIntent.error) {
        return { error: paymentIntent.error.message };
      }

      return { clientSecret: paymentIntent.client_secret };
    }

    case "enableOfflineAccess": {
      const key = Array.from(
        crypto.getRandomValues(new Uint8Array.from({ length: 32 }))
      )
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");

      await sql(
        "INSERT INTO offline_content (user_id, guide_id, encryption_key) VALUES ($1, $2, $3)",
        [session.user.id, guideId, key]
      );

      return {
        encryptionKey: key,
        message: "Offline access enabled",
      };
    }

    default:
      return { error: "Invalid action" };
  }
}