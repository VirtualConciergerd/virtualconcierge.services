async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const timestamp = new Date().toISOString();
    const tables = [
      "countries",
      "regions",
      "attractions",
      "accommodations",
      "businesses",
      "emergency_services",
      "orders",
      "products",
      "subscriptions",
      "users",
    ];

    // Create dynamic queries for each table
    const queries = [
      sql`
        INSERT INTO system_backups (backup_date, backup_type, status, metadata)
        VALUES ($1, 'full', 'in_progress', $2)
        RETURNING id
      `,
      ...tables.map((table) =>
        sql("SELECT json_agg(t.*) as data FROM " + table + " t")
      ),
    ];

    const [initialBackup, ...tableBackups] = await sql.transaction(queries);

    // Combine all backup data
    const backupData = {};
    tables.forEach((table, index) => {
      backupData[table] = tableBackups[index][0].data;
    });

    // Update backup record
    await sql`
      UPDATE system_backups 
      SET status = 'completed',
          metadata = $1::jsonb
      WHERE id = $2
    `([
      JSON.stringify({
        tables,
        count: tables.length,
        backup_date: timestamp,
        data: backupData,
      }),
      initialBackup[0].id,
    ]);

    // Verify backup completion with health check
    await fetch("/api/system-health-check", {
      method: "POST",
    });

    return {
      success: true,
      message: "Backup completed successfully",
      timestamp,
      backupId: initialBackup[0].id,
      tablesBackedUp: tables.length,
    };
  } catch (error) {
    console.error("Backup error:", error);

    // Log failed backup attempt
    await sql`
      UPDATE system_backups
      SET status = 'failed',
          metadata = jsonb_set(metadata, '{error}', $1::jsonb)
      WHERE backup_type = 'full'
      AND status = 'in_progress'
    `([JSON.stringify(error.message)]);

    return {
      error: "Backup failed",
      status: 500,
    };
  }
}