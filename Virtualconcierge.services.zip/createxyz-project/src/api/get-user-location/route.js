async function handler() {
  try {
    // Check cache first
    const cached = await sql`
      SELECT country_code, country_name, created_at 
      FROM user_locations 
      ORDER BY created_at DESC 
      LIMIT 1
    `;

    // If we have a recent cache entry (less than 1 day old), return it
    if (cached.length > 0) {
      const cacheAge = Date.now() - new Date(cached[0].created_at).getTime();
      if (cacheAge < 24 * 60 * 60 * 1000) {
        return {
          countryCode: cached[0].country_code,
          countryName: cached[0].country_name,
          cached: true,
        };
      }
    }

    // Make API call to get location
    const response = await fetch("http://ip-api.com/json/");
    if (!response.ok) {
      throw new Error("Failed to fetch location data");
    }

    const data = await response.json();

    if (data.status === "success") {
      // Store in cache
      await sql`
        INSERT INTO user_locations (country_code, country_name, created_at)
        VALUES (${data.countryCode}, ${
        data.country
      }, ${new Date().toISOString()})
      `;

      return {
        countryCode: data.countryCode,
        countryName: data.country,
        cached: false,
      };
    }

    throw new Error("Location detection failed");
  } catch (error) {
    // Return default values if anything fails
    return {
      countryCode: "DO",
      countryName: "Dominican Republic",
      isDefault: true,
    };
  }
}