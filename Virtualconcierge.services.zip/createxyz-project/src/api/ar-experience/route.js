async function handler({ action, modelId, attractionId, sessionId, metrics }) {
  const session = await getSession();
  if (!session?.user) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  const subscription = await sql(
    "SELECT p.features->>$1 as has_ar FROM user_subscriptions s JOIN subscription_plans p ON s.plan_id = p.id WHERE s.user_id = $2 AND s.status = $3 AND s.current_period_end > NOW()",
    ["ar_access", session.user.id, "active"]
  );

  if (!subscription[0]?.has_ar) {
    return { status: 403, body: { error: "AR access required" } };
  }

  switch (action) {
    case "getModel": {
      const model = await sql("SELECT * FROM ar_models WHERE id = $1", [
        modelId,
      ]);

      if (model.length === 0) {
        return { status: 404, body: { error: "Model not found" } };
      }

      await sql(
        "INSERT INTO ar_sessions (user_id, model_id, device_info) VALUES ($1, $2, $3)",
        [session.user.id, modelId, JSON.stringify(req.headers["user-agent"])]
      );

      return { status: 200, body: model[0] };
    }

    case "getAttractionModels": {
      const models = await sql(
        "SELECT * FROM ar_models WHERE attraction_id = $1",
        [attractionId]
      );
      return { status: 200, body: models };
    }

    case "endSession": {
      await sql(
        "UPDATE ar_sessions SET ended_at = NOW(), performance_metrics = $1 WHERE id = $2",
        [JSON.stringify(metrics), sessionId]
      );

      return { status: 200, body: { success: true } };
    }

    default:
      return { status: 400, body: { error: "Invalid action" } };
  }
}