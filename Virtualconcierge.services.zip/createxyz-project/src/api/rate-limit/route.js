async function handler({ ip, userId, endpoint }) {
  if (!ip) {
    return { error: "IP address required", status: 400 };
  }

  if (!endpoint?.includes("/image")) {
    return { success: true };
  }

  const now = new Date();
  const minuteStart = new Date(now.getTime() - 60000);
  const hourStart = new Date(now.getTime() - 3600000);

  await sql("DELETE FROM rate_limit WHERE created_at < $1", [hourStart]);

  let ipLimit = 30;
  let userLimit = 100;

  if (userId) {
    const userSubscription = await sql(
      `
      SELECT plan_id FROM user_subscriptions 
      WHERE user_id = $1 
      AND status = 'active' 
      AND current_period_end > NOW()
    `,
      [userId]
    );

    if (userSubscription.length > 0) {
      ipLimit = 100;
      userLimit = 500;
    }
  }

  const ipResult = await sql(
    `
    SELECT COUNT(*) as count 
    FROM rate_limit 
    WHERE ip = $1 
    AND created_at > $2
  `,
    [ip, minuteStart]
  );

  const ipCount = parseInt(ipResult[0].count);
  if (ipCount >= ipLimit) {
    await sql(
      `
      INSERT INTO admin_audit_log (user_id, action, entity_type, entity_id, changes)
      VALUES ($1, 'rate_limit_exceeded', 'ip_limit', NULL, $2)
    `,
      [
        userId || null,
        JSON.stringify({
          ip,
          endpoint,
          count: ipCount,
          limit: ipLimit,
          window: "minute",
        }),
      ]
    );

    return {
      error: `Rate limit exceeded. Maximum ${ipLimit} requests per minute from this IP address.`,
      status: 429,
      resetAt: new Date(minuteStart.getTime() + 60000).toISOString(),
      retryAfter: 60,
    };
  }

  if (userId) {
    const userResult = await sql(
      `
      SELECT COUNT(*) as count 
      FROM rate_limit 
      WHERE user_id = $1 
      AND created_at > $2
    `,
      [userId, hourStart]
    );

    const userCount = parseInt(userResult[0].count);
    if (userCount >= userLimit) {
      await sql(
        `
        INSERT INTO admin_audit_log (user_id, action, entity_type, entity_id, changes)
        VALUES ($1, 'rate_limit_exceeded', 'user_limit', NULL, $2)
      `,
        [
          userId,
          JSON.stringify({
            userId,
            endpoint,
            count: userCount,
            limit: userLimit,
            window: "hour",
          }),
        ]
      );

      return {
        error: `User rate limit exceeded. Maximum ${userLimit} requests per hour. Consider upgrading to premium for higher limits.`,
        status: 429,
        resetAt: new Date(hourStart.getTime() + 3600000).toISOString(),
        retryAfter: 3600,
      };
    }
  }

  await sql(
    `
    INSERT INTO rate_limit (ip, user_id, endpoint, created_at)
    VALUES ($1, $2, $3, $4)
  `,
    [ip, userId || null, endpoint, now]
  );

  return {
    success: true,
    limits: {
      ipRemaining: ipLimit - ipCount - 1,
      ipLimit,
      ipResetAt: new Date(minuteStart.getTime() + 60000).toISOString(),
      userRemaining: userId
        ? userLimit - (parseInt(userResult[0].count) + 1)
        : null,
      userLimit: userId ? userLimit : null,
      userResetAt: userId
        ? new Date(hourStart.getTime() + 3600000).toISOString()
        : null,
      isPremium: ipLimit > 30,
    },
  };
}