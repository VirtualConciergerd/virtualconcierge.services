async function handler({ action, planId, paymentMethodId, subscriptionId }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "createSubscription": {
      try {
        const subscription = await fetch(
          "https://api.stripe.com/v1/subscriptions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              customer: session.user.stripeCustomerId,
              "items[0][price]": planId,
              payment_method: paymentMethodId,
              expand: ["latest_invoice.payment_intent"],
            }),
          }
        ).then((r) => r.json());

        if (subscription.error) {
          return { error: subscription.error.message };
        }

        await sql(
          `
          INSERT INTO user_subscriptions (
            user_id, plan_id, status, 
            current_period_start, current_period_end
          ) VALUES ($1, $2, $3, $4, $5)
        `,
          [
            session.user.id,
            planId,
            subscription.status,
            new Date(subscription.current_period_start * 1000),
            new Date(subscription.current_period_end * 1000),
          ]
        );

        return { subscription };
      } catch (err) {
        return { error: "Failed to create subscription" };
      }
    }

    case "cancelSubscription": {
      try {
        const cancelledSubscription = await fetch(
          `https://api.stripe.com/v1/subscriptions/${subscriptionId}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              cancel_at_period_end: "true",
            }),
          }
        ).then((r) => r.json());

        if (cancelledSubscription.error) {
          return { error: cancelledSubscription.error.message };
        }

        await sql(
          `
          UPDATE user_subscriptions 
          SET cancel_at_period_end = true,
              updated_at = CURRENT_TIMESTAMP
          WHERE user_id = $1
        `,
          [session.user.id]
        );

        return { message: "Subscription cancelled" };
      } catch (err) {
        return { error: "Failed to cancel subscription" };
      }
    }

    default:
      return { error: "Invalid action" };
  }
}