async function handler({ name, email, message }) {
  if (!name || !email || !message) {
    return { error: "All fields are required" };
  }

  try {
    const result = await sql`
      INSERT INTO contact_submissions (name, email, message)
      VALUES (${name}, ${email}, ${message})
      RETURNING *
    `;

    return { success: true, message: "Message sent successfully" };
  } catch (error) {
    return { error: "Failed to submit contact form" };
  }
}