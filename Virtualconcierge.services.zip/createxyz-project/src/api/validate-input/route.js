function handler({ input, email, type }) {
  const sanitizeInput = (text) => {
    if (typeof text !== "string") return "";
    return text.replace(/[<>]/g, "");
  };

  const validateEmail = (emailAddress) => {
    if (typeof emailAddress !== "string") return false;
    return Boolean(emailAddress.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/));
  };

  if (!input && !email) {
    return { error: "No input provided" };
  }

  if (type === "email") {
    const isValid = validateEmail(email);
    return {
      valid: isValid,
      sanitized: isValid ? email : null,
    };
  }

  return {
    valid: true,
    sanitized: sanitizeInput(input),
  };
}