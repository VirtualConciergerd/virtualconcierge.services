async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const sampleBusinesses = [
      {
        name: "Seaside Resort & Spa",
        type: "Hotel",
        contact_name: "Maria Santos",
        email: "maria@seasideresort.test",
        phone: "+1-555-0123",
        address: "123 Beach Drive, Coastal City",
        website: "https://seasideresort.test",
        status: "verified",
        country_id: 1,
        region_id: 1,
      },
      {
        name: "Mountain View Restaurant",
        type: "Restaurant",
        contact_name: "John Chen",
        email: "john@mvrestaurant.test",
        phone: "+1-555-0124",
        address: "456 Highland Road",
        website: "https://mvrestaurant.test",
        status: "verified",
        country_id: 1,
        region_id: 2,
      },
      {
        name: "City Tours & Adventures",
        type: "Tour Operator",
        contact_name: "Sarah Johnson",
        email: "sarah@citytours.test",
        phone: "+1-555-0125",
        address: "789 Downtown Ave",
        website: "https://citytours.test",
        status: "pending",
        country_id: 2,
        region_id: 3,
      },
    ];

    // First clear existing businesses
    await sql`TRUNCATE TABLE businesses CASCADE`;

    // Build query parts
    const columns = [
      "name",
      "type",
      "contact_name",
      "email",
      "phone",
      "address",
      "website",
      "status",
      "country_id",
      "region_id",
    ];
    const values = sampleBusinesses.map((b) => columns.map((col) => b[col]));

    // Build placeholders for prepared statement
    const placeholders = values
      .map(
        (_, i) =>
          `(${columns
            .map((_, j) => `$${i * columns.length + j + 1}`)
            .join(",")})`
      )
      .join(",");

    // Flatten values array
    const flatValues = values.flat();

    // Execute insert
    const businesses = await sql(
      `INSERT INTO businesses (${columns.join(
        ","
      )}) VALUES ${placeholders} RETURNING *`,
      flatValues
    );

    return {
      success: true,
      count: businesses.length,
      businesses,
    };
  } catch (error) {
    console.error("Seed error:", error);
    return { error: "Failed to seed businesses" };
  }
}