async function handler({
  action,
  userId,
  role,
  startDate,
  endDate,
  reportType,
} = {}) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized access" };
  }

  // Verify admin status
  const adminCheck = await sql`
    SELECT id FROM auth_users 
    WHERE id = ${session.user.id} 
    AND email LIKE '%@admin%'
  `;

  if (!adminCheck.length) {
    return { error: "Admin privileges required" };
  }

  switch (action) {
    case "getMetrics": {
      const [users, businesses, bookings, revenue] = await sql.transaction([
        sql`SELECT COUNT(*) as total FROM auth_users`,
        sql`SELECT COUNT(*), status FROM businesses GROUP BY status`,
        sql`SELECT COUNT(*), status FROM bookings WHERE created_at >= NOW() - INTERVAL '30 days' GROUP BY status`,
        sql`SELECT SUM(total_amount) as total FROM orders WHERE created_at >= NOW() - INTERVAL '30 days' AND status = 'completed'`,
      ]);

      return {
        metrics: {
          totalUsers: users[0]?.total || 0,
          businessMetrics: businesses,
          recentBookings: bookings,
          monthlyRevenue: revenue[0]?.total || 0,
        },
      };
    }

    case "manageUser": {
      if (!userId || !role) {
        return { error: "User ID and role required" };
      }

      await sql`
        UPDATE users 
        SET preferences = jsonb_set(
          COALESCE(preferences, '{}'::jsonb),
          '{role}',
          ${JSON.stringify(role)}::jsonb
        )
        WHERE id = ${userId}
      `;

      return { success: true };
    }

    case "systemStatus": {
      const [dbStatus, errorCount, serviceStatus] = await sql.transaction([
        sql`SELECT NOW() - pg_postmaster_start_time() as uptime`,
        sql`SELECT COUNT(*) as count FROM error_logs WHERE created_at >= NOW() - INTERVAL '24 hours'`,
        sql`SELECT status, COUNT(*) FROM bookings WHERE created_at >= NOW() - INTERVAL '1 hour' GROUP BY status`,
      ]);

      return {
        status: {
          dbUptime: dbStatus[0]?.uptime,
          recentErrors: errorCount[0]?.count,
          serviceHealth: serviceStatus,
        },
      };
    }

    case "generateReport": {
      if (!startDate || !endDate || !reportType) {
        return { error: "Date range and report type required" };
      }

      let reportData;
      switch (reportType) {
        case "business": {
          reportData = await sql`
            SELECT 
              b.status,
              COUNT(*) as count,
              c.name as country
            FROM businesses b
            LEFT JOIN countries c ON b.country_id = c.id
            WHERE b.created_at BETWEEN ${startDate} AND ${endDate}
            GROUP BY b.status, c.name
          `;
          break;
        }
        case "revenue": {
          reportData = await sql`
            SELECT 
              DATE_TRUNC('day', created_at) as date,
              SUM(total_amount) as revenue,
              COUNT(*) as order_count
            FROM orders
            WHERE created_at BETWEEN ${startDate} AND ${endDate}
            GROUP BY DATE_TRUNC('day', created_at)
            ORDER BY date
          `;
          break;
        }
        default:
          return { error: "Invalid report type" };
      }

      return { report: reportData };
    }

    case "errorLogs": {
      const errors = await sql`
        SELECT 
          error_type,
          message,
          created_at,
          user_id
        FROM error_logs
        WHERE created_at >= NOW() - INTERVAL '24 hours'
        ORDER BY created_at DESC
        LIMIT 100
      `;

      return { errors };
    }

    default:
      return { error: "Invalid action" };
  }
}