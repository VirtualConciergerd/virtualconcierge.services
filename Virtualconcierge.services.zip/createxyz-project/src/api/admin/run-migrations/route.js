async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    // Execute migrations sequentially
    await sql`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`;

    await sql`ALTER TABLE businesses 
      ADD COLUMN IF NOT EXISTS last_sync_at TIMESTAMP,
      ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'`;

    await sql`CREATE INDEX IF NOT EXISTS idx_businesses_last_sync 
      ON businesses(last_sync_at)`;

    return { success: true, message: "Migrations completed successfully" };
  } catch (error) {
    console.error("Migration error:", error);
    return { error: "Migration failed" };
  }
}