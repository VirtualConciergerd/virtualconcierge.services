async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const businessTypes = {
      HOTELS: [
        {
          name: "Grand Plaza Hotel",
          type: "Hotel",
          contact_name: "James Wilson",
          email: "james@grandplaza.test",
          phone: "+1-555-0101",
          address: "1 Luxury Avenue",
          website: "https://grandplaza.test",
          status: "verified",
        },
        {
          name: "Beachfront Resort",
          type: "Resort",
          contact_name: "Elena Rodriguez",
          email: "elena@beachfront.test",
          phone: "+1-555-0102",
          address: "2 Coastal Road",
          website: "https://beachfront.test",
          status: "verified",
        },
      ],
      RESTAURANTS: [
        {
          name: "Fusion Kitchen",
          type: "Restaurant",
          contact_name: "Chef Mike Chang",
          email: "mike@fusionkitchen.test",
          phone: "+1-555-0201",
          address: "10 Culinary Street",
          website: "https://fusionkitchen.test",
          status: "verified",
        },
        {
          name: "Local Bistro",
          type: "Restaurant",
          contact_name: "Sophie Laurent",
          email: "sophie@localbistro.test",
          phone: "+1-555-0202",
          address: "20 Main Street",
          website: "https://localbistro.test",
          status: "pending",
        },
      ],
      TOUR_OPERATORS: [
        {
          name: "Adventure Tours",
          type: "Tour Operator",
          contact_name: "Alex Thompson",
          email: "alex@adventuretours.test",
          phone: "+1-555-0301",
          address: "30 Explorer Road",
          website: "https://adventuretours.test",
          status: "verified",
        },
        {
          name: "Cultural Expeditions",
          type: "Tour Operator",
          contact_name: "Maria Garcia",
          email: "maria@culturalexp.test",
          phone: "+1-555-0302",
          address: "40 Heritage Lane",
          website: "https://culturalexp.test",
          status: "pending",
        },
      ],
      TRANSPORTATION: [
        {
          name: "City Cab Co",
          type: "Transportation",
          contact_name: "David Kim",
          email: "david@citycab.test",
          phone: "+1-555-0401",
          address: "50 Transit Way",
          website: "https://citycab.test",
          status: "verified",
        },
        {
          name: "Luxury Transfers",
          type: "Transportation",
          contact_name: "Linda Black",
          email: "linda@luxtransfers.test",
          phone: "+1-555-0402",
          address: "60 Airport Road",
          website: "https://luxtransfers.test",
          status: "pending",
        },
      ],
    };

    const countries = await sql("SELECT id FROM countries LIMIT 3");
    const regions = await sql("SELECT id FROM regions LIMIT 5");

    const allBusinesses = Object.values(businessTypes)
      .flat()
      .map((business, index) => ({
        ...business,
        country_id: countries[index % countries.length]?.id || 1,
        region_id: regions[index % regions.length]?.id || 1,
        created_at: new Date(
          Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000
        ),
      }));

    const columns = [
      "name",
      "type",
      "contact_name",
      "email",
      "phone",
      "address",
      "website",
      "status",
      "country_id",
      "region_id",
      "created_at",
    ];

    const values = allBusinesses.map((business) =>
      columns.map((col) => business[col])
    );

    const placeholders = values
      .map(
        (_, i) =>
          `(${columns
            .map((_, j) => `$${i * columns.length + j + 1}`)
            .join(",")})`
      )
      .join(",");

    const query = `
      INSERT INTO businesses (${columns.join(",")})
      VALUES ${placeholders}
      RETURNING *
    `;

    const flatValues = values.flat();
    const businesses = await sql(query, flatValues);

    return {
      success: true,
      count: businesses.length,
      businessesByType: {
        hotels: businesses.filter(
          (b) => b.type === "Hotel" || b.type === "Resort"
        ),
        restaurants: businesses.filter((b) => b.type === "Restaurant"),
        tourOperators: businesses.filter((b) => b.type === "Tour Operator"),
        transportation: businesses.filter((b) => b.type === "Transportation"),
      },
    };
  } catch (error) {
    console.error("Extended seed error:", error);
    return { error: "Failed to seed extended business data" };
  }
}