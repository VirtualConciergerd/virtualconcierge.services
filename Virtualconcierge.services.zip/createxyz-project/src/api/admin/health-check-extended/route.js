async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const metrics = await sql(
      `
      WITH stats AS (
        SELECT
          COUNT(*) as total_businesses,
          COUNT(*) FILTER (WHERE status = $1) as pending_count,
          COUNT(*) FILTER (WHERE status = $2) as verified_count,
          COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '24 hours') as last_24h,
          COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '7 days') as last_7d,
          COUNT(DISTINCT type) as business_types,
          COUNT(DISTINCT country_id) as countries_represented,
          MAX(created_at) as latest_registration,
          MIN(created_at) as earliest_registration
        FROM businesses
      ),
      type_breakdown AS (
        SELECT type, COUNT(*) as count
        FROM businesses
        GROUP BY type
      )
      SELECT 
        stats.*,
        json_agg(json_build_object('type', type, 'count', count)) as type_distribution
      FROM stats, type_breakdown
      GROUP BY stats.*
    `,
      ["pending", "verified"]
    );

    const dbLatency = await sql`SELECT NOW() - NOW() as latency`;

    const lastBackup = await sql`
      SELECT backup_date, status 
      FROM system_backups 
      ORDER BY backup_date DESC 
      LIMIT 1
    `;

    return {
      success: true,
      timestamp: new Date().toISOString(),
      metrics: {
        ...metrics[0],
        database: {
          status: "healthy",
          latency: dbLatency[0].latency,
        },
        backups: {
          lastBackup: lastBackup[0] || null,
          status: lastBackup[0]?.status || "unknown",
        },
      },
    };
  } catch (error) {
    console.error("Enhanced health check error:", error);
    return { error: "Enhanced health check failed" };
  }
}