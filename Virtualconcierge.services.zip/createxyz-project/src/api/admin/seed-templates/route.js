async function handler() {
  const templates = [
    {
      business_type: "restaurant",
      status: "approved",
      language_code: "en",
      subject: "🎉 Welcome to Our Restaurant Network!",
      body: `
        <h2>Welcome aboard, {businessName}!</h2>
        <p>Your restaurant has been approved. Here are some restaurant-specific next steps:</p>
        <ul>
          <li>Upload your menu</li>
          <li>Set special dining hours</li>
          <li>Add food photos</li>
        </ul>
      `,
    },
    {
      business_type: "hotel",
      status: "approved",
      language_code: "en",
      subject: "🌟 Welcome to Our Hotel Network!",
      body: `
        <h2>Welcome aboard, {businessName}!</h2>
        <p>Your hotel has been approved. Here are some hotel-specific next steps:</p>
        <ul>
          <li>Set up your room inventory</li>
          <li>Add amenity details</li>
          <li>Upload property photos</li>
        </ul>
      `,
    },
    {
      business_type: "retail",
      status: "approved",
      language_code: "en",
      subject: "🛍️ Welcome to Our Retail Network!",
      body: `
        <h2>Welcome aboard, {businessName}!</h2>
        <p>Your retail business has been approved. Here are some retail-specific next steps:</p>
        <ul>
          <li>Upload your product catalog</li>
          <li>Set business hours</li>
          <li>Add store photos</li>
        </ul>
      `,
    },
  ];

  try {
    const queries = templates.map((template) => {
      return sql`
        INSERT INTO email_templates 
          (business_type, status, language_code, subject, body)
        VALUES
          (${template.business_type}, ${template.status}, ${template.language_code}, 
           ${template.subject}, ${template.body})
        ON CONFLICT (business_type, status, language_code) 
        DO UPDATE SET 
          subject = EXCLUDED.subject,
          body = EXCLUDED.body,
          updated_at = CURRENT_TIMESTAMP
      `;
    });

    await sql.transaction(queries);
    return { success: true, message: "Email templates seeded successfully" };
  } catch (error) {
    return { success: false, error: "Failed to seed email templates" };
  }
}