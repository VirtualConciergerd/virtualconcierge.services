async function handler() {
  try {
    const suspiciousActivity = await sql`
      SELECT user_id, COUNT(*) as action_count
      FROM admin_audit_log
      WHERE created_at > NOW() - INTERVAL '1 hour'
      GROUP BY user_id
      HAVING COUNT(*) > 100`;

    const failedOperations = await sql`
      SELECT entity_type, COUNT(*) as fail_count
      FROM admin_audit_log
      WHERE action = 'error'
      AND created_at > NOW() - INTERVAL '24 hours'
      GROUP BY entity_type`;

    const report = {
      timestamp: new Date(),
      suspiciousActivity: suspiciousActivity,
      failedOperations: failedOperations,
      status: "normal",
    };

    if (suspiciousActivity.length > 0) {
      report.status = "alert";
      report.alerts = ["Suspicious activity detected"];
    }

    return report;
  } catch (error) {
    return { error: "Audit monitoring failed" };
  }
}