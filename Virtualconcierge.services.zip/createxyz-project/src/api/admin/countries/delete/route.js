async function handler({ id }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!id) {
    return { error: "Country ID is required" };
  }

  const deleted = await sql`
    DELETE FROM countries 
    WHERE id = ${id}
    RETURNING *
  `;

  if (!deleted.length) {
    return { error: "Country not found" };
  }

  return deleted[0];
}