const rateLimit = require("express-rate-limit");
const winston = require("winston");

const logger = winston.createLogger({
  level: "info",
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: "error.log", level: "error" }),
    new winston.transports.File({ filename: "combined.log" }),
  ],
});

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});

async function handler(
  {
    name,
    code,
    currency,
    language,
    emergency_number,
    tourist_hotline,
    timezone,
    theme_settings,
    ip_ranges,
    cultural_colors,
    flag_colors,
    sort_order,
  },
  req
) {
  logger.info("Create country request", {
    timestamp: new Date(),
    ip: req.ip,
    user: session?.user?.id,
    params: { name, code },
  });

  try {
    await limiter(req, {}, () => {});
  } catch (error) {
    return { error: "Too many requests, please try again later" };
  }

  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!name || !code) {
    return { error: "Name and code are required" };
  }

  if (!code.match(/^[A-Z]{2}$/)) {
    return { error: "Country code must be 2 uppercase letters" };
  }

  if (currency && !currency.match(/^[A-Z]{3}$/)) {
    return { error: "Currency must be 3 uppercase letters" };
  }

  if (language && !language.match(/^[a-z]{2}$/)) {
    return { error: "Language must be 2 lowercase letters" };
  }

  if (timezone) {
    try {
      Intl.DateTimeFormat(undefined, { timeZone: timezone });
    } catch (e) {
      return { error: "Invalid timezone" };
    }
  }

  if (ip_ranges) {
    const validIpRange = (range) =>
      range.match(/^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/);
    if (!Array.isArray(ip_ranges) || !ip_ranges.every(validIpRange)) {
      return { error: "Invalid IP range format" };
    }
  }

  if (theme_settings) {
    const allowedKeys = [
      "text",
      "accent",
      "cardBg",
      "primary",
      "footerBg",
      "headerBg",
      "secondary",
      "background",
      "buttonText",
      "borderColor",
    ];
    theme_settings = Object.fromEntries(
      Object.entries(theme_settings).filter(([key]) =>
        allowedKeys.includes(key)
      )
    );
  }

  try {
    const result = await sql.transaction(async (sql) => {
      const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000);
      const recentActions = await sql`
        SELECT COUNT(*) 
        FROM admin_audit_log 
        WHERE user_id = ${session.user.id} 
        AND created_at > ${fifteenMinutesAgo}
      `;

      if (recentActions[0].count >= 100) {
        throw new Error("Rate limit exceeded. Please try again later.");
      }

      const existing = await sql`
        SELECT code FROM countries WHERE code = ${code}
      `;

      if (existing.length > 0) {
        throw new Error("Country code already exists");
      }

      const country = await sql`
        INSERT INTO countries (
          name, code, currency, language, emergency_number, 
          tourist_hotline, timezone, theme_settings, ip_ranges,
          cultural_colors, flag_colors, sort_order
        )
        VALUES (
          ${name}, ${code}, ${currency}, ${language}, ${emergency_number},
          ${tourist_hotline}, ${timezone}, ${theme_settings}, ${ip_ranges},
          ${cultural_colors}, ${flag_colors}, ${sort_order}
        )
        RETURNING *
      `;

      await sql`
        INSERT INTO admin_audit_log (
          user_id, action, entity_type, entity_id, changes
        ) VALUES (
          ${session.user.id}, 'create', 'country', ${
        country[0].id
      }, ${JSON.stringify({
        ...country[0],
        action_details: "Country creation",
        timestamp: new Date().toISOString(),
      })}
        )
      `;

      logger.info("Country created successfully", {
        countryId: country[0].id,
        userId: session.user.id,
        timestamp: new Date(),
      });

      return country[0];
    });

    return result;
  } catch (error) {
    await sql`
      INSERT INTO admin_audit_log (
        user_id, action, entity_type, changes
      ) VALUES (
        ${session.user.id}, 'error', 'country', ${JSON.stringify({
      error: error.message,
      attempted_action: "create_country",
      timestamp: new Date().toISOString(),
    })}
      )
    `;

    logger.error("Create country error", {
      error: error.message,
      stack: error.stack,
      userId: session?.user?.id,
      timestamp: new Date(),
    });

    return { error: error.message || "Failed to create country" };
  }
}