async function handler({ params, method, body }) {
  const session = getSession();
  if (!session?.user?.role === "admin") {
    throw new Error("Unauthorized");
  }

  const { id } = params;

  if (method === "PUT") {
    const { theme_settings } = body;

    // Validate theme settings
    const requiredColors = [
      "primary",
      "secondary",
      "accent",
      "background",
      "text",
      "headerBg",
      "footerBg",
      "cardBg",
      "buttonText",
      "borderColor",
    ];

    const missingColors = requiredColors.filter(
      (color) => !theme_settings[color]
    );
    if (missingColors.length > 0) {
      throw new Error(`Missing required colors: ${missingColors.join(", ")}`);
    }

    // Update theme settings using function notation for clarity
    const updatedCountry = await sql(
      "UPDATE countries SET theme_settings = $1 WHERE id = $2 RETURNING *",
      [theme_settings, id]
    );

    return updatedCountry[0];
  }

  throw new Error("Method not allowed");
}