async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  const countries = await sql`
    SELECT * FROM countries 
    ORDER BY sort_order ASC, name ASC
  `;

  return countries;
}