async function handler({ method, body, params }) {
  const session = getSession();
  if (!session?.user?.role === "admin") {
    return { error: "Unauthorized" };
  }

  try {
    switch (method) {
      case "GET": {
        const countries = await sql`
          SELECT * FROM countries 
          ORDER BY name ASC
        `;
        return { countries };
      }

      case "POST": {
        const {
          name,
          code,
          currency,
          language,
          emergency_number,
          tourist_hotline,
        } = body;
        const result = await sql`
          INSERT INTO countries 
            (name, code, currency, language, emergency_number, tourist_hotline)
          VALUES 
            (${name}, ${code}, ${currency}, ${language}, ${emergency_number}, ${tourist_hotline})
          RETURNING *
        `;
        return { country: result[0] };
      }

      case "PUT": {
        const { id, ...updates } = body;

        // Build dynamic query
        const setEntries = Object.entries(updates);
        const setClauses = setEntries
          .map((_, i) => `${setEntries[i][0]} = $${i + 2}`)
          .join(", ");
        const values = [id, ...setEntries.map((entry) => entry[1])];

        const result = await sql(
          `UPDATE countries SET ${setClauses} WHERE id = $1 RETURNING *`,
          values
        );

        return { country: result[0] };
      }

      case "DELETE": {
        const { id } = params;
        await sql`
          DELETE FROM countries 
          WHERE id = ${id}
        `;
        return { success: true };
      }

      default:
        return { error: "Method not allowed" };
    }
  } catch (error) {
    return { error: error.message };
  }
}