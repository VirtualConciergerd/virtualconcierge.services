async function handler({ id, ...updateData }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!id) {
    return { error: "Country ID is required" };
  }

  const fields = Object.keys(updateData);
  const values = Object.values(updateData);
  const setClause = fields.map((field, i) => `${field} = $${i + 2}`).join(", ");

  const country = await sql(
    `
    UPDATE countries 
    SET ${setClause}
    WHERE id = $1
    RETURNING *
  `,
    [id, ...values]
  );

  if (country.length === 0) {
    return { error: "Country not found" };
  }

  return country[0];
}