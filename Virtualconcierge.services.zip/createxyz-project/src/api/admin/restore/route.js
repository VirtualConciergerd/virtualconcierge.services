async function handler({ backup_id }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!backup_id) {
    return { error: "Backup ID is required" };
  }

  try {
    const [backup] = await sql`
      SELECT metadata FROM system_backups 
      WHERE id = ${backup_id} AND status = 'completed'
    `;

    if (!backup?.metadata) {
      return { error: "Backup not found or incomplete" };
    }

    const results = await sql.transaction(async (sql) => {
      await sql`
        INSERT INTO system_backups (backup_date, backup_type, status, metadata)
        SELECT 
          NOW(),
          'pre_restore_backup',
          'completed',
          (
            SELECT json_build_object(
              'businesses', COALESCE((SELECT json_agg(b.*) FROM businesses b), '[]'::json),
              'regions', COALESCE((SELECT json_agg(r.*) FROM regions r), '[]'::json), 
              'backup_date', NOW()
            )
          )
      `;

      await sql`TRUNCATE businesses CASCADE`;

      if (backup.metadata.businesses?.length > 0) {
        const columns = [
          "name",
          "type",
          "contact_name",
          "email",
          "phone",
          "address",
          "website",
          "status",
          "country_id",
          "region_id",
          "created_at",
        ];

        const values = backup.metadata.businesses.map((b) =>
          columns.map((col) => b[col])
        );

        const placeholders = values
          .map(
            (_, i) =>
              `(${columns
                .map((_, j) => `$${i * columns.length + j + 1}`)
                .join(",")})`
          )
          .join(",");

        const query = `
          INSERT INTO businesses (${columns.join(",")})
          VALUES ${placeholders}
        `;

        await sql(query, values.flat());
      }

      return { success: true };
    });

    return {
      ...results,
      message: "Restore completed successfully",
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Restore error:", error);
    return { error: "Restore failed" };
  }
}