async function handler() {
  const testCases = {
    countryTests: [
      {
        name: "Valid country data",
        data: {
          name: "Test Country",
          code: "TC",
          currency: "USD",
          language: "en",
          emergency_number: "911",
          timezone: "UTC",
        },
        expectSuccess: true,
      },
      {
        name: "Invalid country code",
        data: {
          name: "Test Country",
          code: "123",
          currency: "USD",
        },
        expectSuccess: false,
      },
      {
        name: "Invalid currency",
        data: {
          name: "Test Country",
          code: "TC",
          currency: "USDD",
        },
        expectSuccess: false,
      },
    ],
  };

  try {
    const results = {
      timestamp: new Date(),
      tests: {},
      status: "pass",
    };

    // Run country validation tests
    for (const test of testCases.countryTests) {
      try {
        const response = await fetch("/api/admin/countries/create", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(test.data),
        });
        const success = response.ok === test.expectSuccess;
        results.tests[test.name] = {
          passed: success,
          expected: test.expectSuccess,
          received: response.ok,
        };
        if (!success) results.status = "fail";
      } catch (e) {
        results.tests[test.name] = {
          passed: false,
          error: e.message,
        };
        results.status = "fail";
      }
    }

    // Test rate limiting
    try {
      const requests = Array.from({ length: 102 })
        .fill(null)
        .map(() =>
          fetch("/api/admin/countries/create", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name: "Test Country",
              code: "TC",
            }),
          })
        );

      const responses = await Promise.all(requests);
      const rateLimitPassed = responses[101].status === 429;

      results.tests["Rate Limiting"] = {
        passed: rateLimitPassed,
        description: "Verified 429 response after limit exceeded",
      };
      if (!rateLimitPassed) results.status = "fail";
    } catch (e) {
      results.tests["Rate Limiting"] = {
        passed: false,
        error: e.message,
      };
      results.status = "fail";
    }

    // Database constraint tests
    try {
      const nameLengthTest = await sql(
        "INSERT INTO countries (name, code) VALUES ($1, $2)",
        ["x".repeat(101), "TC"]
      )
        .then(() => false)
        .catch(() => true);

      const uniqueCodeTest = await sql.transaction(async (txn) => {
        try {
          await txn(
            "INSERT INTO countries (name, code) VALUES ($1, $2), ($3, $4)",
            ["Test 1", "TC", "Test 2", "TC"]
          );
          return false;
        } catch {
          return true;
        }
      });

      const dbConstraintsPassed = nameLengthTest && uniqueCodeTest;

      results.tests["Database Constraints"] = {
        passed: dbConstraintsPassed,
        description: "Verified length and unique constraints",
      };
      if (!dbConstraintsPassed) results.status = "fail";
    } catch (e) {
      results.tests["Database Constraints"] = {
        passed: false,
        error: e.message,
      };
      results.status = "fail";
    }

    return results;
  } catch (error) {
    return {
      timestamp: new Date(),
      status: "error",
      error: error.message,
    };
  }
}