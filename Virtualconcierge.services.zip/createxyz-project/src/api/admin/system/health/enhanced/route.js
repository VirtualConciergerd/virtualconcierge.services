async function handler() {
  const edgeCaseTests = {
    specialChars: {
      name: "Test'Country;",
      code: "TC",
      expectSuccess: true,
    },
    unicode: {
      name: "测试国家",
      code: "TC",
      expectSuccess: true,
    },
    emptyVsNull: [
      {
        name: "",
        code: "TC",
        expectSuccess: false,
      },
      {
        name: "Test Country",
        code: "TC",
        currency: null,
        expectSuccess: true,
      },
    ],
    whitespace: {
      name: "  Test  Country  ",
      code: " TC ",
      expectSuccess: true,
    },
  };

  try {
    const results = {
      timestamp: new Date(),
      edgeCases: {},
      performance: {},
      dataConsistency: {},
      status: "pass",
    };

    const startTime = Date.now();

    const testQueries = [
      sql`SELECT COUNT(*) FROM countries`,
      sql`SELECT COUNT(*) FROM regions`,
      sql`SELECT COUNT(*) FROM emergency_services`,
    ];

    const dbCounts = await sql.transaction(async (txn) => {
      const results = await Promise.all(testQueries.map((query) => txn(query)));
      return results;
    });

    results.performance.queryTime = Date.now() - startTime;
    results.performance.passed = results.performance.queryTime < 1000;

    results.dataConsistency.counts = {
      countries: dbCounts[0][0].count,
      regions: dbCounts[1][0].count,
      emergencyServices: dbCounts[2][0].count,
    };

    const constraintTest = await sql.transaction(async (txn) => {
      try {
        await txn("INSERT INTO countries (name, code) VALUES ($1, $2)", [
          "Test Special",
          "@#",
        ]);
        return false;
      } catch (e) {
        return true;
      }
    });

    results.edgeCases["Constraint Validation"] = {
      passed: constraintTest,
      details: "Country code constraint test",
    };

    const duplicateTest = await sql.transaction(async (txn) => {
      try {
        await txn(
          "INSERT INTO countries (name, code) VALUES ($1, $2), ($3, $2)",
          ["Test Country 1", "XX", "Test Country 2"]
        );
        return false;
      } catch (e) {
        return true;
      }
    });

    results.edgeCases["Duplicate Prevention"] = {
      passed: duplicateTest,
      details: "Unique code constraint test",
    };

    const nullTest = await sql.transaction(async (txn) => {
      try {
        await txn("INSERT INTO countries (name, code) VALUES ($1, $2)", [
          null,
          "YY",
        ]);
        return false;
      } catch (e) {
        return true;
      }
    });

    results.edgeCases["Null Handling"] = {
      passed: nullTest,
      details: "Not null constraint test",
    };

    results.status =
      Object.values(results.edgeCases).every((test) => test.passed) &&
      results.performance.passed
        ? "pass"
        : "fail";

    return results;
  } catch (error) {
    return {
      timestamp: new Date(),
      status: "error",
      error: error.message,
    };
  }
}