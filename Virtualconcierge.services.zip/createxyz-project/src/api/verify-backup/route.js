async function handler() {
  try {
    const tableQueries = [
      sql`SELECT COUNT(*), MIN(created_at) as oldest, MAX(created_at) as newest FROM countries`,
      sql`SELECT COUNT(*), MIN(created_at) as oldest, MAX(created_at) as newest FROM regions`,
      sql`SELECT COUNT(*), MIN(created_at) as oldest, MAX(created_at) as newest FROM attractions`,
      sql`SELECT COUNT(*), MIN(created_at) as oldest, MAX(created_at) as newest FROM accommodations`,
      sql`SELECT COUNT(*), MIN(created_at) as oldest, MAX(created_at) as newest FROM admin_audit_log`,
      sql`SELECT COUNT(*) as orphaned_count
          FROM admin_audit_log a 
          LEFT JOIN countries c ON a.entity_id = c.id 
          WHERE a.entity_type = 'country' AND c.id IS NULL`,
      sql`SELECT tablename, indexname FROM pg_indexes WHERE schemaname = 'public'`,
      sql`SELECT conname, contype FROM pg_constraint WHERE connamespace = 'public'::regnamespace`,
    ];

    const [
      countries,
      regions,
      attractions,
      accommodations,
      auditLog,
      orphaned,
      indexes,
      constraints,
    ] = await sql.transaction(tableQueries);

    const tables = {
      countries: {
        count: Number(countries[0].count),
        oldest: countries[0].oldest,
        newest: countries[0].newest,
        status: Number(countries[0].count) > 0 ? "ok" : "empty",
      },
      regions: {
        count: Number(regions[0].count),
        oldest: regions[0].oldest,
        newest: regions[0].newest,
        status: Number(regions[0].count) > 0 ? "ok" : "empty",
      },
      attractions: {
        count: Number(attractions[0].count),
        oldest: attractions[0].oldest,
        newest: attractions[0].newest,
        status: Number(attractions[0].count) > 0 ? "ok" : "empty",
      },
      accommodations: {
        count: Number(accommodations[0].count),
        oldest: accommodations[0].oldest,
        newest: accommodations[0].newest,
        status: Number(accommodations[0].count) > 0 ? "ok" : "empty",
      },
    };

    const report = {
      timestamp: new Date(),
      tables,
      auditLog: {
        count: Number(auditLog[0].count),
        oldest: auditLog[0].oldest,
        newest: auditLog[0].newest,
      },
      orphanedRecords: Number(orphaned[0].orphaned_count),
      indexes: indexes,
      constraints: constraints,
      status: "healthy",
    };

    const warnings = [];
    if (orphaned[0].orphaned_count > 0) {
      warnings.push("Orphaned audit records detected");
    }

    Object.entries(tables).forEach(([name, data]) => {
      if (data.status === "empty") {
        warnings.push(`Table ${name} is empty`);
      }
    });

    if (warnings.length > 0) {
      report.status = "warning";
      report.warnings = warnings;
    }

    return report;
  } catch (error) {
    return { error: "Backup verification failed" };
  }
}