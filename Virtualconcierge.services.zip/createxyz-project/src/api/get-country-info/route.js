async function handler({ countryCode }) {
  try {
    // Default to Dominican Republic if no country code provided
    if (!countryCode) {
      countryCode = "DO";
    }

    const countries = await sql`
      SELECT * FROM countries 
      WHERE code = ${countryCode}
    `;

    if (countries.length === 0) {
      return {
        error: "Country not found",
      };
    }

    return {
      country: countries[0],
    };
  } catch (err) {
    return {
      error: "Failed to fetch country information",
    };
  }
}