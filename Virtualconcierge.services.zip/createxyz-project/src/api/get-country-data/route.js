async function handler({ countryId }) {
  const [country, regions, attractions, accommodations] = await sql.transaction(
    [
      sql`SELECT * FROM countries WHERE id = ${countryId}`,
      sql`SELECT * FROM regions WHERE country_id = ${countryId}`,
      sql`SELECT * FROM attractions WHERE country_id = ${countryId}`,
      sql`SELECT * FROM accommodations WHERE country_id = ${countryId}`,
    ]
  );

  return {
    country: country[0] || null,
    regions,
    attractions,
    accommodations,
  };
}