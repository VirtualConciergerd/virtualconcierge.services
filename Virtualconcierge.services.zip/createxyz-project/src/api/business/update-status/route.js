async function handler({ businessId, status, notes }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!businessId || !status) {
    return { error: "Missing required fields" };
  }

  if (!["approved", "rejected", "pending"].includes(status)) {
    return { error: "Invalid status" };
  }

  try {
    const businesses = await sql`
      SELECT * FROM businesses 
      WHERE id = ${businessId}
    `;

    if (!businesses[0]) {
      return { error: "Business not found" };
    }

    await sql.transaction(async (sql) => [
      sql`
        UPDATE businesses 
        SET 
          status = ${status},
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${businessId}
      `,
      sql`
        INSERT INTO admin_audit_log 
        (user_id, action, entity_type, entity_id, changes)
        VALUES 
        (${
          session.user.id
        }, 'update_business_status', 'business', ${businessId}, ${JSON.stringify(
        { status, notes }
      )})
      `,
    ]);

    await fetch("/api/send-business-status-email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ businessId, status }),
    });

    return { success: true, business: businesses[0] };
  } catch (error) {
    return { error: error.message };
  }
}