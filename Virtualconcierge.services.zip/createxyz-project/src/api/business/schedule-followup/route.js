async function handler({ body }) {
  const { businessId } = body;

  if (!businessId) {
    return { error: "Business ID is required" };
  }

  try {
    // Set follow-up date
    await sql`
      UPDATE businesses 
      SET follow_up_date = CURRENT_TIMESTAMP + interval '3 days'
      WHERE id = ${businessId}
    `;

    // Get business details
    const businesses = await sql`
      SELECT name, contact_name, email 
      FROM businesses 
      WHERE id = ${businessId}
    `;

    if (!businesses.length) {
      return { error: "Business not found" };
    }

    // Send immediate notification about the scheduled follow-up
    await fetch("/api/send-business-status-email", {
      method: "POST",
      body: JSON.stringify({
        businessId,
        status: "pending",
        notes: "Your application is still under review.",
        customInstructions:
          "We will follow up with you in 3 days if we need any additional information.",
      }),
    });

    return {
      success: true,
      message: "Follow-up scheduled successfully",
    };
  } catch (error) {
    return {
      error: "Failed to schedule follow-up",
      details: error.message,
    };
  }
}