async function handler({ body }) {
  const { businessId, status, notes, customInstructions } = body;

  if (!businessId || !status) {
    return { error: "Business ID and status are required" };
  }

  if (!["approved", "rejected", "pending"].includes(status)) {
    return { error: "Invalid status value" };
  }

  try {
    const session = getSession();

    const businesses = await sql`
      SELECT b.*, u.language 
      FROM businesses b
      LEFT JOIN users u ON b.user_id = u.id
      WHERE b.id = ${businessId}
    `;

    if (!businesses.length) {
      return { error: "Business not found" };
    }

    const business = businesses[0];

    const templateResponse = await fetch("/api/get-email-template", {
      method: "POST",
      body: JSON.stringify({
        businessType: business.type,
        status,
        languageCode: business.language || "en",
      }),
    });

    const templateData = await templateResponse.json();

    if (templateData.error) {
      await fetch("/api/seed-email-templates", { method: "POST" });
      return {
        error:
          "Templates not found - seeded default templates. Please try again.",
      };
    }

    let emailBody = templateData.body
      .replace("{businessName}", business.name)
      .replace("{contactName}", business.contact_name);

    if (notes) {
      emailBody += `
        <div class="feedback-section">
          <h3>Additional Notes:</h3>
          <div style="background: #f8f9fa; padding: 15px; border-radius: 5px;">
            ${notes}
          </div>
        </div>
      `;
    }

    if (customInstructions) {
      emailBody += `
        <div class="instructions-section">
          <h3>Special Instructions:</h3>
          <div style="background: #f8f9fa; padding: 15px; border-radius: 5px;">
            ${customInstructions}
          </div>
        </div>
      `;
    }

    await fetch("https://api.resend.com/v1/email/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Virtual Concierge <no-reply@virtualconcierge.services>",
        to: business.email,
        subject: templateData.subject,
        html: emailBody,
      }),
    });

    await sql`
      INSERT INTO admin_audit_log 
        (user_id, action, entity_type, entity_id, changes)
      VALUES 
        (${session.user.id}, 'send_email', 'business', ${businessId}, 
         ${JSON.stringify({ status, templateUsed: templateData.id })})
    `;

    return { success: true };
  } catch (error) {
    return { error: "Failed to send email notification" };
  }
}