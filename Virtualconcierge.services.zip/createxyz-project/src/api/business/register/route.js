async function handler({
  businessName,
  businessType,
  contactName,
  email,
  phone,
  address,
  website,
}) {
  const session = getSession();

  try {
    if (
      !businessName ||
      !businessType ||
      !contactName ||
      !email ||
      !phone ||
      !address
    ) {
      return { error: "Missing required fields" };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return { error: "Invalid email format" };
    }

    const phoneRegex = /^\+?[\d\s-()]+$/;
    if (!phoneRegex.test(phone)) {
      return { error: "Invalid phone format" };
    }

    if (website && !website.startsWith("http")) {
      website = "https://" + website;
    }

    const [business] = await sql`
      INSERT INTO businesses (
        name,
        type,
        contact_name,
        email,
        phone,
        address,
        website,
        status,
        created_at,
        updated_at
      ) VALUES (
        ${businessName},
        ${businessType},
        ${contactName},
        ${email},
        ${phone},
        ${address},
        ${website || null},
        'pending',
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP
      )
      RETURNING *
    `;

    if (!business) {
      throw new Error("Failed to insert business");
    }

    return {
      success: true,
      business,
    };
  } catch (error) {
    console.error("Business registration error:", error);
    return {
      error: "Failed to register business. Please try again later.",
      details: error.message,
    };
  }
}