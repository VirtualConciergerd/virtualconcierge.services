async function handler({ action, data }) {
  if (action !== "submit") {
    return { error: "Invalid action" };
  }

  const { name, email, subject, message } = data;

  if (!name || typeof name !== "string" || name.length < 2) {
    return { error: "Name must be at least 2 characters long" };
  }

  if (
    !email ||
    typeof email !== "string" ||
    !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)
  ) {
    return { error: "Invalid email address" };
  }

  if (!message || typeof message !== "string" || message.length < 10) {
    return { error: "Message must be at least 10 characters long" };
  }

  try {
    const result = await sql`
      INSERT INTO contact_submissions (
        name,
        email,
        message,
        status
      ) VALUES (
        ${name},
        ${email},
        ${message},
        'new'
      ) RETURNING id`;

    await sql`
      INSERT INTO chat_history (
        message,
        response
      ) VALUES (
        ${`Contact form submission from ${name} (${email}): ${
          subject ? `[${subject}] ` : ""
        }${message}`},
        'Contact form submitted successfully'
      )`;

    return {
      success: true,
      message: "Thank you for your message. We'll get back to you soon!",
      id: result[0].id,
    };
  } catch (err) {
    console.error("Contact form submission error:", err);
    return {
      error: "Failed to submit form. Please try again later.",
      details: process.env.NODE_ENV === "development" ? err.message : undefined,
    };
  }
}