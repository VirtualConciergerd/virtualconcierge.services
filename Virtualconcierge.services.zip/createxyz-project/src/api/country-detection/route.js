async function handler({ headers }) {
  const ipAddress = headers?.["x-forwarded-for"] || "127.0.0.1";

  // Try to find country matching IP
  const matchingCountries = await sql`
    SELECT * 
    FROM countries 
    WHERE ${ipAddress} = ANY(ip_ranges)
    AND active = true
    LIMIT 1
  `;

  if (matchingCountries.length > 0) {
    return matchingCountries[0];
  }

  // Default to first active country if no match
  const defaultCountries = await sql`
    SELECT * 
    FROM countries
    WHERE active = true
    ORDER BY sort_order ASC, name ASC
    LIMIT 1
  `;

  return defaultCountries[0] || null;
}