async function handler({ countryId, provinceId, limit = 10 }) {
  try {
    const attractions = await sql(
      `
      SELECT 
        a.*,
        r.name as region_name,
        c.name as country_name
      FROM attractions a
      LEFT JOIN regions r ON a.province_id = r.id
      LEFT JOIN countries c ON a.country_id = c.id
      WHERE 
        ($1::integer IS NULL OR a.country_id = $1) AND
        ($2::integer IS NULL OR a.province_id = $2)
      ORDER BY a.average_rating DESC NULLS LAST, a.total_reviews DESC
      LIMIT $3
    `,
      [countryId, provinceId, limit]
    );

    return { attractions };
  } catch (error) {
    return { error: "Failed to fetch top attractions" };
  }
}