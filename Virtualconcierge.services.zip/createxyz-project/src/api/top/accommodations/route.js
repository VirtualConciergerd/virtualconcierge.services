async function handler({ countryId, provinceId, type, limit = 10 }) {
  try {
    const accommodations = await sql(
      `SELECT 
        a.*,
        r.name as region_name,
        c.name as country_name
      FROM accommodations a
      LEFT JOIN regions r ON a.province_id = r.id
      LEFT JOIN countries c ON a.country_id = c.id
      WHERE 
        ($1::integer IS NULL OR a.country_id = $1) AND
        ($2::integer IS NULL OR a.province_id = $2) AND
        ($3::varchar IS NULL OR a.accommodation_type = $3)
      ORDER BY a.average_rating DESC NULLS LAST, a.total_reviews DESC
      LIMIT $4`,
      [countryId, provinceId, type, limit]
    );

    return { accommodations };
  } catch (error) {
    return { error: "Failed to fetch top accommodations" };
  }
}