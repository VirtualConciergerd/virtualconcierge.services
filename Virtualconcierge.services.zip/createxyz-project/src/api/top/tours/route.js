async function handler({ countryId, provinceId, limit = 10 }) {
  try {
    const tours = await sql(
      `SELECT 
        t.*,
        r.name as region_name,
        c.name as country_name
      FROM tours t
      LEFT JOIN regions r ON t.province_id = r.id
      LEFT JOIN countries c ON t.country_id = c.id
      WHERE 
        ($1::integer IS NULL OR t.country_id = $1) AND
        ($2::integer IS NULL OR t.province_id = $2)
      ORDER BY t.average_rating DESC NULLS LAST, t.total_reviews DESC
      LIMIT $3`,
      [countryId, provinceId, limit]
    );

    return { tours };
  } catch (error) {
    return { error: "Failed to fetch top tours" };
  }
}