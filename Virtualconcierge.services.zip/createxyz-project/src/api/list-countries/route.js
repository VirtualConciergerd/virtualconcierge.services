async function handler() {
  try {
    const countries = await sql`
      SELECT * FROM countries 
      ORDER BY name
    `;

    return {
      countries,
    };
  } catch (err) {
    return {
      error: "Failed to fetch countries",
    };
  }
}