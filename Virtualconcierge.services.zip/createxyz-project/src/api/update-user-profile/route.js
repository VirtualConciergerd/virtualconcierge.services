async function handler({ name, email, phone, timezone, avatar_url }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "Invalid email format" };
  }

  if (phone && !/^\+?[\d\s-()]{8,}$/.test(phone)) {
    return { error: "Invalid phone number format" };
  }

  if (timezone && !/^[A-Za-z_\/+-]+(?:\/[A-Za-z_]+)*$/.test(timezone)) {
    return { error: "Invalid timezone format" };
  }

  const updates = [];
  const values = [];
  let paramCount = 1;

  if (name) {
    updates.push(`name = $${paramCount}`);
    values.push(name);
    paramCount++;
  }

  if (email) {
    updates.push(`email = $${paramCount}`);
    values.push(email);
    paramCount++;
  }

  if (phone) {
    updates.push(`phone = $${paramCount}`);
    values.push(phone);
    paramCount++;
  }

  if (timezone) {
    updates.push(`timezone = $${paramCount}`);
    values.push(timezone);
    paramCount++;
  }

  if (avatar_url) {
    updates.push(`avatar_url = $${paramCount}`);
    values.push(avatar_url);
    paramCount++;
  }

  if (updates.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(session.user.id);

  const query = `
    UPDATE auth_users 
    SET ${updates.join(", ")}, 
    updated_at = CURRENT_TIMESTAMP 
    WHERE id = $${paramCount} 
    RETURNING id, name, email, avatar_url
  `;

  try {
    const [updatedUser] = await sql(query, values);

    if (!updatedUser) {
      return { error: "Failed to update user profile" };
    }

    return {
      success: true,
      user: updatedUser,
    };
  } catch (error) {
    return { error: "Database error occurred" };
  }
}