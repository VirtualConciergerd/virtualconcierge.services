async function handler({ action, userId, provider, accountData, accountId }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    switch (action) {
      case "list":
        const accounts = await sql`
          SELECT id, provider, provider_account_id, is_verified, profile_data, created_at 
          FROM connected_accounts 
          WHERE user_id = ${session.user.id}
        `;
        return { accounts };

      case "connect":
        if (!provider || !accountData) {
          return { error: "Missing required fields" };
        }

        const existingAccount = await sql`
          SELECT id FROM connected_accounts 
          WHERE user_id = ${session.user.id} 
          AND provider = ${provider}
        `;

        if (existingAccount.length > 0) {
          return { error: "Account already connected" };
        }

        const [newAccount] = await sql`
          INSERT INTO connected_accounts (
            user_id, 
            provider, 
            provider_account_id,
            provider_token,
            profile_data,
            is_verified
          )
          VALUES (
            ${session.user.id},
            ${provider},
            ${accountData.id},
            ${accountData.token},
            ${accountData.profile || {}},
            ${false}
          )
          RETURNING id, provider, is_verified
        `;
        return { account: newAccount };

      case "disconnect":
        if (!accountId) {
          return { error: "Account ID required" };
        }

        await sql`
          DELETE FROM connected_accounts 
          WHERE id = ${accountId} 
          AND user_id = ${session.user.id}
        `;
        return { success: true };

      case "verify":
        if (!accountId) {
          return { error: "Account ID required" };
        }

        const [verifiedAccount] = await sql`
          UPDATE connected_accounts 
          SET is_verified = true,
          updated_at = CURRENT_TIMESTAMP
          WHERE id = ${accountId} 
          AND user_id = ${session.user.id}
          RETURNING id, provider, is_verified
        `;
        return { account: verifiedAccount };

      case "update":
        if (!accountId || !accountData) {
          return { error: "Account ID and update data required" };
        }

        const [updatedAccount] = await sql`
          UPDATE connected_accounts 
          SET 
            profile_data = ${accountData.profile || {}},
            provider_token = COALESCE(${accountData.token}, provider_token),
            updated_at = CURRENT_TIMESTAMP
          WHERE id = ${accountId} 
          AND user_id = ${session.user.id}
          RETURNING id, provider, is_verified, profile_data
        `;
        return { account: updatedAccount };

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    console.error("Connected accounts error:", error);
    return { error: "Failed to process request" };
  }
}