async function handler({ action, data }) {
  const session = getSession();
  if (!session) {
    return { error: "Authentication required" };
  }

  const userId = session.user?.id;

  try {
    switch (action) {
      case "getCart":
        const cartItems = await sql`
          SELECT ci.*, p.name, p.price, p.image_url 
          FROM cart_items ci
          JOIN products p ON ci.product_id = p.id 
          WHERE ci.user_id = ${userId}
        `;
        return { items: cartItems };

      case "addToCart": {
        const { productId, quantity } = data;

        const result = await sql`
          INSERT INTO cart_items (user_id, product_id, quantity)
          VALUES (${userId}, ${productId}, ${quantity})
          ON CONFLICT (user_id, product_id) 
          DO UPDATE SET quantity = cart_items.quantity + ${quantity}
          RETURNING *
        `;
        return { item: result[0] };
      }

      case "updateQuantity": {
        const { itemId, quantity } = data;

        if (quantity <= 0) {
          await sql`
            DELETE FROM cart_items 
            WHERE id = ${itemId} AND user_id = ${userId}
          `;
          return { success: true };
        }

        const result = await sql`
          UPDATE cart_items 
          SET quantity = ${quantity}
          WHERE id = ${itemId} AND user_id = ${userId}
          RETURNING *
        `;
        return { item: result[0] };
      }

      case "clearCart":
        await sql`
          DELETE FROM cart_items 
          WHERE user_id = ${userId}
        `;
        return { success: true };

      default:
        return { error: "Invalid action" };
    }
  } catch (err) {
    console.error("Cart management error:", err);
    return { error: "Failed to process cart action" };
  }
}