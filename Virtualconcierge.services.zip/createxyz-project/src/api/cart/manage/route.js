async function handler({ action, productId, quantity, cartId }) {
  const session = getSession();
  const userId = session?.user?.id;

  if (!action) {
    return { error: "Action is required" };
  }

  switch (action) {
    case "get": {
      const cart = await sql`
        SELECT cart_data 
        FROM saved_carts 
        WHERE user_id = ${userId} 
        ORDER BY updated_at DESC 
        LIMIT 1
      `;
      return cart?.[0]?.cart_data || { items: [], total: 0, tax: 0 };
    }

    case "add": {
      if (!productId || !quantity) {
        return { error: "Product ID and quantity are required" };
      }

      // Get product details and validate availability
      const products = await sql`
        SELECT id, price, name 
        FROM products 
        WHERE id = ${productId}
      `;

      if (!products.length) {
        return { error: "Product not found" };
      }

      const product = products[0];

      // Get existing cart or create new
      const existingCart = await sql`
        SELECT id, cart_data 
        FROM saved_carts 
        WHERE user_id = ${userId} 
        ORDER BY updated_at DESC 
        LIMIT 1
      `;

      const cartData = existingCart?.[0]?.cart_data || {
        items: [],
        total: 0,
        tax: 0,
      };
      const existingItem = cartData.items.find(
        (item) => item.productId === productId
      );

      if (existingItem) {
        existingItem.quantity += quantity;
        if (existingItem.quantity > 10) existingItem.quantity = 10;
      } else {
        cartData.items.push({
          productId,
          name: product.name,
          price: product.price,
          quantity: Math.min(quantity, 10),
        });
      }

      // Calculate totals
      cartData.total = cartData.items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      );
      cartData.tax = cartData.total * 0.1; // 10% tax rate

      if (existingCart?.[0]?.id) {
        await sql`
          UPDATE saved_carts 
          SET cart_data = ${cartData}, updated_at = CURRENT_TIMESTAMP 
          WHERE id = ${existingCart[0].id}
        `;
      } else {
        await sql`
          INSERT INTO saved_carts (user_id, cart_data) 
          VALUES (${userId}, ${cartData})
        `;
      }

      return cartData;
    }

    case "update": {
      if (!productId || typeof quantity !== "number") {
        return { error: "Product ID and quantity are required" };
      }

      const cart = await sql`
        SELECT id, cart_data 
        FROM saved_carts 
        WHERE user_id = ${userId} 
        ORDER BY updated_at DESC 
        LIMIT 1
      `;

      if (!cart?.[0]) {
        return { error: "Cart not found" };
      }

      const cartData = cart[0].cart_data;

      if (quantity === 0) {
        cartData.items = cartData.items.filter(
          (item) => item.productId !== productId
        );
      } else {
        const item = cartData.items.find(
          (item) => item.productId === productId
        );
        if (item) {
          item.quantity = Math.min(Math.max(quantity, 0), 10);
        }
      }

      cartData.total = cartData.items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      );
      cartData.tax = cartData.total * 0.1;

      await sql`
        UPDATE saved_carts 
        SET cart_data = ${cartData}, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ${cart[0].id}
      `;

      return cartData;
    }

    case "clear": {
      await sql`
        DELETE FROM saved_carts 
        WHERE user_id = ${userId}
      `;
      return { items: [], total: 0, tax: 0 };
    }

    default:
      return { error: "Invalid action" };
  }
}