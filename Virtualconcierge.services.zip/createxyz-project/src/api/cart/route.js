async function handler({ action, data }) {
  try {
    switch (action) {
      case "addItem": {
        const { userId, itemId, quantity = 1 } = data;
        const existingItem = await sql(
          "SELECT * FROM cart_items WHERE user_id = $1 AND item_id = $2",
          [userId, itemId]
        );

        if (existingItem.length > 0) {
          const newQuantity = existingItem[0].quantity + quantity;
          await sql(
            "UPDATE cart_items SET quantity = $1 WHERE user_id = $2 AND item_id = $3",
            [newQuantity, userId, itemId]
          );
        } else {
          await sql(
            "INSERT INTO cart_items (user_id, item_id, quantity) VALUES ($1, $2, $3)",
            [userId, itemId, quantity]
          );
        }
        return { success: true };
      }

      case "removeItem": {
        const { userId, itemId } = data;
        await sql(
          "DELETE FROM cart_items WHERE user_id = $1 AND item_id = $2",
          [userId, itemId]
        );
        return { success: true };
      }

      case "updateQuantity": {
        const { userId, itemId, quantity } = data;
        if (quantity <= 0) {
          await sql(
            "DELETE FROM cart_items WHERE user_id = $1 AND item_id = $2",
            [userId, itemId]
          );
        } else {
          await sql(
            "UPDATE cart_items SET quantity = $1 WHERE user_id = $2 AND item_id = $3",
            [quantity, userId, itemId]
          );
        }
        return { success: true };
      }

      case "getCart": {
        const { userId } = data;
        const cartItems = await sql(
          `
          SELECT ci.*, i.name, i.price, i.image_url 
          FROM cart_items ci
          JOIN items i ON ci.item_id = i.id
          WHERE ci.user_id = $1
        `,
          [userId]
        );

        return { items: cartItems };
      }

      case "clearCart": {
        const { userId } = data;
        await sql("DELETE FROM cart_items WHERE user_id = $1", [userId]);
        return { success: true };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    return { error: "Failed to process cart operation" };
  }
}