async function handler({ headers }) {
  try {
    const ip = headers["x-forwarded-for"] || headers["x-real-ip"] || "0.0.0.0";

    const country = await sql`
      SELECT id, name, code, theme_settings
      FROM countries 
      WHERE active = true
      AND ip_ranges @> ARRAY[${ip}]::text[]
      LIMIT 1
    `;

    if (country.length === 0) {
      const defaultCountry = await sql`
        SELECT id, name, code, theme_settings
        FROM countries
        WHERE active = true
        ORDER BY sort_order ASC, name ASC
        LIMIT 1
      `;

      return defaultCountry[0] || null;
    }

    return country[0];
  } catch (error) {
    console.error("Country detection error:", error);
    return null;
  }
}