async function handler() {
  const config = {
    required: {
      DATABASE_URL: {
        value: process.env.DATABASE_URL,
        validate: (v) =>
          v?.startsWith("postgres://") || v?.startsWith("postgresql://"),
        feature: "database",
      },
      AUTH_SECRET: {
        value: process.env.AUTH_SECRET,
        validate: (v) => v?.length >= 32,
        feature: "authentication",
      },
    },
    optional: {
      PIXABAY_API_KEY: {
        value: process.env.PIXABAY_API_KEY,
        validate: (v) => v?.length === 40,
        default: "",
        feature: "image-search",
      },
      REPLICATE_API_TOKEN: {
        value: process.env.REPLICATE_API_TOKEN,
        validate: (v) => v?.startsWith("r8_"),
        default: "",
        feature: "ai-image-processing",
      },
      EMAIL_SERVICE_API_KEY: {
        value: process.env.EMAIL_SERVICE_API_KEY,
        validate: (v) => v?.length > 0,
        default: "",
        feature: "email-notifications",
      },
      RATE_LIMIT_MAX: {
        value: process.env.RATE_LIMIT_MAX,
        validate: (v) => !isNaN(v) && parseInt(v) > 0,
        default: "100",
        feature: "rate-limiting",
      },
      QUEUE_MAX_SIZE: {
        value: process.env.QUEUE_MAX_SIZE,
        validate: (v) => !isNaN(v) && parseInt(v) > 0,
        default: "1000",
        feature: "queue-management",
      },
      NODE_ENV: {
        value: process.env.NODE_ENV,
        validate: (v) => ["development", "production", "test"].includes(v),
        default: "development",
        feature: "environment",
      },
    },
  };

  const missing = [];
  const invalid = [];
  const services = [];
  const features = {
    required: {},
    optional: {},
  };

  for (const [key, conf] of Object.entries(config.required)) {
    if (!conf.value) {
      missing.push(key);
      features.required[conf.feature] = { available: false, reason: "missing" };
    } else if (!conf.validate(conf.value)) {
      invalid.push(key);
      features.required[conf.feature] = { available: false, reason: "invalid" };
    } else {
      features.required[conf.feature] = { available: true };
    }
  }

  for (const [key, conf] of Object.entries(config.optional)) {
    const value = conf.value || conf.default;
    if (!value || !conf.validate(value)) {
      console.log(
        `Optional feature '${conf.feature}' disabled due to missing or invalid ${key}`
      );
      features.optional[conf.feature] = {
        available: false,
        reason: !conf.value ? "missing" : "invalid",
        defaultUsed: !conf.value,
      };
    } else {
      features.optional[conf.feature] = {
        available: true,
        defaultUsed: !conf.value,
      };
    }
  }

  try {
    const [healthResponse, rateResponse, queueResponse] = await Promise.all([
      fetch("/api/health-check", { method: "POST" }),
      fetch("/api/api-rate-limiter", {
        method: "POST",
        body: JSON.stringify({
          ip: "127.0.0.1",
          endpoint: "/api/config/validate",
        }),
      }),
      fetch("/api/queue-monitor", { method: "POST" }),
    ]);

    const serviceStatus = {
      "health-check": healthResponse.ok,
      "rate-limiter": rateResponse.ok,
      "queue-monitor": queueResponse.ok,
      database: true,
    };

    if (process.env.DATABASE_URL) {
      try {
        await sql`SELECT 1`;
      } catch (err) {
        serviceStatus.database = false;
        services.push("database");
      }
    }

    for (const [service, ok] of Object.entries(serviceStatus)) {
      if (!ok) services.push(service);
    }
  } catch (error) {
    services.push("api-services");
  }

  const isValid = missing.length === 0 && invalid.length === 0;

  return {
    valid: isValid,
    environment: process.env.NODE_ENV || "development",
    features: {
      ...features,
      serviceStatus: services.length === 0 ? "healthy" : "degraded",
    },
    status: {
      missingRequired: missing,
      invalidConfig: invalid,
      failedServices: services,
      message: [
        missing.length
          ? `Missing required variables: ${missing.join(", ")}`
          : "",
        invalid.length ? `Invalid variables: ${invalid.join(", ")}` : "",
        services.length ? `Failed services: ${services.join(", ")}` : "",
      ]
        .filter(Boolean)
        .join(". "),
    },
  };
}