async function handler({ countryId, countryCode }) {
  if (!countryId && !countryCode) {
    return { error: "Either Country ID or Country Code is required" };
  }

  try {
    const whereClause = countryId ? "c.id = $1" : "c.code = $1";
    const paramValue = countryId || countryCode;

    const result = await sql(
      `SELECT 
        c.*,
        COALESCE(json_agg(DISTINCT r.*) FILTER (WHERE r.id IS NOT NULL), '[]') as regions,
        COALESCE(json_agg(DISTINCT a.*) FILTER (WHERE a.id IS NOT NULL), '[]') as attractions,
        COALESCE(json_agg(DISTINCT acc.*) FILTER (WHERE acc.id IS NOT NULL), '[]') as accommodations,
        COALESCE(json_agg(DISTINCT es.*) FILTER (WHERE es.id IS NOT NULL), '[]') as emergency_services
      FROM countries c
      LEFT JOIN regions r ON r.country_id = c.id
      LEFT JOIN attractions a ON a.country_id = c.id
      LEFT JOIN accommodations acc ON acc.country_id = c.id
      LEFT JOIN emergency_services es ON es.country_id = c.id
      WHERE ${whereClause}
      GROUP BY c.id`,
      [paramValue]
    );

    if (!result || result.length === 0) {
      return { error: "Country not found" };
    }

    return { success: true, data: result[0] };
  } catch (error) {
    console.error("Error fetching country data:", error);
    return { error: "Failed to fetch country data" };
  }
}