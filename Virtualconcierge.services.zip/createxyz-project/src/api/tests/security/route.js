async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  async function testRateLimiting() {
    const testIP = "192.168.1.1";
    const responses = [];

    for (let i = 0; i < 6; i++) {
      const response = await fetch("/api/api-rate-limiter", {
        method: "POST",
        body: JSON.stringify({ ip: testIP, email: session.user.email }),
      });
      responses.push(await response.json());
    }

    return {
      name: "Rate Limiting Test",
      passed: responses[5].blocked === true,
      details: responses,
    };
  }

  async function testAuditLogging() {
    const response = await fetch("/api/security-audit-log", {
      method: "POST",
      body: JSON.stringify({ method: "POST" }),
    });
    const logs = await response.json();

    return {
      name: "Audit Logging Test",
      passed: Array.isArray(logs) && logs.length > 0,
      details: logs,
    };
  }

  async function testEmergencyNotifications() {
    const response = await fetch("/api/security-alert-notification", {
      method: "POST",
      body: JSON.stringify({
        type: "security_test",
        severity: "low",
        message: "Security integration test notification",
      }),
    });

    return {
      name: "Emergency Notifications Test",
      passed: response.ok,
      details: await response.json(),
    };
  }

  try {
    const testResults = await Promise.all([
      testRateLimiting(),
      testAuditLogging(),
      testEmergencyNotifications(),
    ]);

    await sql`
      INSERT INTO admin_audit_log 
      (user_id, action, entity_type, entity_id, changes)
      VALUES (
        ${session.user.id},
        'security_test',
        'system',
        NULL,
        ${JSON.stringify({ results: testResults })}
      )
    `;

    return {
      status: 200,
      body: {
        timestamp: new Date().toISOString(),
        executor: session.user.email,
        results: testResults,
        summary: {
          total: testResults.length,
          passed: testResults.filter((t) => t.passed).length,
          failed: testResults.filter((t) => !t.passed).length,
        },
      },
    };
  } catch (error) {
    await sql`
      INSERT INTO error_logs 
      (error_type, message, stack_trace, user_id)
      VALUES (
        'security_test_failure',
        ${error.message},
        ${error.stack},
        ${session.user.id}
      )
    `;

    return {
      status: 500,
      body: {
        error: "Security test execution failed",
        message: error.message,
      },
    };
  }
}