async function handler({ businessType, status, languageCode = "en" }) {
  if (!businessType || !status) {
    return { error: "Business type and status are required" };
  }

  let template = await sql`
    SELECT * FROM email_templates 
    WHERE business_type = ${businessType}
    AND status = ${status}
    AND language_code = ${languageCode}
  `;

  // If no template found and language isn't English, try English fallback
  if (template.length === 0 && languageCode !== "en") {
    template = await sql`
      SELECT * FROM email_templates 
      WHERE business_type = ${businessType}
      AND status = ${status}
      AND language_code = 'en'
    `;
  }

  return template[0] || { error: "No template found" };
}