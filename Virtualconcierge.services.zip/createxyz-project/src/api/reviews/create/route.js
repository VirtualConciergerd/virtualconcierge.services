async function handler({
  bookingId,
  serviceId,
  rating,
  reviewText,
  images = [],
}) {
  const session = getSession();
  if (!session?.user) {
    throw new Error("Authentication required");
  }

  try {
    // Verify the booking belongs to the user and is completed
    const bookings = await sql`
      SELECT * FROM bookings 
      WHERE id = ${bookingId} 
      AND user_id = ${session.user.id} 
      AND status = 'completed'
    `;

    if (!bookings[0]) {
      throw new Error("Invalid booking or booking not completed");
    }

    // Check if review already exists
    const existingReviews = await sql`
      SELECT id FROM service_reviews 
      WHERE booking_id = ${bookingId}
    `;

    if (existingReviews[0]) {
      throw new Error("Review already exists for this booking");
    }

    // Create review
    const [review] = await sql.transaction([
      sql`
        INSERT INTO service_reviews (
          booking_id,
          user_id,
          service_id,
          rating,
          review_text,
          images
        ) VALUES (
          ${bookingId}, 
          ${session.user.id}, 
          ${serviceId}, 
          ${rating}, 
          ${reviewText}, 
          ${images}
        )
        RETURNING *
      `,
      sql`
        UPDATE concierge_services 
        SET 
          average_rating = (
            SELECT AVG(rating)::numeric(3,2) 
            FROM service_reviews 
            WHERE service_id = ${serviceId} 
            AND status = 'active'
          ),
          total_reviews = (
            SELECT COUNT(*) 
            FROM service_reviews 
            WHERE service_id = ${serviceId} 
            AND status = 'active'
          )
        WHERE id = ${serviceId}
      `,
    ]);

    return review[0];
  } catch (error) {
    console.error("Review creation error:", error);
    throw new Error("Failed to create review");
  }
}