async function handler({ reviewId }) {
  const session = getSession();
  if (!session?.user) {
    throw new Error("Authentication required");
  }

  try {
    // Check if user has already marked this review as helpful
    const helpfulRecords = await sql`
      SELECT id FROM review_helpful_marks 
      WHERE review_id = ${reviewId} 
      AND user_id = ${session.user.id}
    `;

    if (helpfulRecords.length > 0) {
      throw new Error("Already marked as helpful");
    }

    // Use transaction to ensure both operations complete
    await sql.transaction([
      sql`
        INSERT INTO review_helpful_marks (review_id, user_id)
        VALUES (${reviewId}, ${session.user.id})
      `,
      sql`
        UPDATE service_reviews 
        SET helpful_count = helpful_count + 1 
        WHERE id = ${reviewId}
      `,
    ]);

    return { success: true };
  } catch (error) {
    console.error("Mark helpful error:", error);
    throw new Error("Failed to mark review as helpful");
  }
}