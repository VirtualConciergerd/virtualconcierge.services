async function handler({
  serviceId,
  page = 1,
  limit = 10,
  sortBy = "newest",
  filterRating,
}) {
  if (!serviceId) {
    throw new Error("Service ID is required");
  }

  const offset = (page - 1) * limit;
  const orderClause =
    sortBy === "helpful"
      ? "helpful_count DESC, created_at DESC"
      : sortBy === "highest"
      ? "rating DESC, created_at DESC"
      : sortBy === "lowest"
      ? "rating ASC, created_at DESC"
      : "created_at DESC";

  try {
    let reviews;
    let countResult;

    if (filterRating) {
      [reviews, countResult] = await sql.transaction([
        sql(
          `
          SELECT 
            sr.*,
            au.name as user_name,
            au.image as user_image,
            b.booking_date
          FROM service_reviews sr
          JOIN auth_users au ON sr.user_id = au.id
          JOIN bookings b ON sr.booking_id = b.id
          WHERE sr.service_id = $1 
          AND sr.status = 'active'
          AND sr.rating = $2
          ORDER BY ${orderClause}
          LIMIT $3 OFFSET $4
        `,
          [serviceId, filterRating, limit, offset]
        ),

        sql(
          `
          SELECT COUNT(*) 
          FROM service_reviews 
          WHERE service_id = $1 
          AND status = 'active'
          AND rating = $2
        `,
          [serviceId, filterRating]
        ),
      ]);
    } else {
      [reviews, countResult] = await sql.transaction([
        sql(
          `
          SELECT 
            sr.*,
            au.name as user_name,
            au.image as user_image,
            b.booking_date
          FROM service_reviews sr
          JOIN auth_users au ON sr.user_id = au.id
          JOIN bookings b ON sr.booking_id = b.id
          WHERE sr.service_id = $1 
          AND sr.status = 'active'
          ORDER BY ${orderClause}
          LIMIT $2 OFFSET $3
        `,
          [serviceId, limit, offset]
        ),

        sql(
          `
          SELECT COUNT(*) 
          FROM service_reviews 
          WHERE service_id = $1 
          AND status = 'active'
        `,
          [serviceId]
        ),
      ]);
    }

    return {
      reviews: reviews,
      total: parseInt(countResult[0].count),
      pages: Math.ceil(parseInt(countResult[0].count) / limit),
    };
  } catch (error) {
    console.error("Get reviews error:", error);
    throw new Error("Failed to fetch reviews");
  }
}