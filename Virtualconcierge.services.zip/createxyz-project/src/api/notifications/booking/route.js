async function handler({ bookingId, type, userId }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Authentication required" };
  }

  try {
    // Get booking and related details
    const [booking] = await sql`
      SELECT b.*, cs.name as service_name, cs.type as service_type,
        u.email, u.name as user_name
      FROM bookings b
      JOIN concierge_services cs ON b.service_id = cs.id
      JOIN auth_users u ON b.user_id = u.id
      WHERE b.id = ${bookingId}
    `;

    if (!booking) {
      return { error: "Booking not found" };
    }

    // Get email template
    const [template] = await sql`
      SELECT * FROM email_templates 
      WHERE business_type = ${booking.service_type} 
      AND status = ${type} 
      AND language_code = 'en'
    `;

    if (!template) {
      return { error: "Email template not found" };
    }

    // Send email notification
    const emailBody = template.body
      .replace("{{booking_id}}", bookingId)
      .replace("{{service_name}}", booking.service_name)
      .replace(
        "{{booking_date}}",
        new Date(booking.booking_date).toLocaleString()
      )
      .replace("{{status}}", type);

    const emailResponse = await fetch("/api/resend", {
      method: "POST",
      body: JSON.stringify({
        to: booking.email,
        subject: template.subject,
        html: emailBody,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error("Failed to send email");
    }

    // Save notification record
    const [notification] = await sql`
      INSERT INTO booking_notifications (
        booking_id,
        notification_type,
        sent_at,
        status,
        recipient_email
      ) VALUES (
        ${bookingId},
        ${type},
        CURRENT_TIMESTAMP,
        'sent',
        ${booking.email}
      )
      RETURNING *
    `;

    return {
      success: true,
      message: "Notification sent successfully",
      notificationId: notification.id,
    };
  } catch (error) {
    console.error("Notification error:", error);
    return { error: "Failed to send notification" };
  }
}