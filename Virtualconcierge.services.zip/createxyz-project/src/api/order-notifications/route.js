async function handler({ action, data }) {
  try {
    switch (action) {
      case "sendOrderConfirmation": {
        const { orderId, userId } = data;

        const [order, user] = await sql.transaction([
          sql("SELECT * FROM orders WHERE id = $1", [orderId]),
          sql(
            "SELECT email, notification_preferences FROM users WHERE id = $1",
            [userId]
          ),
        ]);

        if (!order[0] || !user[0]) return { error: "Order or user not found" };

        if (user[0].notification_preferences?.order_confirmations === false) {
          return { status: "skipped", reason: "user opted out" };
        }

        const emailResponse = await fetch(
          "https://api.email-service.com/send",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.EMAIL_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              to: user[0].email,
              template: "order_confirmation",
              variables: {
                orderNumber: order[0].id,
                total: order[0].total_amount,
                items: order[0].items,
                shippingAddress: order[0].shipping_address,
              },
            }),
          }
        );

        if (!emailResponse.ok) throw new Error("Failed to send email");

        await sql(
          "INSERT INTO notification_logs (user_id, order_id, type, status) VALUES ($1, $2, $3, $4)",
          [userId, orderId, "order_confirmation", "sent"]
        );

        return { success: true };
      }

      case "sendShippingUpdate": {
        const { orderId, trackingNumber, status } = data;

        const [orderDetails] = await sql(
          `
          SELECT o.*, u.email, u.notification_preferences 
          FROM orders o 
          JOIN users u ON o.user_id = u.id 
          WHERE o.id = $1
        `,
          [orderId]
        );

        if (!orderDetails) return { error: "Order not found" };

        if (orderDetails.notification_preferences?.shipping_updates === false) {
          return { status: "skipped", reason: "user opted out" };
        }

        const emailResponse = await fetch(
          "https://api.email-service.com/send",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.EMAIL_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              to: orderDetails.email,
              template: "shipping_update",
              variables: {
                orderNumber: orderId,
                trackingNumber,
                status,
                estimatedDelivery: orderDetails.estimated_delivery,
              },
            }),
          }
        );

        if (!emailResponse.ok) throw new Error("Failed to send email");

        await sql(
          "INSERT INTO notification_logs (user_id, order_id, type, status) VALUES ($1, $2, $3, $4)",
          [orderDetails.user_id, orderId, "shipping_update", "sent"]
        );

        return { success: true };
      }

      case "sendDeliveryNotification": {
        const { orderId } = data;

        const [orderDetails] = await sql(
          `
          SELECT o.*, u.email, u.notification_preferences 
          FROM orders o 
          JOIN users u ON o.user_id = u.id 
          WHERE o.id = $1
        `,
          [orderId]
        );

        if (!orderDetails) return { error: "Order not found" };

        if (
          orderDetails.notification_preferences?.delivery_notifications ===
          false
        ) {
          return { status: "skipped", reason: "user opted out" };
        }

        const emailResponse = await fetch(
          "https://api.email-service.com/send",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.EMAIL_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              to: orderDetails.email,
              template: "delivery_notification",
              variables: {
                orderNumber: orderId,
                deliveryDate: new Date().toISOString(),
              },
            }),
          }
        );

        if (!emailResponse.ok) throw new Error("Failed to send email");

        await sql(
          "INSERT INTO notification_logs (user_id, order_id, type, status) VALUES ($1, $2, $3, $4)",
          [orderDetails.user_id, orderId, "delivery_notification", "sent"]
        );

        return { success: true };
      }

      case "updateNotificationPreferences": {
        const { userId, preferences } = data;

        await sql(
          `
          UPDATE users 
          SET notification_preferences = $1 
          WHERE id = $2
        `,
          [preferences, userId]
        );

        return { success: true };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    return { error: "Failed to process notification" };
  }
}