function handler({ action, guideId }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "checkStatus":
      return checkStatus(session.user.id, guideId);

    case "initializeDownload":
      return initializeDownload(session.user.id, guideId);

    case "completeDownload":
      return completeDownload(session.user.id, guideId);

    case "deleteContent":
      return deleteContent(session.user.id, guideId);

    default:
      return { error: "Invalid action" };
  }
}

async function checkStatus(userId, guideId) {
  const status = await sql(
    "SELECT * FROM offline_content WHERE user_id = $1 AND guide_id = $2",
    [userId, guideId]
  );
  return { isDownloaded: status.length > 0 };
}

async function initializeDownload(userId, guideId) {
  const access = await sql(
    "SELECT * FROM user_purchases WHERE user_id = $1 AND guide_id = $2",
    [userId, guideId]
  );
  if (access.length === 0) {
    return { error: "Purchase required" };
  }

  const encryptionKey = Buffer.from(crypto.randomBytes(32)).toString("hex");

  await sql(
    "INSERT INTO offline_content (user_id, guide_id, encryption_key) VALUES ($1, $2, $3)",
    [userId, guideId, encryptionKey]
  );

  const guide = await sql(
    "SELECT content_url FROM premium_guides WHERE id = $1",
    [guideId]
  );

  return {
    downloadUrl: guide[0].content_url,
    encryptionKey,
  };
}

async function completeDownload(userId, guideId) {
  await sql(
    "UPDATE offline_content SET last_synced = NOW() WHERE user_id = $1 AND guide_id = $2",
    [userId, guideId]
  );
  return { success: true };
}

async function deleteContent(userId, guideId) {
  await sql(
    "DELETE FROM offline_content WHERE user_id = $1 AND guide_id = $2",
    [userId, guideId]
  );
  return { success: true };
}