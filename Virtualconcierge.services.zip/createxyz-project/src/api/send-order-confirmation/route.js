async function handler({ orderId, email }) {
  if (!orderId || !email) {
    return { error: "Order ID and email are required" };
  }

  try {
    const orders = await sql`
      SELECT 
        o.*,
        oi.quantity,
        oi.price_amount,
        p.name as product_name
      FROM orders o
      JOIN order_items oi ON o.id = oi.order_id
      JOIN products p ON oi.product_id = p.id
      WHERE o.id = ${orderId}
    `;

    if (orders.length === 0) {
      return { error: "Order not found" };
    }

    const items = orders.map((item) => ({
      name: item.product_name,
      quantity: item.quantity,
      price: item.price_amount,
    }));

    const emailResponse = await fetch("/api/send-email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: email,
        subject: `Order Confirmation #${orderId}`,
        html: `
          <h1>Thank you for your order!</h1>
          <p>Order #${orderId}</p>
          <h2>Order Details:</h2>
          <ul>
            ${items
              .map(
                (item) => `
              <li>${item.name} x ${item.quantity} - $${item.price}</li>
            `
              )
              .join("")}
          </ul>
          <p>Total: $${orders[0].total_amount}</p>
          <p>Shipping Address: ${orders[0].shipping_address}</p>
        `,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error("Failed to send email");
    }

    return { success: true };
  } catch (error) {
    console.error("Order confirmation error:", error);
    return { error: "Failed to send confirmation email" };
  }
}