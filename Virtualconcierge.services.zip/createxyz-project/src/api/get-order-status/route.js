async function handler({ orderId }) {
  const session = getSession();
  if (!session) {
    return { error: "Authentication required" };
  }

  if (!orderId) {
    return { error: "Order ID is required" };
  }

  try {
    const orders = await sql`
      SELECT 
        o.id,
        o.status,
        o.total_amount,
        o.shipping_address,
        o.created_at,
        oi.quantity,
        oi.price_amount,
        p.name as product_name
      FROM orders o
      JOIN order_items oi ON o.id = oi.order_id
      JOIN products p ON oi.product_id = p.id
      WHERE o.id = ${orderId} 
      AND o.user_id = ${session.user.id}
    `;

    if (orders.length === 0) {
      return { error: "Order not found" };
    }

    return {
      orderId: orders[0].id,
      status: orders[0].status,
      total: orders[0].total_amount,
      items: orders.map((item) => ({
        name: item.product_name,
        quantity: item.quantity,
        price: item.price_amount,
      })),
      shippingAddress: orders[0].shipping_address,
      createdAt: orders[0].created_at,
    };
  } catch (error) {
    console.error("Status check error:", error);
    return { error: "Failed to get order status" };
  }
}