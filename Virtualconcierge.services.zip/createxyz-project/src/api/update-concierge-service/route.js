async function handler({ id, name, description, price }) {
  if (!id) {
    throw new Error("Service ID is required");
  }

  const updates = [];
  const values = [id];
  let paramCount = 1;

  if (name) {
    updates.push(`name = $${++paramCount}`);
    values.push(name);
  }
  if (description) {
    updates.push(`description = $${++paramCount}`);
    values.push(description);
  }
  if (price) {
    updates.push(`price = $${++paramCount}`);
    values.push(price);
  }

  if (updates.length === 0) {
    throw new Error("No fields to update");
  }

  const query = `UPDATE concierge_services 
                 SET ${updates.join(", ")}, updated_at = CURRENT_TIMESTAMP 
                 WHERE id = $1 
                 RETURNING *`;

  const [updatedService] = await sql(query, values);

  if (!updatedService) {
    throw new Error("Service not found");
  }

  return updatedService;
}