async function handler({ id }) {
  if (!id) {
    throw new Error("Service ID is required");
  }

  try {
    const [service] = await sql`
      SELECT id, name, description, price, created_at, updated_at
      FROM concierge_services 
      WHERE id = ${id}
    `;

    if (!service) {
      throw new Error("Service not found");
    }

    return service;
  } catch (error) {
    if (error.message === "Service not found") {
      throw error;
    }
    throw new Error("Failed to get concierge service");
  }
}