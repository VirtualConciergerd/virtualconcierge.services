async function handler({ name, email, message }) {
  if (!name || !email || !message) {
    return { error: "All fields are required" };
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { error: "Invalid email format" };
  }

  try {
    const result = await sql`
      INSERT INTO contact_submissions (name, email, message, created_at)
      VALUES (${name}, ${email}, ${message}, NOW())
      RETURNING *
    `;

    return { success: true, submission: result[0] };
  } catch (err) {
    return { error: "Failed to submit contact form" };
  }
}