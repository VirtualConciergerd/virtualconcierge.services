async function handler({
  email_digest,
  notification_schedule,
  do_not_disturb,
  digest_day,
}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, error: "Unauthorized" };
  }

  if (email_digest && !["daily", "weekly", "monthly"].includes(email_digest)) {
    return { status: 400, error: "Invalid email digest frequency" };
  }

  try {
    const preferences = {
      email_digest,
      notification_schedule,
      do_not_disturb,
      digest_day,
    };

    const result = await sql`
      UPDATE users
      SET communication_preferences = communication_preferences || ${JSON.stringify(
        preferences
      )}::jsonb
      WHERE id = ${session.user.id}
      RETURNING communication_preferences
    `;

    if (result.length === 0) {
      return { status: 404, error: "User not found" };
    }

    return {
      status: 200,
      preferences: result[0].communication_preferences,
    };
  } catch (error) {
    console.error("Error updating communication preferences:", error);
    return { status: 500, error: "Failed to update preferences" };
  }
}