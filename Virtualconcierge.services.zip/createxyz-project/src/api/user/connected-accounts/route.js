async function handler({ accountType, action }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Not authenticated" };
  }

  if (
    !accountType ||
    !["google", "facebook", "twitter", "github"].includes(accountType)
  ) {
    return { error: "Invalid account type" };
  }

  if (!action || !["add", "remove"].includes(action)) {
    return { error: "Invalid action" };
  }

  try {
    const [user] = await sql`
      SELECT connected_accounts 
      FROM users 
      WHERE id = ${session.user.id}
    `;

    if (!user) {
      return { error: "User not found" };
    }

    let connectedAccounts = user.connected_accounts || [];

    if (action === "add") {
      if (connectedAccounts.includes(accountType)) {
        return { error: "Account already connected" };
      }
      connectedAccounts = [...connectedAccounts, accountType];
    } else {
      connectedAccounts = connectedAccounts.filter(
        (acc) => acc !== accountType
      );
    }

    const [updatedUser] = await sql`
      UPDATE users 
      SET 
        connected_accounts = ${connectedAccounts},
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${session.user.id}
      RETURNING connected_accounts
    `;

    return {
      success: true,
      connected_accounts: updatedUser.connected_accounts,
    };
  } catch (error) {
    return { error: "Failed to update connected accounts" };
  }
}