async function handler({
  display_name,
  avatar_url,
  phone,
  timezone,
  notification_preferences,
  account_settings,
  privacy_settings,
  security_settings,
  connected_accounts,
}) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Not authenticated" };
  }

  if (display_name !== undefined) {
    if (
      typeof display_name !== "string" ||
      display_name.length < 2 ||
      display_name.length > 100
    ) {
      return { error: "Display name must be between 2 and 100 characters" };
    }
  }

  if (phone !== undefined) {
    if (!phone && phone !== "") {
      return { error: "Phone number cannot be null" };
    }
    if (phone && !/^\+?[\d\s-()]{8,20}$/.test(phone)) {
      return { error: "Invalid phone number format" };
    }
  }

  if (timezone !== undefined) {
    if (!timezone && timezone !== "") {
      return { error: "Timezone cannot be null" };
    }
    if (timezone && !/^[A-Za-z_\/+-]{1,50}$/.test(timezone)) {
      return { error: "Invalid timezone format" };
    }
  }

  if (notification_preferences !== undefined) {
    if (
      !notification_preferences ||
      typeof notification_preferences !== "object"
    ) {
      return { error: "Invalid notification preferences" };
    }

    const requiredKeys = ["email", "push", "sms"];
    const validEmailPrefs = [
      "orders",
      "bookings",
      "security",
      "newsletters",
      "product_updates",
    ];
    const validPushPrefs = ["offers", "orders", "bookings", "security_alerts"];
    const validSmsPrefs = ["security_alerts", "booking_reminders"];

    if (
      !requiredKeys.every(
        (key) => typeof notification_preferences[key] === "object"
      )
    ) {
      return { error: "Missing required notification preference categories" };
    }

    for (const [key, prefs] of Object.entries(notification_preferences)) {
      if (!requiredKeys.includes(key)) {
        return { error: `Invalid notification category: ${key}` };
      }

      const validPrefs =
        key === "email"
          ? validEmailPrefs
          : key === "push"
          ? validPushPrefs
          : validSmsPrefs;

      for (const pref in prefs) {
        if (!validPrefs.includes(pref) || typeof prefs[pref] !== "boolean") {
          return { error: `Invalid ${key} preference: ${pref}` };
        }
      }
    }
  }

  if (account_settings !== undefined) {
    if (!account_settings || typeof account_settings !== "object") {
      return { error: "Invalid account settings" };
    }

    const validThemes = ["light", "dark", "system"];
    const validCurrencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD"];
    const validDateFormats = ["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"];
    const validTimeFormats = ["12h", "24h"];

    if (!validThemes.includes(account_settings.theme)) {
      return { error: "Invalid theme setting" };
    }
    if (!validCurrencies.includes(account_settings.currency)) {
      return { error: "Invalid currency setting" };
    }
    if (!validDateFormats.includes(account_settings.date_format)) {
      return { error: "Invalid date format setting" };
    }
    if (!validTimeFormats.includes(account_settings.time_format)) {
      return { error: "Invalid time format setting" };
    }
    if (
      typeof account_settings.accessibility?.large_text !== "boolean" ||
      typeof account_settings.accessibility?.high_contrast !== "boolean"
    ) {
      return { error: "Invalid accessibility settings" };
    }
  }

  if (privacy_settings !== undefined) {
    if (!privacy_settings || typeof privacy_settings !== "object") {
      return { error: "Invalid privacy settings" };
    }

    const validVisibility = ["public", "private", "contacts"];
    if (!validVisibility.includes(privacy_settings.profile_visibility)) {
      return { error: "Invalid profile visibility setting" };
    }
    if (
      typeof privacy_settings.show_email !== "boolean" ||
      typeof privacy_settings.show_phone !== "boolean"
    ) {
      return { error: "Invalid contact visibility settings" };
    }
  }

  if (security_settings !== undefined) {
    if (!security_settings || typeof security_settings !== "object") {
      return { error: "Invalid security settings" };
    }
    if (
      typeof security_settings.two_factor_enabled !== "boolean" ||
      typeof security_settings.login_notifications !== "boolean"
    ) {
      return { error: "Invalid security option types" };
    }
  }

  if (connected_accounts !== undefined) {
    if (!Array.isArray(connected_accounts)) {
      return { error: "Connected accounts must be an array" };
    }
    const validPlatforms = ["google", "facebook", "twitter", "github"];
    if (
      !connected_accounts.every((account) => validPlatforms.includes(account))
    ) {
      return { error: "Invalid connected account platform" };
    }
  }

  const updates = [];
  const values = [];
  let paramCount = 1;

  const fields = {
    display_name,
    avatar_url,
    phone,
    timezone,
    notification_preferences,
    account_settings,
    privacy_settings,
    security_settings,
    connected_accounts,
  };

  for (const [key, value] of Object.entries(fields)) {
    if (value !== undefined) {
      updates.push(`${key} = $${paramCount}`);
      values.push(value);
      paramCount++;
    }
  }

  if (updates.length === 0) {
    return { error: "No valid fields to update" };
  }

  values.push(session.user.id);
  const query = `
    UPDATE users 
    SET ${updates.join(", ")}, 
        updated_at = CURRENT_TIMESTAMP 
    WHERE id = $${paramCount} 
    RETURNING *`;

  const [user] = await sql(query, values);

  if (!user) {
    return { error: "Failed to update user" };
  }

  return { user };
}