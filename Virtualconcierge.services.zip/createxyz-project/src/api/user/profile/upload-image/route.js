async function handler({ image, generateTempUrl, processingOptions }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (!image) {
    return { error: "No image provided" };
  }

  if (!image.startsWith("data:image/")) {
    return { error: "Invalid image format. Must be a base64 encoded image" };
  }

  const fileSize = Math.round((image.length * 3) / 4);
  const maxSize = 5 * 1024 * 1024; // 5MB
  if (fileSize > maxSize) {
    return { error: "Image size exceeds 5MB limit" };
  }

  try {
    const { url, error, mimeType } = await upload({
      base64: image,
    });

    if (error) {
      return { error: "Failed to upload image" };
    }

    if (!mimeType?.startsWith("image/")) {
      return { error: "Invalid file type. Only images are allowed" };
    }

    const metadata = {
      original_size: fileSize,
      mime_type: mimeType,
      upload_date: new Date().toISOString(),
      processing_status: "completed",
    };

    let enhancedImageRecord = null;
    if (generateTempUrl) {
      const expiryTime = new Date();
      expiryTime.setHours(expiryTime.getHours() + 1);

      const [record] = await sql(
        `
        INSERT INTO enhanced_images 
        (original_image_url, enhanced_image_url, status, metadata, preview_url, processing_attempts, configuration)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
      `,
        [url, url, "completed", metadata, url, 1, processingOptions || {}]
      );

      enhancedImageRecord = record;
    }

    const [updatedUser] = await sql.transaction([
      sql(
        `
        UPDATE auth_users 
        SET 
          avatar_url = $1,
          updated_at = CURRENT_TIMESTAMP 
        WHERE id = $2 
        RETURNING id, avatar_url, updated_at
      `,
        [url, session.user.id]
      ),

      sql(
        `
        INSERT INTO users 
        (id, avatar_url, updated_at) 
        VALUES ($1, $2, CURRENT_TIMESTAMP)
        ON CONFLICT (id) 
        DO UPDATE SET 
          avatar_url = EXCLUDED.avatar_url,
          updated_at = CURRENT_TIMESTAMP
      `,
        [session.user.id, url]
      ),
    ]);

    if (!updatedUser) {
      return { error: "Failed to update user profile" };
    }

    const response = {
      success: true,
      avatar_url: updatedUser.avatar_url,
      mime_type: mimeType,
      metadata: {
        file_size: fileSize,
        updated_at: updatedUser.updated_at,
        processing_status: "completed",
      },
    };

    if (enhancedImageRecord) {
      response.temp_url = enhancedImageRecord.preview_url;
      response.temp_url_expires = enhancedImageRecord.metadata.expires_at;
      response.enhanced_image_id = enhancedImageRecord.id;
    }

    return response;
  } catch (error) {
    await sql(
      `
      INSERT INTO error_logs (error_type, message, user_id)
      VALUES ($1, $2, $3)
    `,
      ["image_upload", error.message, session.user.id]
    );

    return { error: "Failed to process image upload" };
  }
}