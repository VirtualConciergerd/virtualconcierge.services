async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Not authenticated" };
  }

  const [user] = await sql`
    SELECT 
      id, 
      display_name, 
      email, 
      avatar_url, 
      phone, 
      timezone,
      notification_preferences,
      account_settings,
      privacy_settings,
      security_settings,
      connected_accounts,
      created_at, 
      updated_at
    FROM users 
    WHERE id = ${session.user.id}
  `;

  if (!user) {
    return { error: "User not found" };
  }

  return { user };
}