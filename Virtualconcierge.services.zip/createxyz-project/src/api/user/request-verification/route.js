async function handler({ method, body }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  if (method !== "POST") {
    return { status: 405, body: { error: "Method not allowed" } };
  }

  const { type, documents } = body;

  try {
    // Check for existing pending request
    const existingRequests = await sql`
      SELECT id 
      FROM verification_requests 
      WHERE user_id = ${session.user.id} 
      AND status = 'pending'
    `;

    if (existingRequests.length > 0) {
      return {
        status: 400,
        body: { error: "You already have a pending verification request" },
      };
    }

    // Use transaction to ensure both operations succeed or fail together
    await sql.transaction([
      sql`
        INSERT INTO verification_requests 
        (user_id, type, documents, status)
        VALUES (${session.user.id}, ${type}, ${documents}, 'pending')
      `,
      sql`
        UPDATE users 
        SET verification_status = 'pending'
        WHERE id = ${session.user.id}
      `,
    ]);

    return {
      status: 200,
      body: { message: "Verification request submitted successfully" },
    };
  } catch (error) {
    console.error("Error submitting verification request:", error);
    return {
      status: 500,
      body: { error: "Failed to submit verification request" },
    };
  }
}