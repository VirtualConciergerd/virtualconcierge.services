async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  try {
    const userData = await sql`
      SELECT 
        au.name, 
        au.email, 
        au."emailVerified" as email_verified,
        u.preferences, 
        u.privacy_settings, 
        u.communication_preferences
      FROM auth_users au
      LEFT JOIN users u ON au.id = u.id
      WHERE au.id = ${session.user.id}`;

    if (!userData?.[0]) {
      return { status: 404, body: { error: "User not found" } };
    }

    const exportData = {
      personalInfo: {
        name: userData[0].name,
        email: userData[0].email,
        emailVerified: userData[0].email_verified,
      },
      preferences: userData[0].preferences,
      privacySettings: userData[0].privacy_settings,
      communicationPreferences: userData[0].communication_preferences,
    };

    return {
      status: 200,
      body: exportData,
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": 'attachment; filename="user-data.json"',
      },
    };
  } catch (error) {
    console.error("Error exporting user data:", error);
    return { status: 500, body: { error: "Failed to export data" } };
  }
}