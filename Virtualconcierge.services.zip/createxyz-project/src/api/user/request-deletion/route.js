async function handler({ reason }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  try {
    await sql.transaction([
      sql`
        UPDATE auth_users 
        SET account_deletion_requested = CURRENT_TIMESTAMP,
            deletion_reason = ${reason}
        WHERE id = ${session.user.id}
      `,
      sql`
        UPDATE users
        SET account_settings = jsonb_set(
          account_settings,
          '{deletion_requested}',
          'true'
        )
        WHERE id = ${session.user.id}
      `,
    ]);

    return {
      status: 200,
      body: { message: "Deletion request submitted successfully" },
    };
  } catch (error) {
    console.error("Error requesting account deletion:", error);
    return {
      status: 500,
      body: { error: "Failed to submit deletion request" },
    };
  }
}