async function handler({ method, settings }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  if (method === "GET") {
    try {
      const result = await sql`
        SELECT accessibility_settings 
        FROM users 
        WHERE id = ${session.user.id}
      `;

      if (result?.[0]) {
        return { settings: result[0].accessibility_settings };
      }
      return { error: "User not found" };
    } catch (error) {
      return { error: "Failed to fetch settings" };
    }
  }

  if (method === "POST") {
    try {
      await sql`
        UPDATE users 
        SET accessibility_settings = ${settings}
        WHERE id = ${session.user.id}
      `;

      return { message: "Settings updated successfully" };
    } catch (error) {
      return { error: "Failed to update settings" };
    }
  }

  return { error: "Method not allowed" };
}