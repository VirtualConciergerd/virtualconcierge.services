async function handler({ enable }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Not authenticated" };
  }

  if (typeof enable !== "boolean") {
    return { error: "Invalid input: enable must be a boolean" };
  }

  try {
    const [user] = await sql`
      SELECT security_settings 
      FROM users 
      WHERE id = ${session.user.id}
    `;

    if (!user) {
      return { error: "User not found" };
    }

    const securitySettings = {
      ...user.security_settings,
      two_factor_enabled: enable,
    };

    const [updatedUser] = await sql`
      UPDATE users 
      SET 
        security_settings = ${securitySettings},
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${session.user.id}
      RETURNING security_settings
    `;

    return {
      success: true,
      two_factor_enabled: updatedUser.security_settings.two_factor_enabled,
    };
  } catch (error) {
    return { error: "Failed to update 2FA settings" };
  }
}