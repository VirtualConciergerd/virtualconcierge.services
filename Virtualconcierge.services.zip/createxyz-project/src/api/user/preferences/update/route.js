async function handler({ notification_preferences, account_settings }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  try {
    // Check if user exists
    const [existingUser] = await sql`
      SELECT id FROM users WHERE id = ${userId}
    `;

    if (!existingUser) {
      // Create user record if it doesn't exist
      await sql`
        INSERT INTO users (id)
        VALUES (${userId})
      `;
    }

    // Update preferences
    const [updatedUser] = await sql`
      UPDATE users
      SET 
        notification_preferences = COALESCE(${notification_preferences}, notification_preferences),
        account_settings = COALESCE(${account_settings}, account_settings),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${userId}
      RETURNING *
    `;

    return {
      success: true,
      preferences: {
        notification_preferences: updatedUser.notification_preferences,
        account_settings: updatedUser.account_settings,
      },
    };
  } catch (error) {
    return { error: "Failed to update preferences" };
  }
}