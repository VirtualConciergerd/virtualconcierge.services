async function handler({ method, body, headers }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  const getUserTimezone = () => {
    try {
      const timeZone =
        headers["x-timezone"] ||
        Intl.DateTimeFormat().resolvedOptions().timeZone;
      return timeZone;
    } catch (error) {
      return "UTC";
    }
  };

  if (method === "GET") {
    try {
      const [userSettings, countryFormats] = await sql.transaction([
        sql`SELECT regional_settings FROM users WHERE id = ${session.user.id}`,
        sql`SELECT date_formats, time_formats, holidays, number_formats 
            FROM countries 
            WHERE code = ${headers.country_code || "US"}`,
      ]);

      const timezone = getUserTimezone();

      return {
        status: 200,
        body: {
          settings: userSettings[0]?.regional_settings,
          countryFormats: countryFormats[0],
          detectedTimezone: timezone,
        },
      };
    } catch (error) {
      console.error("Error fetching regional settings:", error);
      return { status: 500, body: { error: "Failed to fetch settings" } };
    }
  }

  if (method === "POST") {
    const { settings } = body;

    try {
      const validDateFormats = ["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"];
      const validTimeFormats = ["12h", "24h"];
      const validFirstDays = ["sunday", "monday"];
      const validCalendarTypes = ["gregorian", "lunar", "islamic"];

      if (
        !validDateFormats.includes(settings.date_format) ||
        !validTimeFormats.includes(settings.time_format) ||
        !validFirstDays.includes(settings.first_day_of_week) ||
        !validCalendarTypes.includes(settings.calendar_type)
      ) {
        return { status: 400, body: { error: "Invalid settings format" } };
      }

      await sql`
        UPDATE users 
        SET regional_settings = ${settings}
        WHERE id = ${session.user.id}
      `;

      return {
        status: 200,
        body: { message: "Settings updated successfully" },
      };
    } catch (error) {
      console.error("Error updating regional settings:", error);
      return { status: 500, body: { error: "Failed to update settings" } };
    }
  }

  return { status: 405, body: { error: "Method not allowed" } };
}