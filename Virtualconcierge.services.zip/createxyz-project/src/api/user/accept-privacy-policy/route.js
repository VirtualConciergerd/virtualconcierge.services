async function handler({ policyVersion, ipAddress, userAgent }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  try {
    await sql`
      INSERT INTO privacy_policy_acceptance 
      (user_id, policy_version, ip_address, user_agent)
      VALUES (${session.user.id}, ${policyVersion}, ${ipAddress}, ${userAgent})
    `;

    return {
      status: 200,
      body: { message: "Privacy policy acceptance logged successfully" },
    };
  } catch (error) {
    console.error("Error logging privacy policy acceptance:", error);
    return { status: 500, body: { error: "Failed to log acceptance" } };
  }
}