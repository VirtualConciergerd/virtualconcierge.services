async function handler({ id }) {
  if (!id) {
    return { error: "Service ID is required" };
  }

  try {
    const [service] = await sql`
      SELECT * FROM accommodations 
      WHERE id = ${id}
    `;

    if (!service) {
      return { error: "Service not found" };
    }

    return { service };
  } catch (error) {
    return { error: "Failed to fetch concierge service" };
  }
}