async function handler({ tourId, date, participants, specialRequests }) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Authentication required" };
  }

  try {
    // Get tour details
    const tours = await sql`
      SELECT * FROM concierge_services 
      WHERE id = ${tourId} 
      AND type = 'tour'
    `;

    if (!tours.length) {
      return { error: "Tour not found" };
    }

    const tour = tours[0];
    const totalPrice = tour.price * participants;

    // Create the booking
    const bookings = await sql`
      INSERT INTO bookings (
        user_id,
        service_id,
        booking_date,
        number_of_people,
        special_requests,
        total_amount,
        status,
        booking_type
      ) VALUES (
        ${session.user.id},
        ${tourId},
        ${date},
        ${participants},
        ${specialRequests},
        ${totalPrice},
        'pending',
        'tour'
      )
      RETURNING *
    `;

    return {
      booking: bookings[0],
      tour,
    };
  } catch (error) {
    console.error("Tour booking error:", error);
    return { error: "Failed to create tour booking" };
  }
}