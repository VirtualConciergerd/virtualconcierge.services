async function handler({ action, data }) {
  switch (action) {
    case "chat": {
      const { userId, message, language = "en" } = data;

      const chatResponse = await fetch(
        "/integrations/chat-gpt/conversationgpt4",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [{ role: "user", content: message }],
          }),
        }
      );

      const chatResult = await chatResponse.json();
      let responseText = chatResult.choices[0].message.content;

      if (language !== "en") {
        const translateResponse = await fetch(
          "/integrations/google-translate/language/translate/v2",
          {
            method: "POST",
            body: new URLSearchParams({
              q: responseText,
              target: language,
            }),
          }
        );

        const translateResult = await translateResponse.json();
        responseText = translateResult.data.translations[0].translatedText;
      }

      await sql(
        "INSERT INTO chat_history (user_id, message, response) VALUES ($1, $2, $3)",
        [userId, message, responseText]
      );

      return { response: responseText };
    }

    case "recommendations": {
      const { location, type } = data;

      const placesResponse = await fetch(
        `/integrations/local-business-data/search?query=${encodeURIComponent(
          type + " in " + location
        )}`
      );
      const weatherResponse = await fetch(
        `/integrations/weather-by-city/weather/${encodeURIComponent(location)}`
      );

      const [places, weather] = await Promise.all([
        placesResponse.json(),
        weatherResponse.json(),
      ]);

      return {
        places: places.data,
        weather: weather,
      };
    }

    default:
      return null;
  }
}