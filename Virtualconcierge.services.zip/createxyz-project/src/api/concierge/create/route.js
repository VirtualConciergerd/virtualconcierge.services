async function handler({
  name,
  description,
  user_id,
  service_type,
  location,
  price_range,
  booking_link,
}) {
  if (!name || !description || !service_type) {
    return { error: "Missing required fields" };
  }

  try {
    const [newService] = await sql`
      INSERT INTO accommodations (
        name, 
        description, 
        location,
        price_range,
        booking_link,
        created_at
      ) VALUES (
        ${name},
        ${description},
        ${location || ""},
        ${price_range || "mid-range"},
        ${booking_link || null},
        NOW()
      )
      RETURNING *
    `;

    return { service: newService };
  } catch (error) {
    return { error: "Failed to create concierge service" };
  }
}