async function handler({
  id,
  name,
  description,
  location,
  price_range,
  booking_link,
  image_url,
  rating,
}) {
  if (!id) {
    return { error: "Service ID is required" };
  }

  try {
    const setClauses = [];
    const values = [id];
    let paramCount = 1;

    if (name) {
      setClauses.push(`name = $${++paramCount}`);
      values.push(name);
    }

    if (description) {
      setClauses.push(`description = $${++paramCount}`);
      values.push(description);
    }

    if (location) {
      setClauses.push(`location = $${++paramCount}`);
      values.push(location);
    }

    if (price_range) {
      if (!["budget", "mid-range", "luxury"].includes(price_range)) {
        return {
          error:
            "Invalid price range. Must be 'budget', 'mid-range', or 'luxury'",
        };
      }
      setClauses.push(`price_range = $${++paramCount}`);
      values.push(price_range);
    }

    if (booking_link) {
      setClauses.push(`booking_link = $${++paramCount}`);
      values.push(booking_link);
    }

    if (image_url) {
      setClauses.push(`image_url = $${++paramCount}`);
      values.push(image_url);
    }

    if (rating !== undefined) {
      if (rating < 0 || rating > 5) {
        return { error: "Rating must be between 0 and 5" };
      }
      setClauses.push(`rating = $${++paramCount}`);
      values.push(rating);
    }

    if (setClauses.length === 0) {
      return { error: "No fields to update" };
    }

    const query = `
      UPDATE accommodations 
      SET ${setClauses.join(", ")},
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `;

    const [updatedService] = await sql(query, values);

    if (!updatedService) {
      return { error: "Service not found" };
    }

    return { service: updatedService };
  } catch (error) {
    return { error: "Failed to update concierge service" };
  }
}