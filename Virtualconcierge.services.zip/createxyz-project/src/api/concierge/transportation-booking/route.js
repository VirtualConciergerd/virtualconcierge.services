async function handler({
  serviceId,
  date,
  time,
  pickupLocation,
  dropoffLocation,
  passengerCount,
  luggageCount,
  specialRequirements,
}) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Authentication required" };
  }

  try {
    const [service] = await sql`
      SELECT * FROM concierge_services 
      WHERE id = ${serviceId} AND type = 'transportation'
    `;

    if (!service) {
      return { error: "Transportation service not found" };
    }

    const totalAmount = service.price * Math.ceil(passengerCount / 4);
    const bookingDateTime = `${date} ${time}`;

    const [booking] = await sql`
      INSERT INTO bookings (
        user_id,
        service_id,
        booking_date,
        number_of_people,
        total_amount,
        status,
        booking_type
      ) VALUES (
        ${session.user.id},
        ${serviceId},
        ${bookingDateTime},
        ${passengerCount},
        ${totalAmount},
        'pending',
        'transportation'
      )
      RETURNING *
    `;

    const [transportDetails] = await sql`
      INSERT INTO transportation_details (
        booking_id,
        vehicle_type,
        pickup_location,
        dropoff_location,
        passenger_count,
        luggage_count,
        special_requirements
      ) VALUES (
        ${booking.id},
        ${service.name},
        ${pickupLocation},
        ${dropoffLocation},
        ${passengerCount},
        ${luggageCount},
        ${specialRequirements}
      )
      RETURNING *
    `;

    await fetch("/api/booking-notifications", {
      method: "POST",
      body: JSON.stringify({
        bookingId: booking.id,
        type: "confirmed",
        userId: session.user.id,
      }),
    });

    return {
      success: true,
      booking,
      service,
      transportDetails,
    };
  } catch (error) {
    console.error("Transportation booking error:", error);
    return { error: "Failed to create transportation booking" };
  }
}