async function handler({
  search,
  price_range,
  rating_min,
  limit = 20,
  offset = 0,
  sort_by = "created_at",
  sort_order = "DESC",
}) {
  try {
    const values = [];
    let paramCount = 0;

    let queryStr = "SELECT * FROM accommodations WHERE 1=1";

    if (search) {
      queryStr += ` AND (
        LOWER(name) LIKE LOWER($${++paramCount})
        OR LOWER(location) LIKE LOWER($${paramCount})
        OR LOWER(description) LIKE LOWER($${paramCount})
      )`;
      values.push(`%${search}%`);
    }

    if (price_range) {
      queryStr += ` AND price_range = $${++paramCount}`;
      values.push(price_range);
    }

    if (rating_min) {
      queryStr += ` AND rating >= $${++paramCount}`;
      values.push(rating_min);
    }

    const validSortColumns = ["name", "rating", "price_range", "created_at"];
    const sortColumn = validSortColumns.includes(sort_by)
      ? sort_by
      : "created_at";
    const sortDir = sort_order.toUpperCase() === "ASC" ? "ASC" : "DESC";

    queryStr += ` ORDER BY ${sortColumn} ${sortDir}`;
    queryStr += ` LIMIT $${++paramCount} OFFSET $${++paramCount}`;
    values.push(limit, offset);

    const services = await sql(queryStr, values);
    const [{ count }] = await sql(
      `SELECT COUNT(*) FROM accommodations WHERE 1=1`,
      []
    );

    return {
      services,
      total: parseInt(count),
      page: Math.floor(offset / limit) + 1,
      pages: Math.ceil(parseInt(count) / limit),
    };
  } catch (error) {
    return { error: "Failed to fetch concierge services" };
  }
}