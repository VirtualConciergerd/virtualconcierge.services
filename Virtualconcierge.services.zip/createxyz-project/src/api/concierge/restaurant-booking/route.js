async function handler({
  restaurantName,
  date,
  time,
  partySize,
  specialRequests,
}) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Authentication required" };
  }

  try {
    // Check if service exists
    const existingServices = await sql`
      SELECT * FROM concierge_services 
      WHERE name = ${restaurantName} 
      AND type = 'restaurant'
    `;

    let serviceId;
    if (existingServices.length === 0) {
      // Create new service
      const newService = await sql`
        INSERT INTO concierge_services 
        (name, type, description, price)
        VALUES 
        (${restaurantName}, 'restaurant', 'Restaurant reservation', 0)
        RETURNING id
      `;
      serviceId = newService[0].id;
    } else {
      serviceId = existingServices[0].id;
    }

    // Create booking
    const bookingDateTime = `${date} ${time}`;
    const booking = await sql`
      INSERT INTO bookings (
        user_id,
        service_id, 
        booking_date,
        number_of_people,
        special_requests,
        total_amount,
        status
      ) VALUES (
        ${session.user.id},
        ${serviceId},
        ${bookingDateTime},
        ${partySize},
        ${specialRequests},
        0,
        'pending'
      )
      RETURNING *
    `;

    return { booking: booking[0] };
  } catch (error) {
    console.error("Restaurant booking error:", error);
    return { error: "Failed to create restaurant booking" };
  }
}