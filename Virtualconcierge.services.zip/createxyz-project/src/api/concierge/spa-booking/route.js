async function handler({
  spaId,
  date,
  time,
  treatmentType,
  therapistPreference,
  medicalNotes,
  duration,
}) {
  const session = getSession();
  if (!session?.user) {
    return { error: "Authentication required" };
  }

  try {
    // Get spa service details
    const [service] = await sql`
      SELECT * FROM concierge_services 
      WHERE id = ${spaId} AND type = 'spa'
    `;

    if (!service) {
      return { error: "Spa service not found" };
    }

    // Create booking
    const [booking] = await sql`
      INSERT INTO bookings (
        user_id,
        service_id,
        booking_date,
        number_of_people,
        total_amount,
        status,
        booking_type
      ) VALUES (
        ${session.user.id},
        ${spaId},
        ${date + " " + time},
        1,
        ${service.price},
        'pending',
        'spa'
      )
      RETURNING *
    `;

    // Add spa-specific details
    const [spaDetails] = await sql`
      INSERT INTO spa_details (
        booking_id,
        treatment_type,
        therapist_preference,
        medical_notes,
        duration_minutes
      ) VALUES (
        ${booking.id},
        ${treatmentType},
        ${therapistPreference},
        ${medicalNotes},
        ${duration}
      )
      RETURNING *
    `;

    // Send booking notification
    await fetch("/api/booking-notifications", {
      method: "POST",
      body: JSON.stringify({
        bookingId: booking.id,
        type: "confirmed",
        userId: session.user.id,
      }),
    });

    return {
      success: true,
      booking,
      service,
      spaDetails,
    };
  } catch (error) {
    console.error("Spa booking error:", error);
    return { error: "Failed to create spa booking" };
  }
}