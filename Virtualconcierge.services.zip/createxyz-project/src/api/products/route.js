async function handler({ action, data }) {
  switch (action) {
    case "listCategories":
      const categories = await sql`
        SELECT * FROM product_categories 
        ORDER BY name ASC`;
      return categories;

    case "getProducts":
      const { categoryId } = data;
      const products = await sql`
        SELECT p.*, pc.name as category_name 
        FROM products p
        JOIN product_categories pc ON p.category_id = pc.id
        WHERE p.category_id = ${categoryId}
        AND p.is_available = true
        ORDER BY p.name ASC`;
      return products;

    case "searchProducts":
      const { query } = data;
      const searchResults = await sql`
        SELECT p.*, pc.name as category_name 
        FROM products p
        JOIN product_categories pc ON p.category_id = pc.id
        WHERE 
          p.name ILIKE ${`%${query}%`} OR 
          p.description ILIKE ${`%${query}%`} OR
          pc.name ILIKE ${`%${query}%`}
        AND p.is_available = true
        ORDER BY pc.name ASC, p.name ASC`;
      return searchResults;

    default:
      return null;
  }
}