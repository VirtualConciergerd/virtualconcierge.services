async function handler({ categorySlug }) {
  if (!categorySlug) {
    return { error: "Category slug is required" };
  }

  try {
    const results = await sql.transaction([
      sql`
        SELECT 
          pc.id as category_id,
          pc.name as category_name,
          pc.description as category_description,
          pc.image_url as category_image
        FROM product_categories pc
        WHERE pc.slug = ${categorySlug}
        LIMIT 1
      `,
      sql`
        SELECT 
          p.id,
          p.name,
          p.description,
          p.price,
          p.image_url,
          p.is_available
        FROM products p
        JOIN product_categories pc ON p.category_id = pc.id
        WHERE pc.slug = ${categorySlug}
        ORDER BY p.name ASC
      `,
    ]);

    const [categories, products] = results;

    if (categories.length === 0) {
      return { error: "Category not found" };
    }

    return {
      category: categories[0],
      products: products,
    };
  } catch (error) {
    return { error: "Failed to fetch products" };
  }
}