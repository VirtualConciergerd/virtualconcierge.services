async function handler({
  action,
  serviceId,
  date,
  numberOfPeople,
  specialRequests,
  bookingId,
}) {
  const session = getSession();
  const userId = session?.user?.id;

  if (!userId) {
    return { error: "Authentication required" };
  }

  switch (action) {
    case "check_availability": {
      if (!serviceId || !date) {
        return { error: "Service ID and date required" };
      }

      const existingBookings = await sql`
        SELECT COUNT(*) as count 
        FROM bookings 
        WHERE service_id = ${serviceId} 
        AND DATE(booking_date) = ${date}::date 
        AND status = 'confirmed'
      `;

      const service = await sql`
        SELECT * FROM concierge_services 
        WHERE id = ${serviceId}
      `;

      if (!service.length) {
        return { error: "Service not found" };
      }

      const isAvailable = existingBookings[0].count < 10;
      return { available: isAvailable };
    }

    case "create": {
      if (!serviceId || !date || !numberOfPeople) {
        return { error: "Missing required booking information" };
      }

      const service = await sql`
        SELECT * FROM concierge_services 
        WHERE id = ${serviceId}
      `;

      if (!service.length) {
        return { error: "Service not found" };
      }

      const totalAmount = service[0].price * numberOfPeople;

      const [booking] = await sql.transaction([
        sql`
          INSERT INTO bookings (
            user_id, service_id, booking_date, 
            number_of_people, special_requests, 
            total_amount, status
          )
          VALUES (
            ${userId}, ${serviceId}, ${date}, 
            ${numberOfPeople}, ${specialRequests || null}, 
            ${totalAmount}, 'pending'
          )
          RETURNING *
        `,
        sql`
          INSERT INTO admin_audit_log (
            user_id, action, entity_type, 
            entity_id, changes
          )
          VALUES (
            ${userId}, 'create', 'booking', 
            currval('bookings_id_seq'), 
            ${JSON.stringify({ type: "new_booking", serviceId, date })}
          )
        `,
      ]);

      return { booking: booking[0] };
    }

    case "cancel": {
      if (!bookingId) {
        return { error: "Booking ID required" };
      }

      const booking = await sql`
        SELECT * FROM bookings 
        WHERE id = ${bookingId} 
        AND user_id = ${userId}
      `;

      if (!booking.length) {
        return { error: "Booking not found" };
      }

      if (booking[0].status === "cancelled") {
        return { error: "Booking already cancelled" };
      }

      const bookingDate = new Date(booking[0].booking_date);
      const now = new Date();
      const hoursDifference = (bookingDate - now) / (1000 * 60 * 60);

      if (hoursDifference < 24) {
        return {
          error: "Cancellations must be made at least 24 hours in advance",
        };
      }

      await sql.transaction([
        sql`
          UPDATE bookings 
          SET status = 'cancelled', 
              updated_at = CURRENT_TIMESTAMP 
          WHERE id = ${bookingId} 
          AND user_id = ${userId}
        `,
        sql`
          INSERT INTO admin_audit_log (
            user_id, action, entity_type, 
            entity_id, changes
          )
          VALUES (
            ${userId}, 'cancel', 'booking', 
            ${bookingId}, 
            ${JSON.stringify({ type: "cancellation", bookingId })}
          )
        `,
      ]);

      return { success: true, message: "Booking cancelled successfully" };
    }

    case "get": {
      if (!bookingId) {
        return { error: "Booking ID required" };
      }

      const booking = await sql`
        SELECT b.*, cs.name as service_name 
        FROM bookings b
        JOIN concierge_services cs ON b.service_id = cs.id
        WHERE b.id = ${bookingId} 
        AND b.user_id = ${userId}
      `;

      if (!booking.length) {
        return { error: "Booking not found" };
      }

      return { booking: booking[0] };
    }

    case "list": {
      const bookings = await sql`
        SELECT b.*, cs.name as service_name 
        FROM bookings b
        JOIN concierge_services cs ON b.service_id = cs.id
        WHERE b.user_id = ${userId}
        ORDER BY b.booking_date DESC
      `;

      return { bookings };
    }

    default:
      return { error: "Invalid action" };
  }
}