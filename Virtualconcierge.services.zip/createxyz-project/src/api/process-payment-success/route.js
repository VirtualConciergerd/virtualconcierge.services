async function handler({ paymentIntentId }) {
  if (!paymentIntentId) {
    return { error: "Payment intent ID is required" };
  }

  try {
    const stripeResponse = await fetch(
      "https://api.stripe.com/v1/payment_intents/" + paymentIntentId,
      {
        headers: {
          Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        },
      }
    );

    if (!stripeResponse.ok) {
      throw new Error("Failed to verify payment intent");
    }

    const paymentIntent = await stripeResponse.json();

    if (paymentIntent.status !== "succeeded") {
      return { error: "Payment has not succeeded" };
    }

    await sql.transaction([
      sql`
        UPDATE orders 
        SET status = 'paid', 
            payment_intent_id = ${paymentIntentId},
            updated_at = CURRENT_TIMESTAMP
        WHERE metadata->>'paymentIntentId' = ${paymentIntentId}
        RETURNING id, email
      `,
      sql`
        INSERT INTO order_events (order_id, event_type, data)
        SELECT id, 'payment_success', ${JSON.stringify(paymentIntent)}
        FROM orders
        WHERE metadata->>'paymentIntentId' = ${paymentIntentId}
      `,
    ]);

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "orders@virtualconcierge.com",
        to: paymentIntent.receipt_email,
        subject: "Your Order Confirmation",
        html: `Thank you for your order! Your payment has been successfully processed.`,
      }),
    });

    if (!emailResponse.ok) {
      console.error("Failed to send confirmation email");
    }

    return {
      success: true,
      orderId: paymentIntent.metadata.orderId,
    };
  } catch (error) {
    console.error("Payment processing error:", error);
    return {
      error: "Failed to process payment confirmation",
    };
  }
}