async function handler({ action, data }) {
  const session = getSession();
  if (!session) {
    return { error: "Authentication required" };
  }

  const userId = session.user?.id;

  try {
    switch (action) {
      case "createOrder": {
        const { items, totalAmount, shippingAddress } = data;

        const orderResults = await sql.transaction([
          sql`
            INSERT INTO orders (user_id, total_amount, shipping_address, status)
            VALUES (${userId}, ${totalAmount}, ${shippingAddress}, 'pending')
            RETURNING *
          `,
          ...items.map(
            (item) =>
              sql`
              INSERT INTO order_items (order_id, product_id, quantity, price_at_time)
              VALUES (currval('orders_id_seq'), ${item.id}, ${item.quantity}, ${item.price})
            `
          ),
          sql`
            DELETE FROM cart_items WHERE user_id = ${userId}
          `,
        ]);

        return { success: true, order: orderResults[0][0] };
      }

      case "listUserOrders":
        const orders = await sql`
          SELECT o.*, 
                 json_agg(json_build_object(
                   'id', oi.id,
                   'product_id', oi.product_id,
                   'quantity', oi.quantity,
                   'price_at_time', oi.price_at_time
                 )) as items
          FROM orders o
          LEFT JOIN order_items oi ON o.id = oi.order_id
          WHERE o.user_id = ${userId}
          GROUP BY o.id
          ORDER BY o.created_at DESC
        `;
        return { orders };

      default:
        return { error: "Invalid action" };
    }
  } catch (err) {
    console.error("Order management error:", err);
    return { error: "Failed to process order action" };
  }
}