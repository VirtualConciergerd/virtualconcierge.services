async function handler({ userId, action, data }) {
  const session = getSession();
  if (!session?.user?.id && action !== "resetPassword") {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "create":
      const language = data?.language || "en";
      const role = data?.role || "user";

      if (
        role === "admin" &&
        (!session?.user?.role || session.user.role !== "admin")
      ) {
        return { error: "Unauthorized to create admin accounts" };
      }

      const newUser = await sql.transaction(async (sql) => {
        const user = await sql`
          INSERT INTO users (language, preferences, role)
          VALUES (${language}, ${{}}, ${role})
          RETURNING *`;

        await sql`
          INSERT INTO admin_logs (admin_id, action, target_id, details)
          VALUES (${session.user.id}, ${"user_created"}, ${
          user[0].id
        }, ${JSON.stringify(data)})`;

        return user[0];
      });

      return newUser;

    case "get":
      if (!session.user.role === "admin" && session.user.id !== userId) {
        return { error: "Unauthorized" };
      }

      const user = await sql`
        SELECT u.*, s.active as session_active, s.last_activity
        FROM users u
        LEFT JOIN user_sessions s ON s.user_id = u.id
        WHERE u.id = ${userId}`;
      return user[0];

    case "update":
      if (!session.user.role === "admin" && session.user.id !== userId) {
        return { error: "Unauthorized" };
      }

      const updatedUser = await sql.transaction(async (sql) => {
        const user = await sql`
          UPDATE users 
          SET language = COALESCE(${data.language}, language),
              preferences = COALESCE(${data.preferences}, preferences),
              role = COALESCE(${data.role}, role)
          WHERE id = ${userId}
          RETURNING *`;

        await sql`
          INSERT INTO admin_logs (admin_id, action, target_id, details)
          VALUES (${
            session.user.id
          }, ${"user_updated"}, ${userId}, ${JSON.stringify(data)})`;

        return user[0];
      });

      return updatedUser;

    case "delete":
      if (!session.user.role === "admin" && session.user.id !== userId) {
        return { error: "Unauthorized" };
      }

      return await sql.transaction(async (sql) => {
        await sql`DELETE FROM user_sessions WHERE user_id = ${userId}`;
        await sql`DELETE FROM users WHERE id = ${userId}`;

        await sql`
          INSERT INTO admin_logs (admin_id, action, target_id, details)
          VALUES (${
            session.user.id
          }, ${"user_deleted"}, ${userId}, ${JSON.stringify(data)})`;

        return { success: true };
      });

    case "resetPassword":
      const resetToken = data.token;
      const newPassword = data.password;

      if (!resetToken || !newPassword) {
        return { error: "Invalid reset request" };
      }

      return await sql.transaction(async (sql) => {
        const token = await sql`
          SELECT * FROM password_reset_tokens 
          WHERE token = ${resetToken} 
          AND expires_at > NOW()`;

        if (!token.length) {
          return { error: "Invalid or expired token" };
        }

        await sql`
          UPDATE auth_accounts 
          SET password = ${newPassword} 
          WHERE "userId" = ${token[0].user_id}`;

        await sql`
          DELETE FROM password_reset_tokens 
          WHERE token = ${resetToken}`;

        return { success: true };
      });

    case "invalidateSession":
      if (!session.user.role === "admin" && session.user.id !== userId) {
        return { error: "Unauthorized" };
      }

      await sql`
        UPDATE user_sessions 
        SET active = false 
        WHERE user_id = ${userId}`;

      return { success: true };

    default:
      return { error: "Invalid action" };
  }
}