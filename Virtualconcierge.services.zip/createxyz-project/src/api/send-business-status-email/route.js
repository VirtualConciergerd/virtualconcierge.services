async function handler({ body }) {
  const { businessId, status, notes, customInstructions } = body;

  if (!businessId || !status) {
    return { error: "Business ID and status are required" };
  }

  if (!["approved", "rejected", "pending"].includes(status)) {
    return { error: "Invalid status value" };
  }

  try {
    const businesses = await sql`
      SELECT name, contact_name, email 
      FROM businesses 
      WHERE id = ${businessId}
    `;

    if (!businesses.length) {
      return { error: "Business not found" };
    }

    const business = businesses[0];

    const emailSubjects = {
      approved: "🎉 Welcome Aboard! Your Business Registration is Approved",
      rejected: "Update Regarding Your Business Registration",
      pending: "We've Received Your Business Registration",
    };

    const emailTemplates = {
      approved: `
        <h2>Congratulations ${business.contact_name}!</h2>
        <p>Your business "${
          business.name
        }" has been approved and is now live on our platform.</p>
        ${
          customInstructions
            ? `
          <h3>Next Steps:</h3>
          <div style="background: #f8f9fa; padding: 15px; border-radius: 5px;">
            ${customInstructions}
          </div>
        `
            : ""
        }
        <h3>Getting Started:</h3>
        <ul>
          <li>Access your dashboard at: [Dashboard URL]</li>
          <li>Update your business profile</li>
          <li>Set up your availability calendar</li>
          <li>Review your analytics</li>
        </ul>
        <p>Need help? Our support team is available 24/7.</p>
      `,
      rejected: `
        <h2>Hello ${business.contact_name},</h2>
        <p>We've reviewed your registration for "${
          business.name
        }" and unfortunately cannot approve it at this time.</p>
        ${
          notes
            ? `
          <h3>Feedback from our Review Team:</h3>
          <div style="background: #f8f9fa; padding: 15px; border-radius: 5px;">
            ${notes}
          </div>
        `
            : ""
        }
        <p>You're welcome to resubmit your application addressing the feedback above.</p>
        <p>For any questions, please contact our support team.</p>
      `,
      pending: `
        <h2>Hello ${business.contact_name},</h2>
        <p>We've received your registration for "${business.name}".</p>
        <p>Our team will review your application within 1-2 business days.</p>
        <p>What happens next:</p>
        <ul>
          <li>Application review by our team</li>
          <li>Possible contact for additional information</li>
          <li>Final decision notification</li>
        </ul>
        <p>We'll keep you updated on the progress.</p>
      `,
    };

    await fetch("https://api.resend.com/v1/email/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Virtual Concierge <no-reply@virtualconcierge.services>",
        to: business.email,
        subject: emailSubjects[status],
        html: emailTemplates[status],
      }),
    });

    return { success: true };
  } catch (error) {
    return { error: "Failed to send email notification" };
  }
}