async function handler({ priceMin, priceMax }) {
  const filters = [];
  const values = [];
  let paramCount = 0;

  if (priceMin !== undefined) {
    filters.push(`price >= $${++paramCount}`);
    values.push(priceMin);
  }
  if (priceMax !== undefined) {
    filters.push(`price <= $${++paramCount}`);
    values.push(priceMax);
  }

  const whereClause =
    filters.length > 0 ? `WHERE ${filters.join(" AND ")}` : "";
  const query = `
    SELECT id, name, description, price, created_at, updated_at 
    FROM concierge_services 
    ${whereClause} 
    ORDER BY price ASC`;

  try {
    const result = await sql(query, values);
    return result;
  } catch (error) {
    throw new Error("Failed to list concierge services");
  }
}