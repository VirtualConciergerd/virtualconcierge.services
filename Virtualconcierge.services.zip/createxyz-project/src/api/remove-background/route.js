async function handler({ imageUrl }) {
  if (!imageUrl) {
    return { error: "No image URL provided", status: 400 };
  }

  if (!process.env.REPLICATE_API_TOKEN) {
    return { error: "Replicate API token not configured", status: 500 };
  }

  try {
    const response = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        Authorization: `Token ${process.env.REPLICATE_API_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        version:
          "fb8af171cfa1616ddcf1242c093f9c46bcada5ad4cf6f2fbe8b81b330ec5c003",
        input: { image: imageUrl },
      }),
    });

    if (!response.ok) {
      return {
        error: "Failed to start image processing",
        status: response.status,
      };
    }

    const prediction = await response.json();
    let status = prediction.status;
    let result = prediction;
    const maxAttempts = 30;
    let attempts = 0;

    while (
      status !== "succeeded" &&
      status !== "failed" &&
      attempts < maxAttempts
    ) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      attempts++;

      const pollResponse = await fetch(
        `https://api.replicate.com/v1/predictions/${prediction.id}`,
        {
          headers: {
            Authorization: `Token ${process.env.REPLICATE_API_TOKEN}`,
          },
        }
      );

      if (!pollResponse.ok) {
        return {
          error: "Failed to check processing status",
          status: pollResponse.status,
        };
      }

      result = await pollResponse.json();
      status = result.status;
    }

    if (status === "failed" || attempts >= maxAttempts) {
      return {
        error:
          attempts >= maxAttempts
            ? "Image processing timeout"
            : "Image processing failed",
        status: 500,
      };
    }

    return {
      url: result.output,
      status: 200,
    };
  } catch (error) {
    return {
      error: "Internal server error",
      status: 500,
    };
  }
}