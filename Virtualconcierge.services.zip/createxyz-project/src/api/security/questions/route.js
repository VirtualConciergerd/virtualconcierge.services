async function handler({ method = "GET", body = {}, user = null } = {}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  if (method === "POST") {
    const { questions } = body;

    try {
      await sql.transaction(async (sql) => {
        await sql`DELETE FROM security_questions WHERE user_id = ${session.user.id}`;

        for (const q of questions) {
          const salt = await bcrypt.genSalt(10);
          const answerHash = await bcrypt.hash(
            q.answer.toLowerCase().trim(),
            salt
          );

          await sql`
            INSERT INTO security_questions (user_id, question, answer_hash)
            VALUES (${session.user.id}, ${q.question}, ${answerHash})
          `;
        }
      });

      return { status: 200, body: { message: "Security questions updated" } };
    } catch (error) {
      return {
        status: 500,
        body: { error: "Failed to update security questions" },
      };
    }
  }

  if (method === "GET") {
    try {
      const questions = await sql`
        SELECT id, question 
        FROM security_questions 
        WHERE user_id = ${session.user.id}
      `;
      return { status: 200, body: questions };
    } catch (error) {
      return {
        status: 500,
        body: { error: "Failed to fetch security questions" },
      };
    }
  }

  if (method === "PUT") {
    const { questionId, answer } = body;

    try {
      const [question] = await sql`
        SELECT answer_hash 
        FROM security_questions 
        WHERE id = ${questionId} 
        AND user_id = ${session.user.id}
      `;

      if (!question) {
        return { status: 404, body: { error: "Question not found" } };
      }

      const isCorrect = await bcrypt.compare(
        answer.toLowerCase().trim(),
        question.answer_hash
      );

      return { status: 200, body: { correct: isCorrect } };
    } catch (error) {
      return { status: 500, body: { error: "Failed to verify answer" } };
    }
  }

  return { status: 405, body: { error: "Method not allowed" } };
}