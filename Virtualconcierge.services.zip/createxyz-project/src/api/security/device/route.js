async function handler(req) {
  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  // Generate fingerprint from request data
  const userAgent = req.headers["user-agent"];
  const ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const acceptLanguage = req.headers["accept-language"];
  const screenResolution = req.body?.screenResolution;
  const timeZone = req.body?.timeZone;

  const fingerprint = require("crypto")
    .createHash("sha256")
    .update(`${userAgent}${ip}${acceptLanguage}${screenResolution}${timeZone}`)
    .digest("hex");

  const deviceName = req.body?.deviceName || userAgent;

  try {
    // Using sql function form for better readability with the UPSERT query
    const device = await sql(
      `INSERT INTO trusted_devices 
       (user_id, device_fingerprint, device_name, last_used) 
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (user_id, device_fingerprint) 
       DO UPDATE SET last_used = NOW()
       RETURNING *`,
      [session.user.id, fingerprint, deviceName]
    );

    return {
      status: 200,
      body: { device: device[0] },
    };
  } catch (error) {
    return {
      status: 500,
      body: { error: "Failed to process device fingerprint" },
    };
  }
}