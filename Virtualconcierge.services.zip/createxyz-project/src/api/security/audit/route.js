async function handler({ method }) {
  if (method !== "POST") {
    return { status: 405, body: { error: "Method not allowed" } };
  }

  const session = getSession();
  if (!session?.user?.id) {
    return { status: 401, body: { error: "Unauthorized" } };
  }

  const events = await sql`
    SELECT 
      'login_attempt' as type,
      attempt_time as timestamp,
      success,
      ip_address,
      device_fingerprint,
      location
    FROM login_attempts 
    WHERE user_email = (SELECT email FROM auth_users WHERE id = ${session.user.id})
    UNION ALL
    SELECT 
      'device_trust' as type,
      created_at as timestamp,
      is_trusted as success,
      NULL as ip_address,
      device_fingerprint,
      device_name as location
    FROM trusted_devices
    WHERE user_id = ${session.user.id}
    UNION ALL
    SELECT 
      'security_question' as type,
      created_at as timestamp,
      true as success,
      NULL as ip_address,
      NULL as device_fingerprint,
      question as location
    FROM security_questions
    WHERE user_id = ${session.user.id}
    ORDER BY timestamp DESC
    LIMIT 100
  `;

  return {
    status: 200,
    body: events,
  };
}