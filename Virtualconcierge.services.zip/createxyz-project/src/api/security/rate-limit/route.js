async function handler({ ip, email }) {
  const RATE_LIMIT_TIERS = [
    { attempts: 5, window: "15 minutes", blockDuration: "1 hour" },
    { attempts: 10, window: "1 hour", blockDuration: "24 hours" },
    { attempts: 20, window: "24 hours", blockDuration: "7 days" },
  ];

  // Check if IP is already blocked
  const blockedIPs = await sql`
    SELECT blocked_until FROM blocked_ips 
    WHERE ip_address = ${ip} 
    AND blocked_until > NOW()
  `;

  if (blockedIPs.length > 0) {
    return {
      status: 429,
      body: {
        error: "Too many attempts. Please try again later.",
        blocked: true,
        blockedUntil: blockedIPs[0].blocked_until,
      },
    };
  }

  // Get block count to determine tier
  const blockHistory = await sql`
    SELECT COUNT(*) as block_count 
    FROM blocked_ips 
    WHERE ip_address = ${ip}
  `;

  const tier = Math.min(
    blockHistory[0].block_count,
    RATE_LIMIT_TIERS.length - 1
  );
  const {
    attempts: maxAttempts,
    window,
    blockDuration,
  } = RATE_LIMIT_TIERS[tier];

  // Get recent attempts
  const recentAttempts = email
    ? await sql`
        SELECT COUNT(*) as count 
        FROM login_attempts 
        WHERE (ip_address = ${ip} OR user_email = ${email})
        AND attempt_time > NOW() - INTERVAL ${window}
      `
    : await sql`
        SELECT COUNT(*) as count 
        FROM login_attempts 
        WHERE ip_address = ${ip}
        AND attempt_time > NOW() - INTERVAL ${window}
      `;

  // If too many attempts, block the IP
  if (recentAttempts[0].count >= maxAttempts) {
    await sql`
      INSERT INTO blocked_ips (ip_address, reason, blocked_until) 
      VALUES (${ip}, 'Too many login attempts', NOW() + INTERVAL ${blockDuration})
    `;

    // Log security event
    await fetch("/api/security-alert-notification", {
      method: "POST",
      body: JSON.stringify({
        type: "rate_limit_exceeded",
        ip,
        email,
        tier,
        attempts: recentAttempts[0].count,
        blockDuration,
      }),
    });

    return {
      status: 429,
      body: {
        error: "Too many attempts. Please try again later.",
        blocked: true,
        blockDuration,
        tier: tier + 1,
      },
    };
  }

  return {
    status: 200,
    body: {
      remaining: maxAttempts - recentAttempts[0].count,
      window,
      tier: tier + 1,
    },
  };
}