async function handler({ prompt }) {
  if (!prompt) {
    return { error: "Prompt is required" };
  }

  try {
    const response = await fetch(
      "https://api.replicate.com/v1/models/google/imagen-3/predictions",
      {
        method: "POST",
        headers: {
          Authorization: `Token ${process.env.REPLICATE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: {
            prompt: prompt,
            negative_prompt: "blurry, ugly, duplicate, poorly drawn",
            num_outputs: 1,
          },
        }),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to initiate image generation");
    }

    const prediction = await response.json();
    console.log("prediction: ", prediction);

    let attempts = 0;
    const maxAttempts = 30;
    const pollInterval = 2000;

    while (attempts < maxAttempts) {
      const statusResponse = await fetch(
        `https://api.replicate.com/v1/predictions/${prediction.id}`,
        {
          headers: {
            Authorization: `Token ${process.env.REPLICATE_API_KEY}`,
          },
        }
      );

      if (!statusResponse.ok) {
        throw new Error("Failed to check generation status");
      }

      const result = await statusResponse.json();
      console.log("result: ", result);

      if (result.status === "succeeded") {
        return { url: result.output };
      }

      if (result.status === "failed") {
        throw new Error("Image generation failed");
      }

      await new Promise((resolve) => setTimeout(resolve, pollInterval));
      attempts++;
    }

    throw new Error("Generation timed out");
  } catch (error) {
    return {
      error: error.message || "Failed to generate image",
    };
  }
}