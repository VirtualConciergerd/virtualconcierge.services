async function handler({ name, description, price }) {
  if (!name || !description || !price) {
    throw new Error("Missing required fields");
  }

  const [service] = await sql`
    INSERT INTO concierge_services (
      name,
      description, 
      price,
      created_at
    ) VALUES (
      ${name},
      ${description},
      ${price},
      CURRENT_TIMESTAMP
    )
    RETURNING *
  `;

  return service;
}