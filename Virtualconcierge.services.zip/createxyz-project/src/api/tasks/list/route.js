async function handler() {
  const tasks = await sql`
    SELECT t.*, 
      u.name as creator_name,
      COUNT(c.id) as comment_count
    FROM tasks t
    LEFT JOIN auth_users u ON t.user_id = u.id 
    LEFT JOIN task_comments c ON t.id = c.task_id
    GROUP BY t.id, u.name
    ORDER BY t.created_at DESC
  `;

  return tasks;
}