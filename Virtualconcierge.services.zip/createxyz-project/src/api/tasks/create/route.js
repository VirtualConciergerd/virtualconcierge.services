async function handler({ title, description }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Must be logged in" };
  }

  if (!title) {
    return { error: "Title is required" };
  }

  const [task] = await sql`
    INSERT INTO tasks (title, description, user_id)
    VALUES (${title}, ${description}, ${session.user.id})
    RETURNING *
  `;

  return task;
}