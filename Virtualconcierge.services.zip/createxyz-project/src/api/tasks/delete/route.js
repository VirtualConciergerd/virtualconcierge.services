async function handler({ taskId }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Must be logged in" };
  }

  if (!taskId) {
    return { error: "Task ID is required" };
  }

  const [deletedTask] = await sql`
    DELETE FROM tasks 
    WHERE id = ${taskId} 
    AND user_id = ${session.user.id}
    RETURNING *
  `;

  if (!deletedTask) {
    return {
      error: "Task not found or you don't have permission to delete it",
    };
  }

  return deletedTask;
}