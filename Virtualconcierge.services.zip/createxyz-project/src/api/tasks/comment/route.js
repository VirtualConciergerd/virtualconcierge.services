async function handler({ taskId, content }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Must be logged in" };
  }

  if (!taskId || !content) {
    return { error: "Task ID and content are required" };
  }

  const [comment] = await sql`
    INSERT INTO task_comments (task_id, user_id, content)
    VALUES (${taskId}, ${session.user.id}, ${content})
    RETURNING *
  `;

  return comment;
}