async function handler({ taskId }) {
  if (!taskId) {
    return { error: "Task ID is required" };
  }

  const comments = await sql`
    SELECT c.*, u.name as user_name
    FROM task_comments c
    JOIN auth_users u ON c.user_id = u.id
    WHERE c.task_id = ${taskId}
    ORDER BY c.created_at DESC
  `;

  return comments;
}