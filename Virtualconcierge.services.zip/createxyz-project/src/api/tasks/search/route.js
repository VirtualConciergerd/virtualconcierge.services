async function handler({ body }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Must be logged in" };
  }

  const { query, filter } = body;
  if (!query) {
    return { error: "Search query is required" };
  }

  const searchPattern = `%${query}%`;

  const tasks = await sql`
    SELECT DISTINCT t.*, 
      u.name as creator_name,
      COUNT(c.id) as comment_count
    FROM tasks t
    LEFT JOIN auth_users u ON t.user_id = u.id 
    LEFT JOIN task_comments c ON t.id = c.task_id
    WHERE 
      (t.title ILIKE ${searchPattern} OR 
       t.description ILIKE ${searchPattern} OR 
       EXISTS (
         SELECT 1 FROM task_comments 
         WHERE task_id = t.id AND content ILIKE ${searchPattern}
       ))
    GROUP BY t.id, u.name
    ORDER BY t.created_at DESC
  `;

  return { tasks };
}