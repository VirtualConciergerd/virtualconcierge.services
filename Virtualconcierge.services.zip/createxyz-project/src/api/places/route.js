async function handler({ action, data }) {
  switch (action) {
    case "save":
      const savedPlace = await sql`
        INSERT INTO saved_places (user_id, place_id, place_type, name, address)
        VALUES (${data.userId}, ${data.placeId}, ${data.placeType}, ${data.name}, ${data.address})
        RETURNING *`;
      return savedPlace[0];

    case "get":
      const places = await sql`
        SELECT * FROM saved_places 
        WHERE user_id = ${data.userId}`;
      return places;

    case "remove":
      await sql`
        DELETE FROM saved_places 
        WHERE user_id = ${data.userId} 
        AND place_id = ${data.placeId}`;
      return { success: true };

    default:
      return null;
  }
}