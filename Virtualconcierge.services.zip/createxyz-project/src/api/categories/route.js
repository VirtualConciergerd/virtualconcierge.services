async function handler() {
  try {
    const categories = await sql`
      SELECT 
        pc.*,
        COUNT(p.id) as product_count
      FROM product_categories pc
      LEFT JOIN products p ON pc.id = p.category_id
      GROUP BY pc.id
      ORDER BY pc.name ASC
    `;

    const categoriesWithImages = await Promise.all(
      categories.map(async (category) => {
        const searchTerm = `${category.name} product`;
        try {
          const response = await fetch(
            `https://pixabay.com/api/?key=${
              process.env.PIXABAY_API_KEY
            }&q=${encodeURIComponent(searchTerm)}&per_page=3`
          );
          const data = await response.json();
          const images = data.hits?.map((hit) => hit.largeImageURL) || [];

          return {
            ...category,
            images,
          };
        } catch (error) {
          return {
            ...category,
            images: [],
          };
        }
      })
    );

    return {
      categories: categoriesWithImages,
    };
  } catch (err) {
    return {
      error: "Failed to fetch product categories",
    };
  }
}