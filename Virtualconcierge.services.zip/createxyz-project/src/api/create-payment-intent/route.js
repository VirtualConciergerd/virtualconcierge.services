async function handler({ amount, currency = "usd" }) {
  try {
    const url = "https://api.stripe.com/v1/payment_intents";

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        amount: Math.round(amount * 100),
        currency: currency,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Payment intent creation failed");
    }

    const paymentIntent = await response.json();

    return {
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error) {
    return {
      error: error.message || "Failed to create payment intent",
    };
  }
}