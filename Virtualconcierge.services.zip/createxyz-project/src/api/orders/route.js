async function handler({ action, data }) {
  try {
    switch (action) {
      case "createOrder": {
        const { userId, items, totalAmount, shippingAddress } = data;
        const order = await sql(
          `
          INSERT INTO orders (user_id, total_amount, shipping_address, status, created_at)
          VALUES ($1, $2, $3, $4, NOW())
          RETURNING id`,
          [userId, totalAmount, shippingAddress, "pending"]
        );

        const orderItems = items.map((item, index) =>
          sql(
            `
            INSERT INTO order_items (order_id, item_id, quantity, price)
            VALUES ($1, $2, $3, $4)`,
            [order[0].id, item.id, item.quantity, item.price]
          )
        );

        await sql.transaction(orderItems);
        return { success: true, orderId: order[0].id };
      }

      case "updateOrderStatus": {
        const { orderId, status } = data;
        await sql(
          `
          UPDATE orders 
          SET status = $1, updated_at = NOW()
          WHERE id = $2`,
          [status, orderId]
        );
        return { success: true };
      }

      case "getOrderDetails": {
        const { orderId } = data;
        const [order, items] = await sql.transaction([
          sql(
            `
            SELECT * FROM orders 
            WHERE id = $1`,
            [orderId]
          ),
          sql(
            `
            SELECT oi.*, i.name, i.image_url
            FROM order_items oi
            JOIN items i ON oi.item_id = i.id
            WHERE oi.order_id = $1`,
            [orderId]
          ),
        ]);
        return { order: order[0], items };
      }

      case "listUserOrders": {
        const { userId } = data;
        const orders = await sql(
          `
          SELECT * FROM orders
          WHERE user_id = $1
          ORDER BY created_at DESC`,
          [userId]
        );
        return { orders };
      }

      case "cancelOrder": {
        const { orderId } = data;
        await sql(
          `
          UPDATE orders
          SET status = $1, updated_at = NOW()
          WHERE id = $2 AND status = $3`,
          ["cancelled", orderId, "pending"]
        );
        return { success: true };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    return { error: "Failed to process order operation" };
  }
}