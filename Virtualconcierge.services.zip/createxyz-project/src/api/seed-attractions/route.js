async function handler() {
  const attractionsData = {
    Ontario: [
      {
        name: "CN Tower",
        description:
          "Iconic landmark with observation decks & revolving restaurant",
        image: "https://images.unsplash.com/photo-1517090504586-fde19ea6066f",
      },
      {
        name: "Niagara Falls",
        description: "Magnificent waterfalls with boat tours & viewing areas",
        image: "https://images.unsplash.com/photo-1489447068241-b3490214e879",
      },
    ],
    "British Columbia": [
      {
        name: "Stanley Park",
        description: "Urban park with beaches, trails & Vancouver Aquarium",
        image: "https://images.unsplash.com/photo-1609825488888-3a766db05542",
      },
      {
        name: "Butchart Gardens",
        description: "55 acres of stunning floral gardens & displays",
        image: "https://images.unsplash.com/photo-1591994843349-f415893b3a6b",
      },
    ],
    Quebec: [
      {
        name: "Old Quebec",
        description: "Historic district with European charm & architecture",
        image: "https://images.unsplash.com/photo-1519832979-6fa011b87667",
      },
      {
        name: "Mont Tremblant",
        description: "Ski resort & year-round outdoor activities",
        image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec",
      },
    ],
  };

  await sql.transaction(async (sql) => {
    for (const provinceName of Object.keys(attractionsData)) {
      const [province] = await sql`
        INSERT INTO provinces (name)
        VALUES (${provinceName})
        RETURNING id`;

      const attractions = attractionsData[provinceName];
      for (const attraction of attractions) {
        await sql`
          INSERT INTO attractions (
            province_id, 
            name, 
            description, 
            image_url
          ) VALUES (
            ${province.id}, 
            ${attraction.name}, 
            ${attraction.description}, 
            ${attraction.image}
          )`;
      }
    }
  });

  return { success: true, message: "Database seeded successfully" };
}